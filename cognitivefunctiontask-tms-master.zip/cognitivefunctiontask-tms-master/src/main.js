import Vue from "vue";
import App from "./App.vue";
import router from "./router";
import store from "./store";
import { config } from "./data/Config";
// import { shapes } from "./data/Shapes";
// import ImageService from "./services/ImageService";

import vmodal from "vue-js-modal";
import notifications from "vue-notification";
import moment from "moment";
import clipboard from "v-clipboard";
import vueNumeralFilterInstaller from "vue-numeral-filter";
import browserDetect from "vue-browser-detect-plugin";

import { library } from "@fortawesome/fontawesome-svg-core";
import { FontAwesomeIcon } from "@fortawesome/vue-fontawesome";

// Font awesome
import {
	faEdit,
	faCopy,
	faTrashAlt,
	faPlus,
	faSave,
	faTimes,
	faEye,
	faExclamationTriangle,
	faTimesCircle,
	faCheck,
	faChevronRight,
	faChevronDown,
	faFileExport,
	faFileImport,
	faLock,
	faUsersCog,
	faDatabase,
	faQuestion,
} from "@fortawesome/free-solid-svg-icons";
library.add(
	faEdit,
	faCopy,
	faTrashAlt,
	faPlus,
	faSave,
	faTimes,
	faEye,
	faExclamationTriangle,
	faTimesCircle,
	faCheck,
	faChevronRight,
	faChevronDown,
	faFileExport,
	faFileImport,
	faLock,
	faUsersCog,
	faDatabase,
	faQuestion
);
Vue.component("font-awesome-icon", FontAwesomeIcon);

// vue config
Vue.config.productionTip = false;

// plugins
Vue.use(vmodal, { dialog: true });
Vue.use(notifications);
Vue.use(clipboard);
Vue.use(vueNumeralFilterInstaller, { locale: "en-gb" });
Vue.use(browserDetect);

// formatting
Vue.filter("formatDateTime", (dateTime) => {
	return moment(String(dateTime)).format(config.dateTimeFormat);
});

Vue.filter("formatTime", (dateTime) => {
	return moment(String(dateTime)).format(config.timeFormat);
});

Vue.filter("formatDateTimeExact", (dateTime) => {
	return moment(String(dateTime)).format(config.dateTimeExactFormat);
});

Vue.filter("stringLimit", (string, size) => {
	if (!string) {
		return "";
	}
	string = string.toString();
	if (string.length <= size) {
		return string;
	}
	return string.substr(0, size);
});

Vue.filter("stringLimitElipses", (string, size) => {
	if (!string) {
		return "";
	}
	string = string.toString();
	if (string.length <= size) {
		return string;
	}
	return string.substr(0, size) + "...";
});

Vue.filter("boolToText", (value) => {
	return value ? "Yes" : "No";
});

Vue.filter("boolToTextShort", (value) => {
	return value ? "Y" : "N";
});

new Vue({
	router,
	store,
	render: (h) => h(App),
}).$mount("#app");
