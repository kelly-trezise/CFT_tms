import { ObjectID } from "bson";

export const config = {
	dateTimeFormat: "DD/MM/YYYY HH:mm",
	dateTimeExactFormat: "DD/MM/YYYY HH:mm:ss",
	dateFormat: "DD/MM/YYYY",
	timeFormat: "HH:mm:ss",
	notificationDuration: 5000,
};

export const defaults = {
	targets: [
		{
			shapes: [
				"L_0_sharp.png",
				"L_90_sharp.png",
				"L_180_sharp.png",
				"L_270_sharp.png",
			],
			isNTarget: 1, // all shapes are targets
			withholdResponseFor: 0, // no responses withheld
			relationship: false,
			relationshipRule: {
				not: false,
				position: "before",
				shapes: [],
				proportion: 50,
			},
			proportion: 20,
			tempId: new ObjectID(),
		},
	],
	nearDistractors: [
		"X_0_sharp.png",
		"T_0_sharp.png",
		"T_90_sharp.png",
		"T_180_sharp.png",
		"T_270_sharp.png",
		"I_0_sharp.png",
		"I_90_sharp.png",
		"O_0_sharp.png",
		"O_90_sharp.png",
	],
	farDistractors: [
		"X_0_round.png",
		"T_0_round.png",
		"T_90_round.png",
		"T_180_round.png",
		"T_270_round.png",
		"L_0_round.png",
		"L_90_round.png",
		"L_180_round.png",
		"L_270_round.png",
		"I_0_round.png",
		"I_90_round.png",
		"O_0_round.png",
		"O_90_round.png",
		"O_180_round.png",
	],
	firstDemoTargets: [
		"L_0_sharp.png",
		"L_90_sharp.png",
		"L_180_sharp.png",
		"L_270_sharp.png",
	],
	secondDemoTargets: [
		"T_0_sharp.png",
		"T_90_sharp.png",
		"T_180_sharp.png",
		"T_270_sharp.png",
	],
};
