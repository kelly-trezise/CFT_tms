import lodash from "lodash";
import { ObjectID } from "bson";

const state = {
	adaptiveRuleList: [],
};

const getters = {
	getAdaptiveRuleList: (state) => {
		return state.adaptiveRuleList;
	},
};

const actions = {
	setAdaptiveRuleList({ commit }, adaptiveRuleList) {
		commit("setAdaptiveRules", adaptiveRuleList);
	},
	addAdaptiveRule({ commit }, adaptiveRule) {
		commit("addAdaptiveRule", adaptiveRule);
	},
	updateAdaptiveRule({ commit }, adaptiveRule) {
		commit("updateAdaptiveRule", adaptiveRule);
	},
	duplicateAdaptiveRule({ commit }, adaptiveRule) {
		commit("duplicateAdaptiveRule", adaptiveRule);
	},
	deleteAdaptiveRule({ commit }, adaptiveRule) {
		commit("deleteAdaptiveRule", adaptiveRule);
	},
};

const mutations = {
	setAdaptiveRules: (state, adaptiveRules) =>
		(state.adaptiveRuleList = adaptiveRules),
	addAdaptiveRule: (state, adaptiveRule) => {
		adaptiveRule.tempId = new ObjectID().toString();
		state.adaptiveRuleList.push(adaptiveRule);
		console.log("New adaptive rule added.");
	},
	updateAdaptiveRule: (state, adaptiveRule) => {
		const adaptiveRuleToUpdate = state.adaptiveRuleList.find(
			(t) =>
				t._id === adaptiveRule._id ||
				(adaptiveRule.tempId && t.tempId === adaptiveRule.tempId)
		);
		if (adaptiveRuleToUpdate) {
			const index = state.adaptiveRuleList.indexOf(adaptiveRuleToUpdate);
			if (index > -1) {
				state.adaptiveRuleList.splice(index, 1, adaptiveRule);
				console.log("Adaptive rule updated.");
			} else {
				console.error("Adaptive rule update failed.");
			}
		} else {
			console.error("Adaptive rule not found.");
		}
	},
	duplicateAdaptiveRule: (state, adaptiveRule) => {
		const index = state.adaptiveRuleList.indexOf(adaptiveRule);
		const dupAdaptiveRule = lodash.cloneDeep(adaptiveRule);
		delete dupAdaptiveRule._id;
		dupAdaptiveRule.tempId = new ObjectID().toString();
		state.adaptiveRuleList.splice(index + 1, 0, dupAdaptiveRule);
		console.log("Adaptive rule duplicated.");
	},
	deleteAdaptiveRule: (state, adaptiveRule) => {
		const index = state.adaptiveRuleList.indexOf(adaptiveRule);
		if (index !== -1) {
			state.adaptiveRuleList.splice(index, 1);
			console.log("Adaptive rule deleted.");
		}
	},
};

export default {
	state,
	getters,
	actions,
	mutations,
};
