import { ObjectID } from "bson";

const state = {
	targetList: [],
};

const getters = {
	getTargetList: (state) => {
		return state.targetList;
	},
};

const actions = {
	setTargetList({ commit }, targetList) {
		commit("setTargets", targetList.targetList);
	},
	addTarget({ commit }, target) {
		commit("addTarget", target);
	},
	updateTarget({ commit }, target) {
		commit("updateTarget", target);
	},
	deleteTarget({ commit }, target) {
		commit("deleteTarget", target);
	},
};

const mutations = {
	setTargets: (state, targets) => (state.targetList = targets),
	addTarget: (state, target) => {
		target.tempId = new ObjectID().toString();
		if (state.targetList.length === 0) {
			target.relationship = JSON.parse(target.relationship);
			target.relationshipRule.not = JSON.parse(
				target.relationshipRule.not
			);
		} else {
			state.targetList.forEach((target) => {
				target.relationship = false;
			});
		}
		state.targetList.push(target);
		console.log("New target added.");
	},
	updateTarget: (state, target) => {
		const targetToUpdate = state.targetList.find(
			(t) =>
				(t._id && t._id === target._id) ||
				(!t._id && t.tempId === target.tempId)
		);
		if (targetToUpdate) {
			const index = state.targetList.indexOf(targetToUpdate);
			if (index > -1) {
				state.targetList.splice(index, 1, target);
				console.log("Target updated.");
			} else {
				console.error("Target update failed.");
			}
		} else {
			console.error("Target not found.");
		}
	},
	deleteTarget: (state, target) => {
		const index = state.targetList.indexOf(target);
		if (index !== -1) {
			state.targetList.splice(index, 1);
			console.log("Target deleted.");
		}
	},
};

export default {
	state,
	getters,
	actions,
	mutations,
};
