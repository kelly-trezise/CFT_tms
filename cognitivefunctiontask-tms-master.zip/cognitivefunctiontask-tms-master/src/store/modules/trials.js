import lodash from "lodash";
import { ObjectID } from "bson";

const state = {
	trialList: [],
};

const getters = {
	getTrialList: (state) => {
		return state.trialList;
	},
};

const actions = {
	setTrialList({ commit }, trialList) {
		commit("setTrials", trialList);
	},
	addTrial({ commit }, trial) {
		commit("addTrial", trial);
	},
	updateTrial({ commit }, trial) {
		commit("updateTrial", trial);
	},
	duplicateTrial({ commit }, trial) {
		commit("duplicateTrial", trial);
	},
	deleteTrial({ commit }, trial) {
		commit("deleteTrial", trial);
	},
};

const mutations = {
	setTrials: (state, trials) => (state.trialList = trials),
	addTrial: (state, trial) => {
		trial.tempId = new ObjectID().toString();
		state.trialList.push(trial);
		console.log("New trial added.");
	},
	updateTrial: (state, trial) => {
		const trialToUpdate = state.trialList.find(
			(t) =>
				(trial._id && t._id === trial._id) ||
				(trial.tempId && t.tempId === trial.tempId)
		);
		if (trialToUpdate) {
			const index = state.trialList.indexOf(trialToUpdate);
			if (index > -1) {
				state.trialList.splice(index, 1, trial);
				console.log("Trial updated.");
			} else {
				console.error("Trial update failed.");
			}
		} else {
			console.error("Trial not found.");
		}
	},
	duplicateTrial: (state, trial) => {
		const index = state.trialList.indexOf(trial);
		const dupTrial = lodash.cloneDeep(trial);
		delete dupTrial._id;
		dupTrial.tempId = new ObjectID().toString();
		state.trialList.splice(index + 1, 0, dupTrial);
		console.log("Trial duplicated.");
	},
	deleteTrial: (state, trial) => {
		const index = state.trialList.indexOf(trial);
		if (index !== -1) {
			state.trialList.splice(index, 1);
			console.log("Trial deleted.");
		}
	},
};

export default {
	state,
	getters,
	actions,
	mutations,
};
