import axios from "axios";
import lodash from "lodash";
import NotificationService from "@/services/NotificationService";
import UserService from "@/services/UserService";
import { ObjectID } from "bson";

const notificationService = new NotificationService();
const userService = new UserService();

const state = {
	taskList: [],
};

const getters = {
	taskList: (state) => {
		return state.taskList.sort((task) => task.name);
	},
	getTask: (state) => (id) => {
		return state.taskList.find((task) => task._id === id);
	},
};

const actions = {
	async getTasks({ commit }) {
		const config = {
			headers: {
				Authorization: "Bearer " + userService.getJwt(),
			},
		};

		await axios
			.get(process.env.VUE_APP_API_URL + "/getTasks", config)
			.then((resp) => {
				commit("setTasks", resp.data);
			})
			.catch((error) => {
				notificationService.error(error);
			});
	},
	async addTask({ commit }, task) {
		const config = {
			headers: {
				Authorization: "Bearer " + userService.getJwt(),
			},
		};

		await axios
			.post(
				process.env.VUE_APP_API_URL + "/addTask",
				{
					task,
				},
				config
			)
			.then((resp) => {
				notificationService.success(
					`${resp.data.name} has been created.`
				);
				commit("addTask", resp.data);
			})
			.catch((error) => {
				notificationService.error(error);
			});
	},
	async updateTask({ commit }, task) {
		const config = {
			headers: {
				Authorization: "Bearer " + userService.getJwt(),
			},
		};

		await axios
			.put(
				process.env.VUE_APP_API_URL + "/updateTask",
				{
					task,
				},
				config
			)
			.then((resp) => {
				notificationService.success(
					`${resp.data.name} has been updated.`
				);
				commit("updateTask", resp.data);
			})
			.catch((error) => {
				notificationService.error(error);
			});
	},
	async duplicateTask({ commit }, task) {
		let duplicate = lodash.cloneDeep(task);
		duplicate.name = "Copy of " + task.name;
		duplicate._id = new ObjectID();
		duplicate.customUrl = null;
		duplicate.dateModified = null;

		const config = {
			headers: {
				Authorization: "Bearer " + userService.getJwt(),
			},
		};

		await axios
			.post(
				process.env.VUE_APP_API_URL + "/addTask",
				{
					task: duplicate,
				},
				config
			)
			.then((resp) => {
				notificationService.success(
					`${resp.data.name} has been created.`
				);
				resp.data.author = userService.getCurrentUserInfo().name;
				commit("addTask", resp.data);
			})
			.catch((error) => {
				notificationService.error(error);
			});
	},
	async deleteTask({ commit }, id) {
		const config = {
			headers: {
				Authorization: "Bearer " + userService.getJwt(),
			},
			data: {
				_id: id,
			},
		};

		await axios
			.delete(process.env.VUE_APP_API_URL + "/deleteTask", config)
			.then((resp) => {
				if (resp.data.name) {
					notificationService.success(
						`${resp.data.name} has been deleted.`
					);
					commit("deleteTask", resp.data._id);
				} else {
					notificationService.error("Task not deleted.");
				}
			})
			.catch((error) => {
				NotificationService.error(error);
			});
	},
};

const mutations = {
	setTasks: (state, tasks) => (state.taskList = tasks),
	addTask: (state, task) => {
		state.taskList.unshift(task);
	},
	updateTask: (state, updatedTask) => {
		const index = state.taskList.findIndex(
			(task) => task._id === updatedTask._id
		);
		if (index !== -1) {
			state.taskList.splice(index, 1, updatedTask);
		}
	},
	deleteTask: (state, deletedTaskId) => {
		state.taskList = state.taskList.filter(
			(task) => task._id !== deletedTaskId
		);
	},
};

export default {
	state,
	getters,
	actions,
	mutations,
};
