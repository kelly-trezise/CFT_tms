import axios from "axios";

import NotificationService from "@/services/NotificationService";
const notificationService = new NotificationService();

import UserService from "@/services/UserService";
const userService = new UserService();

const state = {
	userList: [],
};

const getters = {
	userList: (state) => {
		return state.userList.sort((user) => user.email);
	},
	getUser: (state) => (id) => {
		return state.userList.find((user) => user._id === id);
	},
};

const actions = {
	async getUsers({ commit }) {
		const config = {
			headers: {
				Authorization: "Bearer " + userService.getJwt(),
			},
		};

		await axios
			.get(process.env.VUE_APP_API_URL + "/getUsers", config)
			.then((resp) => {
				commit("setUsers", resp.data);
			})
			.catch((error) => {
				notificationService.error(error);
			});
	},
	async addUser({ commit }, user) {
		const config = {
			headers: {
				Authorization: "Bearer " + userService.getJwt(),
			},
		};

		await axios
			.post(
				process.env.VUE_APP_API_URL + "/addUser",
				{
					user,
				},
				config
			)
			.then((resp) => {
				if (resp.data.error) {
					notificationService.error(`${resp.data.error}`);
				} else {
					notificationService.success(
						`${resp.data.name} has been created.`
					);
					commit("addUser", resp.data);
				}
			})
			.catch((error) => {
				notificationService.error(error);
			});
	},
	async updateUser({ commit }, user) {
		const config = {
			headers: {
				Authorization: "Bearer " + userService.getJwt(),
			},
		};

		await axios
			.put(
				process.env.VUE_APP_API_URL + "/updateUser",
				{
					user,
				},
				config
			)
			.then((resp) => {
				notificationService.success(
					`${resp.data.name} has been updated.`
				);
				commit("updateUser", resp.data);
			})
			.catch((error) => {
				notificationService.error(error);
			});
	},
	async deleteUser({ commit }, id) {
		const config = {
			headers: {
				Authorization: "Bearer " + userService.getJwt(),
			},
			data: {
				_id: id,
			},
		};

		await axios
			.delete(process.env.VUE_APP_API_URL + "/deleteUser", config)
			.then((resp) => {
				if (resp.data.name) {
					notificationService.success(
						`${resp.data.name} has been deleted.`
					);
					commit("deleteUser", resp.data._id);
				} else {
					notificationService.error("User not deleted.");
				}
			})
			.catch((error) => {
				NotificationService.error(error);
			});
	},
};

const mutations = {
	setUsers: (state, users) => (state.userList = users),
	addUser: (state, user) => {
		state.userList.unshift(user);
	},
	updateUser: (state, updatedUser) => {
		const index = state.userList.findIndex(
			(user) => user._id === updatedUser._id
		);
		if (index !== -1) {
			state.userList.splice(index, 1, updatedUser);
		}
	},
	deleteUser: (state, deletedUserId) => {
		state.userList = state.userList.filter(
			(user) => user._id !== deletedUserId
		);
	},
};

export default {
	state,
	getters,
	actions,
	mutations,
};
