import Vue from "vue";
import Vuex from "vuex";
import tasks from "./modules/tasks";
import trials from "./modules/trials";
import targets from "./modules/targets";
import adaptiveRules from "./modules/adaptiveRules";
import users from "./modules/users";

Vue.use(Vuex);

export default new Vuex.Store({
	modules: {
		tasks,
		trials,
		targets,
		adaptiveRules,
		users,
	},
});
