import Vue from "vue";
import VueRouter from "vue-router";
import jwtDecode from "jwt-decode";

import Home from "@/views/Home.vue";
import Task from "@/views/Task.vue";
import Tests from "@/views/Tests.vue";
import Test from "@/views/Test.vue";
import Login from "@/views/Login.vue";
import Users from "@/views/Users.vue";
import User from "@/views/User.vue";
import About from "@/views/About.vue";
import NotFound from "@/views/NotFound.vue";

Vue.use(VueRouter);

import UserService from "@/services/UserService";
const userService = new UserService();

const routes = [
	{
		path: "/",
		name: "Home",
		component: Home,
		meta: {
			title: "Home | TMS",
			requiresAuth: true,
		},
	},
	{
		path: "/login",
		name: "Login",
		component: Login,
		meta: {
			title: "Login | TMS",
			guest: true,
		},
	},
	{
		path: "/task",
		name: "CreateTask",
		component: Task,
		meta: {
			title: "Create Task | TMS",
			requiresAuth: true,
		},
	},
	{
		path: "/task/:id",
		name: "EditTask",
		component: Task,
		meta: {
			title: "Edit Task | TMS",
			requiresAuth: true,
		},
	},
	{
		path: "/tests",
		name: "ViewTests",
		component: Tests,
		meta: {
			title: "View Data | TMS",
			requiresAuth: true,
		},
	},
	{
		path: "/test/:testId",
		name: "ViewTest",
		component: Test,
		meta: {
			title: "Test | TMS",
			requiresAuth: true,
		},
	},
	{
		path: "/users",
		name: "Users",
		component: Users,
		meta: {
			title: "Users | TMS",
			requiresAuth: true,
			admin: true,
		},
	},
	{
		path: "/user",
		name: "CreateUser",
		component: User,
		meta: {
			title: "Create User | TMS",
			requiresAuth: true,
			admin: true,
		},
	},
	{
		path: "/user/:id",
		name: "EditUser",
		component: User,
		meta: {
			title: "Edit User | TMS",
			requiresAuth: true,
			admin: true,
		},
	},
	{
		path: "/about",
		name: "About",
		component: About,
		meta: {
			title: "About | TMS",
			requiresAuth: true,
		},
	},
	{
		path: "*",
		component: NotFound,
		meta: {
			title: "404 Page Not Found | TMS",
			guest: true,
		},
	},
];

let router = new VueRouter({
	mode: "history",
	routes,
});

router.beforeEach((to, from, next) => {
	// set title
	document.title = to.meta.title;

	// authentication
	if (to.matched.some((route) => route.meta.requiresAuth)) {
		if (!userService.getJwt()) {
			next({
				path: "/login",
				params: { nextUrl: to.fullPath },
			});
		} else {
			const decodedJwt = jwtDecode(userService.getJwt());
			if (Date.now() >= decodedJwt.exp * 1000) {
				userService.logout();
				next({
					path: "/login",
					params: { nextUrl: to.fullPath },
				});
			} else {
				if (to.matched.some((route) => route.meta.admin)) {
					let user = userService.getCurrentUserInfo();
					if (!user.admin) {
						next({
							path: "/",
						});
					}
				}
				next();
			}
		}
	} else if (to.matched.some((route) => route.meta.guest)) {
		if (!userService.getJwt()) {
			next();
		} else {
			next({ name: "Home" });
		}
	} else {
		next();
	}
});

export default router;
