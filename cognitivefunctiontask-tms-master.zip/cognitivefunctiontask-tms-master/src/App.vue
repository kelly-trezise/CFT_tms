<template>
	<div id="app">
		<div id="content">
			<Header />
			<notifications
				group="alert"
				position="bottom left"
				data-cy="notification"
			/>
			<router-view />
			<v-dialog />
		</div>
		<Footer />
	</div>
</template>

<script>
	import Header from "./components/Header.vue";
	import Footer from "./components/Footer.vue";

	export default {
		name: "App",
		components: {
			Header,
			Footer,
		},
	};
</script>

<style lang="scss">
	@import url("https://fonts.googleapis.com/css2?family=Open+Sans&display=swap");

	.v--modal {
		font-family: "Open Sans", Avenir, Helvetica, Arial, sans-serif;
	}

	#app {
		display: flex;
		min-height: 100vh;
		flex-direction: column;
	}

	#content {
		flex: 1;
		font-family: "Open Sans", Avenir, Helvetica, Arial, sans-serif;
		margin-bottom: 30px;
	}
</style>
