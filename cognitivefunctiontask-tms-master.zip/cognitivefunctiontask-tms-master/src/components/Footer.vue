<template>
	<footer>
		<p>
			&copy; Cognitive Function Task {{ currentYear }}
			<br />
			Cognitive Function Task by
			<a href="http://kellytrezise.com/" target="_blank">Kelly Trezise</a>
			| Software Developed by
			<a href="https://simon-rose.co.uk/" target="_blank"
				>Simon Rose Software Development</a
			>
			<br />
			Build {{ version }}
		</p>
	</footer>
</template>

<script>
	export default {
		name: "Footer",
		computed: {
			currentYear() {
				return new Date().getFullYear();
			},
			version() {
				return process.env.APPLICATION_VERSION;
			},
		},
	};
</script>

<style lang="scss" scoped>
	footer {
		height: 90px;
		font-size: 14px;
		line-height: 30px;
		left: auto;
		right: auto;
		bottom: 0;
		background: #000;
		color: #fff;
		width: 100%;
		text-align: center;
		z-index: 10000; // over loading spinner
		font-family: "Open Sans", Avenir, Helvetica, Arial, sans-serif;

		a {
			color: #fff;
			text-decoration: none;
		}
	}
</style>
