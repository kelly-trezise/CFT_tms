<template>
	<div class="shapes-summary" data-cy="shapes">
		<div
			class="shape"
			v-for="(shape, i) in trimmedShapes"
			:key="i"
			:style="{
				'background-image': `url(${publicPath}img/shapes/${shape})`,
			}"
		></div>
		<div v-if="shapes && shapes.length > 4 && limit" class="more-shapes">
			+{{ shapes.length - 4 }}
		</div>
	</div>
</template>

<script>
	export default {
		name: "ShapesSummary",
		props: ["shapes", "limit"],
		data() {
			return {
				publicPath: process.env.BASE_URL,
			};
		},
		computed: {
			trimmedShapes() {
				if (this.limit) {
					return this.shapes.slice(0, 4);
				} else {
					return this.shapes;
				}
			},
		},
	};
</script>

<style lang="scss" scoped>
	.shapes-summary {
		.shape {
			background-size: contain;
			background-repeat: no-repeat;
			height: 38px;
			width: 38px;
			margin-top: 2px;
			margin-right: 3px;
			display: inline-block;
		}

		.more-shapes {
			display: inline-block;
			height: 55px;
			position: absolute;
		}
	}
</style>
