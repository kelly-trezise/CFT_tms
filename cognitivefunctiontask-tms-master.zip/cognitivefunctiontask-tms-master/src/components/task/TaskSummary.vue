<template>
	<div>
		<div class="grid-x test-info-row" v-if="task.description">
			<div class="cell medium-12 description">
				<span class="data-title">Description: </span
				>{{ task.description }}
			</div>
		</div>
		<div class="grid-x test-info-row">
			<div class="cell medium-4">
				<span class="data-title">Trial Order: </span
				>{{ task.trialOrder }}
			</div>
		</div>
		<div class="grid-x test-info-row">
			<div class="cell medium-4">
				<span class="data-title">Theme: </span>{{ task.theme }}
			</div>
		</div>
		<div class="grid-x grid-list-header">
			<div class="cell medium-2">
				Tutorial
			</div>
		</div>
		<div class="grid-x test-info-row">
			<div class="cell medium-6">
				<span class="data-title">Target Proportion: </span
				>{{ task.tutorialTargetProportion }}%
			</div>
			<div class="cell medium-6">
				<span class="data-title">Demo Cycle Speed: </span
				>{{ task.tutorialDemoCycleSpeed }}ms
			</div>
		</div>
		<div class="grid-x test-info-row">
			<div class="cell medium-6">
				<span class="data-title">Main Demo: </span>
				<ShapesSummary :shapes="task.firstDemoTargets" :limit="false" />
				{{ task.firstDemoScanningDirectionVertical }}
				{{ task.firstDemoScanningDirectionHorizontal }}
				{{ task.firstDemoScanningDirectionLineByLine | stringLimit(2) }}
			</div>
			<div class="cell medium-6">
				<span class="data-title">Secondary Demo: </span>
				<ShapesSummary
					:shapes="task.secondDemoTargets"
					:limit="false"
				/>
				{{ task.secondDemoScanningDirectionVertical }}
				{{ task.secondDemoScanningDirectionHorizontal }}
				{{
					task.secondDemoScanningDirectionLineByLine | stringLimit(2)
				}}
			</div>
		</div>
		<div
			v-if="
				task.postTutorialMessage &&
					task.postTutorialMessage.length > 0 &&
					task.trialOrder !== 'sequential'
			"
		>
			<div class="grid-x test-info-row">
				<span class="data-title">Pre Trials Message: </span>
			</div>
			<div class="grid-x test-info-row">
				<div class="cell medium-12">
					{{ task.postTutorialMessage }}
				</div>
			</div>
		</div>
		<div class="grid-x grid-list-header">
			<div class="cell medium-2">
				Trials
			</div>
		</div>
		<div class="grid-x grid-list-header">
			<div class="cell medium-1">
				<span class="data-title">Rows</span>
			</div>
			<div class="cell medium-1 tooltip">
				<span class="data-title">NPR</span>
				<span class="tooltip-text">Nodes Per Row</span>
			</div>
			<div class="cell medium-2">
				<span class="data-title">Time Limit (Show)</span>
			</div>
			<div class="cell medium-1">
				<span class="data-title">Trials</span>
			</div>
			<div class="cell medium-1 tooltip">
				<span class="data-title">SD</span>
				<span class="tooltip-text">Scanning Direction</span>
			</div>
			<div class="cell medium-3">
				<span class="data-title">Targets</span>
			</div>
			<div class="cell medium-1 tooltip">
				<span class="data-title">R</span>
				<span class="tooltip-text">Relationships</span>
			</div>
			<div class="cell medium-1 tooltip">
				<span class="data-title">TP</span>
				<span class="tooltip-text">Target Proportion</span>
			</div>
			<div class="cell medium-1 tooltip">
				<span class="data-title">NDP</span>
				<span class="tooltip-text">Near Distractor Proportion</span>
			</div>
		</div>
		<div
			class="grid-x grid-list-row selectable"
			v-for="trial in task.trials"
			@click="showTrialDetailsModal(trial)"
			:key="trial._id"
			data-cy="test-task-trial-summary"
		>
			<div class="cell medium-1">{{ trial.numRows }}</div>
			<div class="cell medium-1">
				{{ trial.numNodesPerRow }}
			</div>
			<div class="cell medium-2" v-if="trial.timeLimit">
				{{ trial.timeLimit }}s ({{ trial.showTimeLimit | boolToText }})
			</div>
			<div class="cell medium-2" v-if="!trial.timeLimit"></div>
			<div class="cell medium-1">
				{{ trial.numTrials }}
			</div>
			<div class="cell medium-1">
				{{ trial.scanningDirectionVertical }}
				{{ trial.scanningDirectionHorizontal }}
				{{ trial.scanningDirectionLineByLine | stringLimit(2) }}
			</div>
			<div class="cell medium-3">
				<ShapesSummary
					:shapes="getTrialTargetShapes(trial).slice(0, 4)"
					:limit="true"
				/>
			</div>
			<div class="cell medium-1">
				{{ getTrialRelationshipCount(trial) }}
			</div>
			<div class="cell medium-1">
				{{ getTrialTargetProportion(trial) }}%
			</div>
			<div class="cell medium-1">
				{{ trial.nearDistractorProportion }}%
			</div>
		</div>
		<modal
			name="trial-details"
			:adaptive="true"
			width="90%"
			height="auto"
			class="modal"
			:scrollable="true"
			data-cy="test-task-trial-details"
		>
			<div class="content">
				<div class="top-right">
					<button
						class="button close"
						@click="$modal.hide('trial-details')"
						data-cy="close-test-task-trial-summary"
					>
						<font-awesome-icon icon="times"></font-awesome-icon>
					</button>
				</div>
				<TaskTrialSummary
					:trial="trialToView"
					:order="task.trialOrder"
				/>
			</div>
		</modal>
	</div>
</template>

<script>
	import ShapesSummary from "@/components/ShapesSummary";
	import TaskTrialSummary from "@/components/task/TaskTrialSummary";

	export default {
		name: "TaskSummary",
		props: ["task"],
		components: {
			ShapesSummary,
			TaskTrialSummary,
		},
		data() {
			return {
				trialToView: null,
			};
		},
		methods: {
			getTrialTargetShapes(trial) {
				let shapes = [];
				trial.targets.forEach((element) => {
					shapes = shapes.concat(element.shapes);
				});
				return shapes;
			},
			getTrialTargetProportion(trial) {
				let proportion = 0;
				trial.targets.forEach((element) => {
					proportion += parseInt(element.proportion);
				});
				return proportion;
			},
			getTrialRelationshipCount(trial) {
				let relationships = 0;
				trial.targets.forEach((element) => {
					if (element.relationship) {
						relationships++;
					}
				});
				return relationships;
			},
			showTrialDetailsModal(trial) {
				this.trialToView = trial;
				this.$modal.show("trial-details");
			},
		},
	};
</script>

<style lang="scss" scoped>
	.test-info-row {
		padding: 10px;
	}

	.description {
		line-height: 2rem;
	}
</style>
