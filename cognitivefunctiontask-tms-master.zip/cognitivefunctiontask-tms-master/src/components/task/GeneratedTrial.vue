<template>
	<div>
		<TrialGrid
			:grid="grid"
			:padding="trial.padding"
			:showColours="showColours"
			v-if="grid.length > 0"
		/>
		<div id="key" class="grid-container" v-if="grid.length > 0">
			<div class="grid-x">
				<div class="cell medium-2">
					<input
						id="all"
						name="all"
						type="checkbox"
						v-model="showColours.all"
					/><label for="all">All</label>
				</div>
				<div class="cell medium-5">
					<input
						id="numbers"
						name="numbers"
						type="checkbox"
						v-model="showColours.numbers"
					/><label for="all">Overall Positions</label>
				</div>
			</div>
			<div class="grid-x">
				<div class="cell medium-2">
					<input
						id="target"
						name="target"
						type="checkbox"
						v-model="showColours.target"
					/><label for="target">Targets</label>
				</div>
				<div class="cell medium-3">
					<input
						id="not-nth-target"
						name="not-nth-target"
						type="checkbox"
						v-model="showColours.notNthTarget"
					/><label for="not-nth-target">Not Nth Targets</label>
				</div>
				<div class="cell medium-3">
					<input
						id="distractor-target"
						name="distractor-target"
						type="checkbox"
						v-model="showColours.distractorTarget"
					/><label for="distractor-target">Distractor Targets</label>
				</div>
				<div class="cell medium-3">
					<input
						id="is-relationship"
						name="is-relationship"
						type="checkbox"
						v-model="showColours.isRelationship"
					/><label for="is-relationship">Relationship Shapes</label>
				</div>
			</div>
			<div class="grid-x">
				<div class="cell medium-3">
					<input
						id="near-distractor"
						name="near-distractor"
						type="checkbox"
						v-model="showColours.nearDistractor"
					/><label for="near-distractor">Near Distractors</label>
				</div>
				<div class="cell medium-3">
					<input
						id="far-distractor"
						name="far-distractor"
						type="checkbox"
						v-model="showColours.farDistractor"
					/><label for="far-distractor">Far Distractors</label>
				</div>
				<div class="cell medium-3">
					<input
						id="withhold-response"
						name="withhold-response"
						type="checkbox"
						v-model="showColours.withholdResponse"
					/><label for="withhold-response">Withhold Response</label>
				</div>
			</div>
		</div>
		<div v-if="error">Something went wrong when generating the grid.</div>
	</div>
</template>

<script>
	import TrialGrid from "@/components/TrialGrid";

	import TrialGeneratorService from "@/services/TrialGeneratorService.js";

	const trialGeneratorService = new TrialGeneratorService();

	export default {
		name: "GeneratedTrial",
		props: ["trial"],
		components: {
			TrialGrid,
		},
		data() {
			return {
				showColours: {
					all: true,
					target: true,
					notNthTarget: true,
					distractorTarget: true,
					isRelationship: true,
					nearDistractor: true,
					farDistractor: true,
					withholdResponse: true,
					numbers: false,
				},
				error: false,
			};
		},
		methods: {
			setVerticalScanningDir(grid) {
				if (this.trial.scanningDirectionVertical === "tb") {
					return grid;
				} else if (this.trial.scanningDirectionVertical === "bt") {
					return grid.slice().reverse();
				}
			},
			setHorizontalScanningDir(row) {
				if (this.trial.scanningDirectionHorizontal === "lr") {
					return row;
				} else if (this.trial.scanningDirectionHorizontal === "rl") {
					return row.slice().reverse();
				}
			},
			setLineByLineScanningDir(grid) {
				if (this.trial.scanningDirectionLineByLine === "sd") {
					return grid;
				} else if (this.trial.scanningDirectionLineByLine === "snake") {
					for (let row = 0; row < grid.length; row++) {
						if ((row + 1) % 2 === 0) {
							grid[row] = grid[row].slice().reverse();
						}
					}
					return grid;
				}
			},
			generateGrid() {
				let grid = {
					grid: [],
				};
				try {
					if (
						this.trial.numRows > 1 ||
						this.trial.numNodesPerRow > 1
					) {
						grid = trialGeneratorService.generateGrid(this.trial);
					} else {
						grid = trialGeneratorService.generateSingleShapeGrid(
							this.trial
						);
					}
				} catch (error) {
					console.error(error);
					this.error = true;
				}
				return grid;
			},
		},
		computed: {
			grid() {
				let generatedTrial = this.generateGrid();
				let grid = [];

				if (generatedTrial) {
					grid = generatedTrial.grid;

					grid = this.setLineByLineScanningDir(grid);
					grid = this.setVerticalScanningDir(grid);
					for (let row = 0; row < grid.length; row++) {
						grid[row] = this.setHorizontalScanningDir(grid[row]);
					}
				}

				return grid;
			},
		},
	};
</script>

<style lang="scss" scoped>
	#key {
		margin-top: 10px;
	}

	label[for="target"] {
		background: $target;
	}
	label[for="not-nth-target"] {
		background: $notNthTarget;
	}
	label[for="distractor-target"] {
		background: $distractorTarget;
	}
	label[for="is-relationship"] {
		background: $isRelationship;
	}
	label[for="near-distractor"] {
		background: $nearDistractor;
	}
	label[for="far-distractor"] {
		background: $farDistractor;
	}
	label[for="withhold-response"] {
		background: white;
		filter: $withholdResponse;
	}
</style>
