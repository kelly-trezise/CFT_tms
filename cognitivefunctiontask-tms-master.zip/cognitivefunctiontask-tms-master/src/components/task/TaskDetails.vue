<template>
	<div class="grid-container" v-if="taskDetails">
		<div class="grid-x task-info" v-if="taskDetails.dateCreated">
			<div class="cell medium-7 large-offset-5">
				Created by: {{ taskDetails.author }} on
				{{ taskDetails.dateCreated | formatDateTime }}
			</div>
		</div>
		<div class="grid-x task-info bottom" v-if="taskDetails.dateModified">
			<div class="cell medium-7 large-offset-5">
				Last modified by: {{ taskDetails.modifier }} on
				{{ taskDetails.dateModified | formatDateTime }}
			</div>
		</div>
		<div class="grid-x">
			<div class="cell medium-3">
				<label for="name" class="data-title">Name</label>
				<input
					type="text"
					name="name"
					v-model="taskDetails.name"
					:class="{
						invalid:
							validation.nameError &&
							(taskDetails.name === '' || taskNameExists),
					}"
				/>
				<FormValidationError
					:error="validation.nameError"
					:showIf="taskDetails.name === '' || taskNameExists"
				/>
			</div>
			<div class="cell medium-3 large-offset-1">
				<label for="custom-url" class="data-title">Custom URL</label>
				<input
					type="text"
					name="custom-url"
					v-model="taskDetails.customUrl"
					:class="{
						invalid: validation.customUrlError && customUrlExists,
					}"
				/>
				<FormValidationError
					:error="validation.customUrlError"
					:showIf="customUrlExists"
				/>
			</div>
			<div class="cell medium-2 large-offset-1">
				<label for="locked" class="data-title">Lock For Edit</label>
				<select
					name="locked"
					v-model="taskDetails.lockForEdit"
					@change="showOrHidePermissionsButton"
				>
					<option value="true">Yes</option>
					<option value="false">No</option>
				</select>
			</div>
			<div class="cell medium-2">
				<button
					class="button permissions"
					@click="showPermissionsModal()"
					v-if="showPermissionsButton"
					data-cy="show-task-permissions"
				>
					Permissions
				</button>
			</div>
		</div>
		<div class="grid-x">
			<div class="cell medium-12">
				<label for="description" class="data-title">Description</label>
				<textarea
					name="description"
					v-model="taskDetails.description"
				/>
			</div>
		</div>
		<div class="grid-x">
			<div class="cell medium-3">
				<label for="trialOrder" class="data-title">Trial Order</label>
				<select
					name="trialOrder"
					v-model="taskDetails.trialOrder"
					@change="updateTempOrder"
				>
					<option value="sequential">Sequential</option>
					<option value="randomised">Randomised</option>
					<option value="alternate">Alternate</option>
				</select>
				<span data-tooltip title="View Example Trial Order">
					<button
						class="button view trial-order-preview"
						@click="trialOrderPreview()"
						data-cy="preview-trial-order"
					>
						<font-awesome-icon icon="eye"></font-awesome-icon>
					</button>
				</span>
			</div>
		</div>
		<div class="grid-x">
			<div class="cell medium-2">
				<label for="theme" class="data-title">Theme</label>
				<select v-model="taskDetails.theme">
					<option value="basic">Basic</option>
					<option value="superheroes">Superheroes</option>
				</select>
			</div>
		</div>
		<div class="grid-x">
			<div class="cell medium-3">
				<label for="theme" class="data-title">Tutorial</label>
			</div>
		</div>
		<div class="grid-x">
			<div class="cell medium-3">
				<label for="tutorialTargetProportion"
					>Target Proportion (%)</label
				>
				<input
					type="number"
					name="tutorialTargetProportion"
					v-model="taskDetails.tutorialTargetProportion"
					:class="{
						invalid:
							validation.tutorialTargetProportionError &&
							(!taskDetails.tutorialTargetProportion ||
								parseInt(
									taskDetails.tutorialTargetProportion
								) <= 0),
					}"
				/>
				<FormValidationError
					:error="validation.tutorialTargetProportionError"
					:showIf="
						!taskDetails.tutorialTargetProportion ||
							parseInt(taskDetails.tutorialTargetProportion) <= 0
					"
				/>
			</div>
			<div class="cell medium-3 large-offset-1">
				<label for="tutorialDemoCycleSpeed"
					>Demo Cycle Speed (ms)</label
				>
				<input
					type="number"
					name="tutorialDemoCycleSpeed"
					v-model="taskDetails.tutorialDemoCycleSpeed"
					:class="{
						invalid:
							validation.tutorialDemoCycleSpeedError &&
							(!taskDetails.tutorialDemoCycleSpeed ||
								parseInt(taskDetails.tutorialDemoCycleSpeed) <=
									0),
					}"
				/>
				<FormValidationError
					:error="validation.tutorialDemoCycleSpeedError"
					:showIf="
						!taskDetails.tutorialDemoCycleSpeed ||
							parseInt(taskDetails.tutorialDemoCycleSpeed) <= 0
					"
				/>
			</div>
		</div>
		<div class="grid-x sub-header">
			<div class="cell medium-4">Main Demo</div>
			<div class="cell medium-4 large-offset-2">
				Secondary Demo
			</div>
		</div>
		<div class="grid-x">
			<div class="cell medium-6">
				<ShapesSelect
					:shapes="taskDetails.firstDemoTargets"
					:config="{
						title: 'Targets',
						name: 'firstDemoTargets',
						label: 'targets',
					}"
					@update-shapes="updateTargets"
				/>
			</div>
			<div class="cell medium-6">
				<ShapesSelect
					:shapes="taskDetails.secondDemoTargets"
					:config="{
						title: 'Targets',
						name: 'secondDemoTargets',
						label: 'targets',
					}"
					@update-shapes="updateTargets"
				/>
			</div>
		</div>
		<div class="grid-x">
			<div class="cell medium-6 scanning-dir">
				<label for="scanningDirection">Scanning Direction </label>
				<select
					name="scanningDirection"
					v-model="taskDetails.firstDemoScanningDirectionVertical"
				>
					<option value="tb">Top to bottom</option>
					<option value="bt">Bottom to top</option>
				</select>
				<select
					name="scanningDirection"
					v-model="taskDetails.firstDemoScanningDirectionHorizontal"
				>
					<option value="lr">Left to right</option>
					<option value="rl">Right to left</option>
				</select>
				<select
					name="scanningDirection"
					v-model="taskDetails.firstDemoScanningDirectionLineByLine"
				>
					<option value="sd">Same direction</option>
					<option value="snake">Snake</option>
				</select>
			</div>
			<div class="cell medium-6 scanning-dir">
				<label for="scanningDirection">Scanning Direction </label>
				<select
					name="scanningDirection"
					v-model="taskDetails.secondDemoScanningDirectionVertical"
				>
					<option value="tb">Top to bottom</option>
					<option value="bt">Bottom to top</option>
				</select>
				<select
					name="scanningDirection"
					v-model="taskDetails.secondDemoScanningDirectionHorizontal"
				>
					<option value="lr">Left to right</option>
					<option value="rl">Right to left</option>
				</select>
				<select
					name="scanningDirection"
					v-model="taskDetails.secondDemoScanningDirectionLineByLine"
				>
					<option value="sd">Same direction</option>
					<option value="snake">Snake</option>
				</select>
			</div>
		</div>
		<div class="grid-x" v-if="taskDetails.trialOrder !== 'sequential'">
			<div class="cell medium-12">
				<label for="postTutorialMessage">Pre-Trials Message</label>
				<textarea
					name="postTutorialMessage"
					v-model="taskDetails.postTutorialMessage"
				/>
			</div>
		</div>
		<TrialList @toggle-is-editing="toggleIsEditing" :order="tempOrder" />
		<div class="grid-x grid-list-footer">
			<div class="cell medium-1 large-offset-11" v-if="!isEditing">
				<div class="buttons">
					<span data-tooltip title="Save Task">
						<button
							class="button save"
							@click="updateTaskClick()"
							data-cy="save-task"
						>
							<font-awesome-icon icon="save"></font-awesome-icon>
						</button>
					</span>
				</div>
			</div>
		</div>
		<modal
			name="trial-order-preview"
			:adaptive="true"
			width="80%"
			height="auto"
			class="modal"
			:scrollable="true"
			data-cy="trial-order-preview"
		>
			<div class="content">
				<div class="top-right">
					<button
						class="button close"
						@click="$modal.hide('trial-order-preview')"
						data-cy="close-trial-order-preview"
					>
						<font-awesome-icon icon="times"></font-awesome-icon>
					</button>
				</div>
				<GeneratedTrialList :trials="generatedTrials" />
			</div>
		</modal>
		<modal
			name="task-permissions"
			:adaptive="true"
			width="90%"
			height="auto"
			class="modal"
			:clickToClose="false"
			:scrollable="true"
			data-cy="task-permissions"
		>
			<div class="content">
				<div class="top-right">
					<span data-tooltip title="Close">
						<button
							class="button close"
							@click="$modal.hide('task-permissions')"
						>
							<font-awesome-icon icon="times"></font-awesome-icon>
						</button>
					</span>
				</div>
				<TaskPermissions
					:task="taskDetails"
					@update-task-permissions="updateTaskPermissions"
				/>
			</div>
		</modal>
	</div>
</template>

<script>
	import { mapActions, mapGetters } from "vuex";
	import router from "@/router";
	import TrialList from "@/components/trial/TrialList";
	import FormValidationError from "@/components/FormValidationError";
	import GeneratedTrialList from "@/components/task/GeneratedTrialList";
	import TaskPermissions from "@/components/task/TaskPermissions";
	import ShapesSelect from "@/components/ShapesSelect";

	import UserService from "@/services/UserService";
	import TrialGeneratorService from "@/services/TrialGeneratorService";

	const userService = new UserService();
	const trialGeneratorService = new TrialGeneratorService();

	export default {
		name: "TaskDetails",
		props: ["task"],
		components: {
			TrialList,
			FormValidationError,
			GeneratedTrialList,
			TaskPermissions,
			ShapesSelect,
		},
		data() {
			return {
				taskDetails: null,
				validation: {
					nameError: "",
					customUrlError: "",
					tutorialTargetsError: "",
					tutorialTargetProportionError: "",
					tutorialDemoCycleSpeedError: "",
				},
				generatedTrials: [],
				isEditing: false,
				showPermissionsButton: false,
				tempOrder: "sequential",
			};
		},
		methods: {
			...mapActions(["addTask", "updateTask", "setTrialList"]),
			...mapGetters(["getTrialList", "taskList"]),
			updateTaskClick() {
				const updatedTask = this.taskDetails;
				updatedTask.trials = this.getTrialList();
				// do validation
				if (this.validateForm(updatedTask)) {
					if (updatedTask._id) {
						updatedTask.lastModifierId = userService.getCurrentUserInfo()._id;
						this.updateTask(updatedTask);
					} else {
						this.addTask(updatedTask);
					}
					this.$emit("save-clicked");
					router.push({ name: "Home" });
				}
			},
			validateForm(task) {
				let isValid = true;

				if (task.name === "") {
					this.validation.nameError = "Name is required";
					isValid = false;
				}

				if (this.taskNameExists) {
					this.validation.nameError =
						"A task already exists with that name";
					isValid = false;
				}

				if (this.customUrlExists) {
					this.validation.customUrlError =
						"A task already exists with that custom url";
					isValid = false;
				}

				if (!task.tutorialTargetProportion) {
					this.validation.tutorialTargetProportionError =
						"Required field";
					isValid = false;
				}

				if (parseInt(task.tutorialTargetProportion) <= 0) {
					this.validation.tutorialTargetProportionError =
						"Must be 1 or more";
					isValid = false;
				}

				if (!task.tutorialDemoCycleSpeed) {
					this.validation.tutorialDemoCycleSpeedError =
						"Required field";
					isValid = false;
				}

				if (parseInt(task.tutorialDemoCycleSpeed) <= 0) {
					this.validation.tutorialDemoCycleSpeedError =
						"Must be 1 or more";
					isValid = false;
				}

				return isValid;
			},
			trialOrderPreview() {
				this.generatedTrials = trialGeneratorService.generateTrialOrder(
					this.getTrialList(),
					this.taskDetails.trialOrder
				);

				this.$modal.show("trial-order-preview");
			},
			toggleIsEditing(editing) {
				this.isEditing = editing;
			},
			showOrHidePermissionsButton(ev) {
				if (JSON.parse(ev.target.value) === true) {
					this.showPermissionsButton = true;
				} else {
					this.showPermissionsButton = false;
				}
			},
			showPermissionsModal() {
				this.$modal.show("task-permissions");
			},
			updateTaskPermissions(userList) {
				this.taskDetails.editPermissions = userList;
				this.$modal.hide("task-permissions");
			},
			updateTargets(targets, type) {
				this.taskDetails[type] = targets;
			},
			updateTempOrder(ev) {
				this.tempOrder = ev.target.value;
			},
		},
		computed: {
			...mapGetters(["userList"]),
			taskNameExists() {
				return (
					this.taskList().filter(
						(t) =>
							t.name === this.taskDetails.name &&
							t._id !== this.taskDetails._id
					).length > 0
				);
			},
			customUrlExists() {
				return (
					this.taskList().filter(
						(t) =>
							t.customUrl &&
							t.customUrl.length > 0 &&
							t.customUrl === this.taskDetails.customUrl &&
							t._id !== this.taskDetails._id
					).length > 0
				);
			},
		},
		created() {
			// handle creating and editing tasks
			if (this.task) {
				this.setTrialList(this.task.trials);
				this.showPermissionsButton = JSON.parse(this.task.lockForEdit);
				this.taskDetails = this.task;
				// use temp order to show/hide sequential only task options
				this.tempOrder = this.task.trialOrder;
			}
		},
	};
</script>

<style lang="scss" scoped>
	@include foundation-xy-grid-classes;
	@include foundation-forms;
	@include foundation-button;

	.task-info {
		height: 45px;
		line-height: 45px;
		text-align: right;
		border-top: $border;

		&.bottom {
			border-bottom: $border;
			margin-bottom: 10px;
		}
	}

	.button.permissions {
		margin-top: 25px;
		float: right;
	}

	.button.trial-order-preview {
		margin: 0 10px;
		border-radius: 25px !important;
		min-width: 42px !important;
		min-height: 41px !important;
		padding: 12px !important;
		background: #ff9d00;
	}

	.sub-header {
		font-style: italic;
	}
</style>
