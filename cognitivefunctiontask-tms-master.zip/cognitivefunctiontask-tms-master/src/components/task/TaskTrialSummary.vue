<template>
	<div class="grid-container" id="trial-details">
		<div class="grid-x header">
			<div class="cell medium-3">
				Rows
			</div>
			<div class="cell medium-3">
				Nodes Per Row
			</div>
			<div class="cell medium-3" v-if="trial.timeLimit">
				Time Limit (Show)
			</div>
			<div class="cell medium-3">
				Number of Trials
			</div>
		</div>
		<div class="grid-x info" data-cy="test-task-trial-grid">
			<div class="cell medium-3">
				{{ trial.numRows }}
			</div>
			<div class="cell medium-3">
				{{ trial.numNodesPerRow }}
			</div>
			<div class="cell medium-4" v-if="trial.timeLimit">
				{{ trial.timeLimit }}s ({{ trial.showTimeLimit | boolToText }})
			</div>
			<div class="cell medium-4">
				{{ trial.numTrials }}
			</div>
		</div>
		<div class="grid-x header">
			<div class="cell medium-4">
				Next Trial When All Targets Selected
			</div>
			<div class="cell medium-4">
				Show 'Next' Button
			</div>
			<div class="cell medium-4">
				Trial Gap
			</div>
		</div>
		<div class="grid-x info">
			<div class="cell medium-4">
				{{ trial.nextTrialWhenAllTargetsSelected | boolToText }}
			</div>
			<div class="cell medium-4">
				{{ trial.showNextButton | boolToText }}
			</div>
			<div class="cell medium-4">{{ trial.trialGap }}ms</div>
		</div>
		<div class="grid-x header">
			<div class="cell medium-4">
				Show Trial Rules/Practice Trial
			</div>
			<div class="cell medium-4">
				Practice Trial Rows
			</div>
			<div class="cell medium-4">
				Practice Trial Nodes Per Row
			</div>
		</div>
		<div class="grid-x info">
			<div class="cell medium-4">
				{{ trial.showTrialRules | boolToText }}
			</div>
			<div class="cell medium-4">
				{{ trial.practiceTrialNumRows }}
			</div>
			<div class="cell medium-4">
				{{ trial.practiceTrialNumNodesPerRow }}
			</div>
		</div>
		<div class="grid-x header">
			<div class="cell medium-4">
				Scanning Direction
			</div>
		</div>
		<div class="grid-x info" data-cy="test-task-trial-scanning">
			<div class="cell medium-5">
				{{ formattedScanningDirection }}
			</div>
		</div>
		<div class="grid-x header">
			<div class="cell medium-4">
				Targets
			</div>
		</div>
		<div
			v-for="(target, index) in trial.targets"
			:key="target._id"
			data-cy="test-task-trial-targets"
		>
			<div class="grid-x info sub-header">
				<div class="cell medium-1">
					{{ index + 1 }}
				</div>
				<div class="cell medium-5">
					Shapes
				</div>
				<div class="cell medium-2">
					All targets?
				</div>
				<div class="cell medium-2">
					Wh response?
				</div>
				<div class="cell medium-2">
					Proportion
				</div>
			</div>
			<div class="grid-x info" data-cy="test-task-trial-target">
				<div class="cell medium-5 large-offset-1">
					<ShapesSummary :shapes="target.shapes" :limit="false" />
				</div>
				<div class="cell medium-2">
					{{ convertAllOrEveryN(target, "isNTarget") }}
					<span v-if="target.isNTarget > 1">
						{{ target.isNTarget | ordinal }}
					</span>
				</div>
				<div class="cell medium-2">
					{{ convertAllOrEveryN(target, "withholdResponseFor") }}
					<span v-if="target.withholdResponseFor > 1">
						{{ target.withholdResponseFor | ordinal }}
					</span>
				</div>
				<div class="cell medium-2">{{ target.proportion }}%</div>
			</div>
			<div class="relationship" v-if="target.relationship">
				<div class="grid-x info sub-header">
					<div class="cell medium-3 large-offset-1">
						Relationship
					</div>
				</div>
				<div class="grid-x info">
					<div class="cell medium-2 large-offset-1">
						{{ formatRelationshipString(target.relationshipRule) }}
					</div>
					<div class="cell medium-7">
						<ShapesSummary
							:shapes="target.relationshipRule.shapes"
							:limit="false"
						/>
					</div>
					<div
						class="cell medium-2"
						v-if="!target.relationshipRule.not"
					>
						{{ target.relationshipRule.proportion }}%
					</div>
				</div>
			</div>
		</div>
		<div class="grid-x header">
			<div class="cell medium-10">
				Near Distractors
			</div>
			<div class="cell medium-2">
				Proportion
			</div>
		</div>
		<div class="grid-x info">
			<div class="cell medium-10">
				<div class="targets-summary">
					<ShapesSummary
						:shapes="trial.nearDistractors"
						:limit="false"
					/>
				</div>
			</div>
			<div class="cell medium-2">
				{{ trial.nearDistractorProportion }}%
			</div>
		</div>
		<div class="grid-x header">
			<div class="cell medium-10">
				Far Distractors
			</div>
		</div>
		<div class="grid-x info">
			<div class="cell medium-10">
				<ShapesSummary :shapes="trial.farDistractors" :limit="false" />
			</div>
			<div class="cell medium-2">{{ farDistractorProportion }}%</div>
		</div>
		<div
			class="adaptive-rules"
			v-if="order === 'sequential' && trial.adaptive"
		>
			<div class="grid-x header">
				<div class="cell medium-10">
					Adaptive Rules
				</div>
			</div>
			<div
				class="grid-x info sub-header"
				v-if="order === 'sequential' && trial.adaptive"
			>
				<div class="cell medium-2 large-offset-1">
					After
				</div>
				<div class="cell medium-3">
					Condition
				</div>
				<div class="cell medium-2">
					Change
				</div>
				<div class="cell medium-1">By</div>
				<div class="cell medium-2">Cont.</div>
			</div>
			<div v-for="(rule, index) in trial.adaptiveRules" :key="rule._id">
				<div class="grid-x info">
					<div class="cell medium-1">
						<strong>{{ index + 1 }}</strong>
					</div>
					<div class="cell medium-2">
						{{ rule.afterNTrials }} trial(s)
					</div>
					<div class="cell medium-3">
						{{ formatRuleCondition(rule) }}
					</div>
					<div class="cell medium-2">
						{{ rule.updateVariable }}
					</div>
					<div class="cell medium-1">
						{{ rule.updateVariablePercentage }}%
					</div>
					<div class="cell medium-2">
						{{ rule.continuous | boolToText }}
					</div>
				</div>
			</div>
		</div>
		<div class="grid-x header">
			<div class="cell medium-10">
				Messages
			</div>
		</div>
		<div class="grid-x info">
			<div class="cell medium-12">
				<span class="data-title">Pre Trial:</span>
			</div>
		</div>
		<div class="grid-x">
			<div class="cell medium-12">
				{{ trial.preTrialMessage }}
			</div>
		</div>
		<div class="grid-x info">
			<div class="cell medium-12">
				<span class="data-title">Post Trial:</span>
			</div>
		</div>
		<div class="grid-x">
			<div class="cell medium-12">
				{{ trial.postTrialMessage }}
			</div>
		</div>
	</div>
</template>

<script>
	import ShapesSummary from "@/components/ShapesSummary";

	export default {
		name: "TaskTrialSummary",
		props: ["trial", "order"],
		components: {
			ShapesSummary,
		},
		methods: {
			convertAllOrEveryN(target, option) {
				if (parseInt(target[option]) > 0) {
					if (parseInt(target[option]) === 1) {
						return "All";
					} else {
						return "Every";
					}
				} else {
					return "None";
				}
			},
			formatRelationshipString(relationship) {
				let is = "Is ";
				if (relationship.not) {
					is = "Is not ";
				}

				return `${is} a target ${relationship.position} `;
			},
			formatRuleCondition(rule) {
				let conditionString = "";

				conditionString += rule.averageStatistic;

				if (rule.averageStatisticComparison === "lessThan") {
					conditionString += " < ";
				} else if (rule.averageStatisticComparison === "greaterThan") {
					conditionString += " > ";
				}

				conditionString += `${rule.averageStatisticPercentage}%`;

				return conditionString;
			},
		},
		computed: {
			formattedScanningDirection() {
				let scanningDir = "";

				if (this.trial.scanningDirectionVertical === "tb") {
					scanningDir += "Top to bottom";
				} else if (this.trial.scanningDirectionVertical === "bt") {
					scanningDir += "Bottom to top";
				}

				if (this.trial.scanningDirectionHorizontal === "lr") {
					scanningDir += ", left to right";
				} else if (this.trial.scanningDirectionHorizontal === "rl") {
					scanningDir += ", right to left";
				}

				if (this.trial.scanningDirectionLineByLine === "sd") {
					scanningDir += ", same direction";
				} else if (this.trial.scanningDirectionLineByLine === "snake") {
					scanningDir += ", snake";
				}

				return scanningDir;
			},
			farDistractorProportion() {
				let targetProportion = 0;
				this.trial.targets.forEach((element) => {
					targetProportion += parseInt(element.proportion);
				});

				return (
					100 - targetProportion - this.trial.nearDistractorProportion
				);
			},
		},
	};
</script>

<style lang="scss" scoped>
	#trial-details {
		padding: 5px;

		.header {
			height: 45px;
			line-height: 45px;
			border-bottom: $border;
			font-weight: bold;
		}

		.info {
			height: 45px;
			line-height: 45px;
		}

		.sub-header {
			font-weight: bold;
		}
	}
</style>
