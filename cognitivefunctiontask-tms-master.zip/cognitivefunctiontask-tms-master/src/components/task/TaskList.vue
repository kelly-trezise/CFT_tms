<template>
	<div class="grid-container">
		<div class="grid-x">
			<div class="cell medium-3">
				<input
					type="text"
					name="search"
					placeholder="Search..."
					v-model="searchQuery"
					data-cy="task-search"
				/>
			</div>
			<div class="cell medium-5 large-offset-4">
				<div class="navigate">
					<span data-tooltip title="View Tests">
						<router-link
							:to="{ name: 'ViewTests' }"
							class="button tests"
							><font-awesome-icon
								icon="database"
							></font-awesome-icon>
							<span class="text">Data</span>
						</router-link>
					</span>
					<span data-tooltip title="View Users">
						<router-link
							:to="{ name: 'Users' }"
							class="button users"
							data-cy="view-users"
							v-if="isAdmin"
							><font-awesome-icon
								icon="users-cog"
							></font-awesome-icon>
							<span class="text">Users</span></router-link
						>
					</span>
					<span data-tooltip title="About">
						<router-link :to="{ name: 'About' }" class="button"
							><font-awesome-icon
								icon="question"
							></font-awesome-icon>
							<span class="text">About</span>
						</router-link>
					</span>
				</div>
			</div>
		</div>
		<div class="grid-x grid-list-header sortable">
			<div
				class="cell medium-3"
				@click="sortBy('name')"
				:class="setSortingIconClass('name')"
			>
				Name
			</div>
			<div
				class="cell medium-2"
				@click="sortBy('author')"
				:class="setSortingIconClass('author')"
			>
				Author
			</div>
			<div
				class="cell medium-2"
				@click="sortBy('dateCreated')"
				:class="setSortingIconClass('dateCreated')"
			>
				Date Created
			</div>
			<div
				class="cell medium-2"
				@click="sortBy('dateModified')"
				:class="setSortingIconClass('dateModified')"
			>
				Date Modified
			</div>
		</div>
		<TaskListItem
			v-for="(task, i) in orderedAndSearchedTaskList"
			:key="`${i}-${task._id}`"
			:task="task"
			@view-task="viewTask"
		/>
		<div class="grid-x grid-list-footer ">
			<div class="cell medium-2 large-offset-10">
				<div class="buttons">
					<span data-tooltip title="Import Task">
						<label
							for="file-input"
							class="button import"
							type="file"
						>
							<font-awesome-icon
								icon="file-import"
							></font-awesome-icon>
						</label>
						<input
							type="file"
							id="file-input"
							name="file-input"
							accept="json"
							data-cy="task-import"
							@change="uploadTask($event.target.files)"
						/>
					</span>
					<span data-tooltip title="Create Task">
						<router-link
							:to="{ name: 'CreateTask' }"
							class="button add"
							data-cy="create-task"
							><font-awesome-icon icon="plus"></font-awesome-icon
						></router-link>
					</span>
				</div>
			</div>
		</div>
		<modal
			name="view-task"
			:adaptive="true"
			width="90%"
			height="auto"
			:scrollable="true"
			class="modal"
		>
			<div class="content" v-if="task">
				<div class="top-right">
					<button
						class="button close"
						@click="$modal.hide('view-task')"
						data-cy="close-task"
					>
						<font-awesome-icon icon="times"></font-awesome-icon>
					</button>
				</div>
				<div class="grid-container">
					<div class="grid-x grid-list-title" data-cy="task-name">
						{{ task.name }}
					</div>
					<div class="url-wrapper">
						<div class="url" data-cy="task-url">
							{{ fullUrl }}
						</div>
						<div class="buttons">
							<span data-tooltip title="Copy Link">
								<button
									class="button"
									v-clipboard="fullUrl"
									v-clipboard:success="
										clipboardSuccessHandler
									"
									v-clipboard:error="clipboardErrorHandler"
									data-cy="copy-task-url"
								>
									Copy To Clipboard
								</button>
							</span>
						</div>
					</div>
					<div class="grid-x grid-list-header">
						<div class="cell medium-2">
							Details
						</div>
					</div>
					<TaskSummary :task="task" />
				</div>
			</div>
		</modal>
	</div>
</template>

<script>
	import { mapGetters, mapActions } from "vuex";
	import lodash from "lodash";
	import { ObjectID } from "bson";

	import TaskListItem from "@/components/task/TaskListItem.vue";
	import TaskSummary from "@/components/task/TaskSummary.vue";

	import UserService from "@/services/UserService";
	const userService = new UserService();

	import NotificationService from "@/services/NotificationService";
	const notificationService = new NotificationService();

	export default {
		name: "TaskList",
		components: {
			TaskListItem,
			TaskSummary,
		},
		data() {
			return {
				fullUrl: "",
				task: null,
				sortByColumn: "dateCreated",
				sortByOrder: "asc",
				searchQuery: "",
			};
		},
		methods: {
			...mapActions(["getTasks", "addTask", "updateTask"]),
			viewTask(task, fullUrl) {
				this.fullUrl = fullUrl;
				this.task = task;
				this.$modal.show("view-task");
			},
			clipboardSuccessHandler() {
				notificationService.success("Url copied.");
				this.$modal.hide("view-task");
			},
			clipboardErrorHandler() {
				notificationService.error("Copy failed.");
				this.$modal.hide("view-task");
			},
			sortBy(column) {
				this.sortByColumn = column;
				if (this.sortByOrder === "asc") {
					this.sortByOrder = "desc";
				} else {
					this.sortByOrder = "asc";
				}
			},
			setSortingIconClass(column) {
				return {
					asc:
						this.sortByColumn === column &&
						this.sortByOrder === "asc",
					desc:
						this.sortByColumn === column &&
						this.sortByOrder === "desc",
				};
			},
			uploadTask(files) {
				let reader = new FileReader();
				reader.onload = (event) => {
					// convert to JS object
					let task = null;
					try {
						task = JSON.parse(event.target.result);
					} catch (error) {
						notificationService.error("Malformed JSON.");
					}

					task._id = new ObjectID();
					task.dateModified = null;

					const sameNameTasks = this.taskList.filter(
						(t) => t.name === task.name
					);

					if (sameNameTasks.length > 0) {
						let count = 1;
						for (let i = 0; i < 100; i++) {
							if (
								this.taskList.filter(
									(t) => t.name === `${task.name} (${i})`
								).length > 0
							) {
								count++;
							}
						}

						task.name = `${task.name} (${count})`;
					}

					// push json to database
					// update if exists, add if doesn't
					if (task) {
						this.addTask(task);
					}
				};
				reader.readAsText(files[0]);

				setTimeout(() => {
					if (files[0]) {
						this.getTasks();
					}
				}, 200);
			},
		},
		computed: {
			...mapGetters(["taskList"]),
			orderedAndSearchedTaskList() {
				let filteredTaskList = this.taskList;

				if (this.searchQuery) {
					filteredTaskList = filteredTaskList.filter((task) => {
						return (
							task.name
								.toLowerCase()
								.indexOf(this.searchQuery.toLowerCase()) > -1 ||
							task.description
								.toLowerCase()
								.indexOf(this.searchQuery.toLowerCase()) > -1 ||
							task.author
								.toLowerCase()
								.indexOf(this.searchQuery.toLowerCase()) > -1
						);
					});
				}

				return lodash.orderBy(
					filteredTaskList,
					(o) => {
						return o[this.sortByColumn] || "";
					},
					this.sortByOrder
				);
			},
			isAdmin() {
				return userService.getCurrentUserInfo().admin;
			},
		},
		created() {
			this.getTasks();
		},
	};
</script>

<style lang="scss" scoped>
	@include foundation-xy-grid-classes;
	@include foundation-button;

	.url-wrapper {
		border: $border;
		padding: 5px;
		position: relative;
		height: 50px;
		margin: 20px 0;
		background: $selectedBackground;

		.url {
			float: left;
			line-height: 40px;
		}

		.button {
			right: 3px;
			bottom: 3px;
			display: inline-block;
			margin: 0;
			position: absolute;
		}
	}

	#file-input {
		cursor: pointer;
		outline: none;
		position: absolute;
		top: 0;
		left: 0;
		width: 0;
		height: 0;
		overflow: hidden;
		filter: alpha(opacity=0);
		opacity: 0;
	}

	.button {
		&.import {
			max-width: 42px !important;
		}

		.text {
			margin-left: 10px;
		}
	}

	.buttons {
		float: right;
	}
</style>
