<template>
	<div>
		<div class="grid-x grid-list-header">
			<div class="cell medium-1"></div>
			<div class="cell medium-1">Rows</div>
			<div class="cell medium-1">NPR</div>
			<div class="cell medium-2">
				Time Limit
			</div>
			<div class="cell medium-1">
				Scanning
			</div>
			<div class="cell medium-4">
				Targets
			</div>
			<div class="cell medium-1">
				Relationships
			</div>
		</div>
		<div
			class="grid-x grid-list-row alternate"
			v-for="(trial, index) in trials"
			:key="index"
		>
			<div class="cell medium-1">{{ index + 1 }}</div>
			<div class="cell medium-1">{{ trial.numRows }}</div>
			<div class="cell medium-1">
				{{ trial.numNodesPerRow }}
			</div>
			<div class="cell medium-2" v-if="trial.timeLimit">
				{{ trial.timeLimit }}s ({{ trial.showTimeLimit | boolToText }})
			</div>
			<div class="cell medium-2" v-if="!trial.timeLimit"></div>
			<div class="cell medium-1">
				{{ trial.scanningDirectionVertical }}
				{{ trial.scanningDirectionHorizontal }}
				{{ trial.scanningDirectionLineByLine | stringLimit(2) }}
			</div>
			<div class="cell medium-4">
				<ShapesSummary
					:shapes="getTargetShapes(trial)"
					:limit="false"
				/>
			</div>
			<div class="cell medium-1">
				{{ getRelationshipCount(trial) }}
			</div>
		</div>
	</div>
</template>

<script>
	import ShapesSummary from "@/components/ShapesSummary";

	export default {
		name: "GeneratedTrialList",
		props: ["trials"],
		components: {
			ShapesSummary,
		},
		data() {
			return {
				publicPath: process.env.BASE_URL,
			};
		},
		methods: {
			getTargetShapes(trial) {
				// concat all target shapes into a single array
				let shapes = [];
				trial.targets.forEach((target) => {
					shapes = shapes.concat(target.shapes);
				});
				return shapes;
			},
			getRelationshipCount(trial) {
				let count = 0;
				trial.targets.forEach((target) => {
					if (target.relationship) {
						count++;
					}
				});
				return count;
			},
		},
	};
</script>

<style lang="scss" scoped>
	.alternate:nth-of-type(even) {
		background: $selectedBackground;
	}
</style>
