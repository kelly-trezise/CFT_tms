<template>
	<div class="grid-container">
		<div class="grid-x grid-list-title">
			Task Edit Permissions
		</div>
		<div class="grid-x grid-list-header">
			<div class="cell medium-3">
				Name
			</div>
			<div class="cell medium-3">
				Email
			</div>
			<div class="cell medium-2 large-offset-4">
				Can Edit
			</div>
		</div>
		<div
			class="grid-x grid-list-row"
			v-for="user in userList"
			:key="user._id"
		>
			<div class="cell medium-3" data-cy="permissions-user-name">
				{{ user.name }}
			</div>
			<div class="cell medium-3">
				{{ user.email }}
			</div>
			<div class="cell medium-2 large-offset-4">
				<input
					type="checkbox"
					v-model="permissions"
					:value="user._id"
					:checked="hasPermissions(user._id) || isAuthor(user._id)"
					:disabled="isCurrentUser(user._id) || isAuthor(user._id)"
					data-cy="can-edit"
				/>
			</div>
		</div>
		<div class="grid-x grid-list-footer">
			<div class="cell medium-2 large-offset-10">
				<div class="buttons">
					<span data-tooltip title="Update Permissions">
						<div
							class="button save"
							@click="savePermissions()"
							data-cy="save-task-permissions"
						>
							<font-awesome-icon icon="check"></font-awesome-icon>
						</div>
					</span>
				</div>
			</div>
		</div>
	</div>
</template>

<script>
	import { mapActions, mapGetters } from "vuex";
	import lodash from "lodash";

	import UserService from "@/services/UserService";
	const userService = new UserService();

	export default {
		name: "TaskPermissions",
		props: ["task"],
		data() {
			return {
				permissions: [],
			};
		},
		methods: {
			...mapActions(["getUsers"]),
			isCurrentUser(id) {
				return userService.getCurrentUserInfo()._id === id;
			},
			isAuthor(id) {
				return this.task.authorId === id;
			},
			hasPermissions(id) {
				return (
					this.task.editPermissions.filter((userId) => userId === id)
						.length > 0
				);
			},
			savePermissions() {
				this.$emit("update-task-permissions", this.permissions);
			},
		},
		computed: mapGetters(["userList"]),
		created() {
			this.getUsers();
			this.permissions = lodash.cloneDeep(this.task.editPermissions);
		},
	};
</script>

<style></style>
