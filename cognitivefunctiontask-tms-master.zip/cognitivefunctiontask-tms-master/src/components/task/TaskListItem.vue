<template>
	<div class="grid-x grid-list-row" data-cy="task">
		<div class="cell medium-3">
			{{ task.name | stringLimitElipses(25) }}
		</div>
		<div class="cell medium-2">{{ task.author }}</div>
		<div class="cell medium-2">{{ task.dateCreated | formatDateTime }}</div>
		<div class="cell medium-2">
			<div v-if="task.dateModified">
				{{ task.dateModified | formatDateTime }}
			</div>
		</div>
		<div class="cell medium-3">
			<div class="buttons">
				<span data-tooltip title="Edit Task" v-if="showEditButtons">
					<router-link
						:to="{ name: 'EditTask', params: { id: task._id } }"
						class="button edit"
						data-cy="edit-task"
						><font-awesome-icon icon="edit"></font-awesome-icon
					></router-link>
				</span>
				<span data-tooltip title="Delete Task" v-if="showEditButtons">
					<div
						class="button delete"
						@click="showDeleteTaskModal()"
						data-cy="delete-task"
					>
						<font-awesome-icon icon="trash-alt"></font-awesome-icon>
					</div>
				</span>
				<span data-tooltip title="Edit Locked" v-if="!showEditButtons">
					<div class="button lock">
						<font-awesome-icon icon="lock"></font-awesome-icon>
					</div>
				</span>
				<span
					data-tooltip
					title="Delete Locked"
					v-if="!showEditButtons"
				>
					<div class="button lock">
						<font-awesome-icon icon="lock"></font-awesome-icon>
					</div>
				</span>
				<span data-tooltip title="Export Task" v-if="showEditButtons">
					<div
						class="button success"
						@click="exportTask()"
						data-cy="export-task"
					>
						<font-awesome-icon
							icon="file-export"
						></font-awesome-icon>
					</div>
				</span>
				<span
					data-tooltip
					title="Export Locked"
					v-if="!showEditButtons"
				>
					<div class="button lock">
						<font-awesome-icon icon="lock"></font-awesome-icon>
					</div>
				</span>
				<span
					data-tooltip
					title="Duplicate Task"
					v-if="showEditButtons"
				>
					<div
						class="button copy"
						@click="duplicateTask(task)"
						data-cy="duplicate-task"
					>
						<font-awesome-icon icon="copy"></font-awesome-icon>
					</div>
				</span>
				<span
					data-tooltip
					title="Duplicate Locked"
					v-if="!showEditButtons"
				>
					<div class="button lock">
						<font-awesome-icon icon="lock"></font-awesome-icon>
					</div>
				</span>
				<span data-tooltip title="View Task">
					<div
						class="button view"
						@click="showViewTask()"
						data-cy="view-task"
					>
						<font-awesome-icon icon="eye"></font-awesome-icon>
					</div>
				</span>
			</div>
		</div>
	</div>
</template>

<script>
	import { mapActions } from "vuex";

	import UserService from "@/services/UserService";

	const userService = new UserService();

	export default {
		name: "TaskListItem",
		props: ["task"],
		data() {
			return {
				clientPath: process.env.VUE_APP_CLIENT_URL,
				showEditButtons: true,
			};
		},
		methods: {
			...mapActions(["deleteTask", "duplicateTask"]),
			showDeleteTaskModal() {
				this.$modal.show("dialog", {
					title: `Delete ${this.task.name}`,
					text: `Are you sure you want to delete ${this.task.name}?`,
					clickToClose: false,
					buttons: [
						{
							title: "Yes, delete it",
							default: true,
							handler: () => {
								this.deleteTask(this.task._id);
								this.$modal.hide("dialog");
							},
							class: "modal-button red-text",
						},
						{
							title: "No",
							handler: () => {
								this.$modal.hide("dialog");
							},
							class: "modal-button",
						},
					],
				});
			},
			showViewTask() {
				const fullUrl = `${this.clientPath}/#/?task=${this.url}`;
				this.$emit("view-task", this.task, fullUrl);
			},
			exportTask() {
				const data = JSON.stringify(this.task, null, "\t");
				const filename = this.createFileName(this.task);

				let file = new Blob([data], { type: "application/json" });
				if (window.navigator.msSaveOrOpenBlob)
					// IE10+
					window.navigator.msSaveOrOpenBlob(file, filename);
				else {
					// Others
					var a = document.createElement("a"),
						url = URL.createObjectURL(file);
					a.href = url;
					a.download = filename;
					document.body.appendChild(a);

					a.click();
					setTimeout(function() {
						document.body.removeChild(a);
						window.URL.revokeObjectURL(url);
					}, 0);
				}
			},
			createFileName(task) {
				return task.name.replace(/\s/g, "") + ".json";
			},
		},
		computed: {
			url() {
				return this.task.customUrl || this.task._id;
			},
		},
		created() {
			if (this.task.lockForEdit) {
				if (
					this.task.editPermissions.filter(
						(userId) =>
							userId === userService.getCurrentUserInfo()._id
					).length === 0
				) {
					this.showEditButtons = false;
				}
			}
		},
	};
</script>

<style lang="scss" scoped>
	@include foundation-button;
	@include foundation-xy-grid-classes;
</style>
