<template>
	<div>
		<div
			class="grid-x grid-list-row selectable"
			@click="toggleTrial()"
			:class="{ selected: selectedTrial }"
			data-cy="test-trial"
		>
			<div class="cell medium-1">
				{{ trial.trialNumberInTask }}
			</div>
			<div class="cell medium-1">
				{{ trial.trialSet }}
			</div>
			<div class="cell medium-1">
				{{ trial.stats.startTime | formatTime }}
			</div>
			<div class="cell medium-1" v-if="trial.stats.timeTakenS >= 0">
				{{ trial.stats.timeTakenS.toFixed(2) }}
			</div>
			<div class="cell medium-1" v-if="trial.stats.timeRemaining">
				{{ trial.stats.timeRemaining.toFixed(2) }}
			</div>
			<div class="cell medium-1" v-else></div>
			<div class="cell medium-1">
				{{ trial.targetCount }}
			</div>
			<div class="cell medium-1">
				{{ trial.totalShapeCount }}
			</div>
			<div class="cell medium-1">
				{{ trial.stats.truePositive }}
			</div>
			<div class="cell medium-1">
				{{ trial.stats.falsePositive }}
			</div>
			<div class="cell medium-1">
				{{ trial.stats.falseNegative }}
			</div>
			<div class="cell medium-1">
				{{ trial.stats.trueNegative }}
			</div>
			<div class="cell medium-1">
				{{ trial.stats.wrongDirection | boolToText }}
			</div>
		</div>
		<TestTrialDetails v-if="selectedTrial" :trial="selectedTrial" />
	</div>
</template>

<script>
	import TestTrialDetails from "@/components/test/TestTrialDetails";

	export default {
		name: "TestTrialListItem",
		props: ["trial"],
		components: {
			TestTrialDetails,
		},
		data() {
			return {
				selectedTrial: null,
			};
		},
		methods: {
			toggleTrial() {
				if (!this.selectedTrial) {
					this.selectedTrial = this.trial;
				} else {
					this.selectedTrial = null;
				}
			},
		},
	};
</script>

<style lang="scss" scoped>
	.selected {
		background: $selectedBackground;
	}
</style>
