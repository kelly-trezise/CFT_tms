<template>
	<div>
		<div
			class="grid-x grid-list-title selectable"
			@click="toggleTaskInfo()"
			data-cy="test-task-details"
		>
			<div class="cell medium-4">
				{{ test.name }}
			</div>
			<div class="cell medium-1 large-offset-9">
				<font-awesome-icon
					icon="chevron-right"
					v-if="!showTaskInfo"
				></font-awesome-icon>
				<font-awesome-icon
					icon="chevron-down"
					v-if="showTaskInfo"
				></font-awesome-icon>
			</div>
		</div>
		<div v-if="showTaskInfo">
			<TaskSummary :task="test.task" />
		</div>
		<div class="grid-x grid-list-title">
			Test
		</div>
		<div class="grid-x test-info-row">
			<div class="cell medium-6" data-cy="test-player-name">
				<span class="data-title">Player Name:</span>
				{{ test.playerName }}
			</div>
			<div class="cell medium-6">
				<span class="data-title">Date of Birth:</span>
				{{ test.dob }}
			</div>
		</div>
		<div class="grid-x test-info-row" data-cy="test-detail-time">
			<div class="cell medium-3">
				<span class="data-title">Start:</span>
				{{ test.stats.startTime | formatDateTimeExact }}
			</div>
			<div class="cell medium-3">
				<span class="data-title">End:</span>
				{{ test.stats.endTime | formatDateTimeExact }}
			</div>
			<div class="cell medium-3">
				<span class="data-title">Time Taken (s):</span>
				{{ test.stats.timeTakenS }}
			</div>
		</div>
		<div class="grid-x grid-list-header">
			<div class="cell medium-1 tooltip">
				<span class="data-title">T+</span>
				<span class="tooltip-text">Targets Selected</span>
			</div>
			<div class="cell medium-1 tooltip">
				<span class="data-title">F+</span>
				<span class="tooltip-text">Targets Missed</span>
			</div>
			<div class="cell medium-1 tooltip">
				<span class="data-title">F-</span>
				<span class="tooltip-text">Incorrect Shapes Selected</span>
			</div>
			<div class="cell medium-1 tooltip">
				<span class="data-title">T-</span>
				<span class="tooltip-text">Incorrect Shapes Missed</span>
			</div>
			<div class="cell medium-1 tooltip">
				<span class="data-title">CT+</span>
				<span class="tooltip-text">Target Corrections</span>
			</div>
			<div class="cell medium-1 tooltip">
				<span class="data-title">CF-</span>
				<span class="tooltip-text">Incorrect Shape Corrections</span>
			</div>
			<div class="cell medium-2">
				<span class="data-title">Wrong Direction</span>
			</div>
		</div>
		<div class="grid-x grid-list-row" data-cy="test-detail-stats">
			<div class="cell medium-1">
				{{ test.stats.truePositive }}
			</div>
			<div class="cell medium-1">
				{{ test.stats.falsePositive }}
			</div>
			<div class="cell medium-1">
				{{ test.stats.falseNegative }}
			</div>
			<div class="cell medium-1">
				{{ test.stats.trueNegative }}
			</div>
			<div class="cell medium-1">
				{{ test.stats.correctionTruePositive }}
			</div>
			<div class="cell medium-1">
				{{ test.stats.correctionFalseNegative }}
			</div>
			<div class="cell medium-2">
				{{ test.stats.wrongDirection | boolToText }}
			</div>
		</div>
		<TestTrialList :trials="test.trials" />
	</div>
</template>

<script>
	import TestTrialList from "@/components/test/TestTrialList";
	import TaskSummary from "@/components/task/TaskSummary";

	export default {
		name: "TestDetails",
		props: ["test"],
		components: {
			TestTrialList,
			TaskSummary,
		},
		data() {
			return {
				publicPath: process.env.BASE_URL,
				showTaskInfo: false,
			};
		},
		methods: {
			toggleTaskInfo() {
				this.showTaskInfo = !this.showTaskInfo;
			},
		},
	};
</script>

<style lang="scss" scoped>
	.test-info-row {
		padding: 10px 0;
		text-transform: capitalize;
	}
</style>
