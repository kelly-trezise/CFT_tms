<template>
	<div>
		<div class="grid-x grid-list-header">
			<div class="cell edium-12">
				Trials
			</div>
		</div>
		<div class="grid-x grid-list-header">
			<div class="cell medium-1">
				Trial
			</div>
			<div class="cell medium-1">
				Trial Set
			</div>
			<div class="cell medium-1 tooltip">
				ST
				<span class="tooltip-text">Start Time</span>
			</div>
			<div class="cell medium-1">
				Time
			</div>
			<div class="cell medium-1 tooltip">
				TR
				<span class="tooltip-text">Time Remaining</span>
			</div>
			<div class="cell medium-1">
				Targets
			</div>
			<div class="cell medium-1">
				Shapes
			</div>
			<div class="cell medium-1 tooltip">
				T+
				<span class="tooltip-text">Targets Selected</span>
			</div>
			<div class="cell medium-1 tooltip">
				F+
				<span class="tooltip-text">Targets Missed</span>
			</div>
			<div class="cell medium-1 tooltip">
				F-
				<span class="tooltip-text">Incorrect Shapes Selected</span>
			</div>
			<div class="cell medium-1 tooltip">
				T-
				<span class="tooltip-text">Incorrect Shapes Missed</span>
			</div>
			<div class="cell medium-1 tooltip">
				WD
				<span class="tooltip-text">Wrong Direction</span>
			</div>
		</div>
		<TestTrialListItem
			v-for="(trial, i) in trials"
			:key="`${i}-${trial._id}`"
			:trial="trial"
		/>
	</div>
</template>

<script>
	import TestTrialListItem from "@/components/test/TestTrialListItem";

	export default {
		name: "TestTrialList",
		props: ["trials"],
		components: {
			TestTrialListItem,
		},
	};
</script>

<style></style>
