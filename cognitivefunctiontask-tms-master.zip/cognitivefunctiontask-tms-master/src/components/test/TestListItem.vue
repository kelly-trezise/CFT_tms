<template>
	<div
		class="grid-x grid-list-row selectable"
		@click="viewTest()"
		data-cy="test"
	>
		<div class="cell medium-2">
			{{ test.task.name | stringLimitElipses(15) }}
		</div>
		<div class="cell medium-2">
			{{ test.stats.startTime | formatDateTime }}
		</div>
		<div class="cell medium-2">
			{{ test.playerName }}
		</div>
		<div class="cell medium-1">
			{{ test.trials.length }}
		</div>
		<div class="cell medium-1">
			{{ test.stats.timeTakenS.toFixed(1) }}
		</div>
		<div class="cell medium-1">
			{{ test.stats.truePositive }}
		</div>
		<div class="cell medium-1">
			{{ test.stats.falsePositive }}
		</div>
		<div class="cell medium-1">
			{{ test.stats.falseNegative }}
		</div>
		<div class="cell medium-1">
			<div class="buttons">
				<span data-tooltip title="Delete Test">
					<div
						class="button delete"
						@click="showDeleteTestModal()"
						data-cy="delete-test"
					>
						<font-awesome-icon icon="trash-alt"></font-awesome-icon>
					</div>
				</span>
			</div>
		</div>
	</div>
</template>

<script>
	import axios from "axios";
	import moment from "moment";

	import router from "@/router";
	import { config } from "@/data/Config";

	import NotificationService from "@/services/NotificationService";
	const notificationService = new NotificationService();

	import UserService from "@/services/UserService";
	const userService = new UserService();

	export default {
		name: "TestListItem",
		props: ["test"],
		data() {
			return {
				isDelete: false,
			};
		},
		methods: {
			viewTest() {
				if (!this.isDelete) {
					router.push({
						name: "ViewTest",
						params: { id: this.test.taskId, testId: this.test._id },
					});
				}
			},
			showDeleteTestModal() {
				this.isDelete = true;
				this.$modal.show("dialog", {
					title: `Delete ${this.test.playerName}'s test?`,
					text: `Are you sure you want to delete ${
						this.test.playerName
					}'s test at ${moment(
						String(this.test.stats.startTime)
					).format(config.dateTimeFormat)}?`,
					clickToClose: false,
					buttons: [
						{
							title: "Yes, delete it",
							default: true,
							handler: () => {
								this.deleteTest();
								this.isDelete = false;
								this.$modal.hide("dialog");
							},
							class: "modal-button red-text",
						},
						{
							title: "No",
							handler: () => {
								this.isDelete = false;
								this.$modal.hide("dialog");
							},
							class: "modal-button",
						},
					],
				});
			},
			deleteTest() {
				const config = {
					headers: {
						Authorization: "Bearer " + userService.getJwt(),
					},
					data: {
						_id: this.test._id,
					},
				};
				axios
					.delete(process.env.VUE_APP_API_URL + "/deleteTest", config)
					.then((resp) => {
						if (resp.data.name) {
							notificationService.success(
								`${resp.data.playerName}'s test has been deleted.`
							);
						} else {
							notificationService.error("Test delete failed.");
						}
						this.$emit("update-tests");
					})
					.catch((error) => {
						NotificationService.error(error);
					});
			},
		},
	};
</script>

<style></style>
