<template>
	<div id="test-trial-details">
		<div class="grid-x grid-list-row">
			<div class="cell medium-4">
				<span class="data-title">
					Grid
				</span>
			</div>
			<div class="cell medium-7" id="log-header">
				<span class="data-title">
					Log
				</span>
			</div>
		</div>
		<div class="grid-x">
			<div class="cell medium-4">
				<TrialGrid
					:grid="trial.grid"
					class="grid"
					:showColours="showColours"
				/>
			</div>
			<div class="cell medium-8">
				<div class="grid-container" v-if="trial.log.length > 0">
					<div class="grid-x grid-list-header">
						<div class="cell medium-2">
							Timestamp
						</div>
						<div
							class="cell medium-1"
							v-if="trial.log[0].timeRemaining"
						>
							TR
						</div>
						<div class="cell medium-1 tooltip">
							T
							<span class="tooltip-text">Target</span>
						</div>
						<div class="cell medium-1 tooltip">
							NNT
							<span class="tooltip-text">Not Nth Target</span>
						</div>
						<div class="cell medium-1 tooltip">
							DT
							<span class="tooltip-text">Distractor Target</span>
						</div>
						<div class="cell medium-1 tooltip">
							ND
							<span class="tooltip-text">Near Distractor</span>
						</div>
						<div class="cell medium-1 tooltip">
							FD
							<span class="tooltip-text">Far Distractor</span>
						</div>
						<div class="cell medium-2 tooltip">
							Pos (R, P)
							<span class="tooltip-text"
								>Position (Row, Position)</span
							>
						</div>
						<div class="cell medium-1 tooltip">
							Cor
							<span class="tooltip-text">Correction</span>
						</div>
						<div class="cell medium-1 tooltip">
							WH
							<span class="tooltip-text">Withhold Response</span>
						</div>
					</div>
					<div
						v-for="record in trial.log"
						:key="record._id"
						class="grid-x grid-list-row"
						data-cy="test-trial-log"
					>
						<div class="cell medium-2">
							{{ record.timestamp | formatTime }}
						</div>
						<div class="cell medium-1" v-if="record.timeRemaining">
							{{ record.timeRemaining.toFixed(2) }}
						</div>
						<div class="cell medium-1">
							{{ record.isTarget | boolToText }}
						</div>
						<div class="cell medium-1">
							{{ record.isNotNthTarget | boolToText }}
						</div>
						<div class="cell medium-1">
							{{ record.isDistractorTarget | boolToText }}
						</div>
						<div class="cell medium-1">
							{{ record.isNearDistractor | boolToText }}
						</div>
						<div class="cell medium-1">
							{{ record.isFarDistractor | boolToText }}
						</div>
						<div class="cell medium-2">
							{{ record.overallPosition + 1 }} ({{ record.row }},
							{{ record.positionInRow }})
						</div>
						<div class="cell medium-1">
							{{ record.hasAlreadyTouched | boolToText }}
						</div>
						<div class="cell medium-1">
							{{ record.withholdResponse | boolToText }}
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</template>

<script>
	import TrialGrid from "@/components/TrialGrid";

	export default {
		name: "TestTrialDetails",
		props: ["trial"],
		components: {
			TrialGrid,
		},
		data() {
			return {
				showColours: {
					all: true,
					target: true,
					notNthTarget: true,
					distractorTarget: true,
					isRelationship: true,
					nearDistractor: true,
					farDistractor: false,
					withholdResponse: true,
				},
			};
		},
	};
</script>

<style lang="scss" scoped>
	#test-trial-details {
		background: $selectedBackground;
	}

	.grid {
		border: $border;
		padding: 2px;
		background: white;
		margin: 10px;
		height: 250px;
		width: 90%;
	}

	.grid-list-row {
		background: $selectedBackground;
	}

	#log-header {
		padding-left: 10px;
	}
</style>
