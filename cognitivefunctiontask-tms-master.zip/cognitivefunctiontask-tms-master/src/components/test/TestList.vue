<template>
	<div class="grid-container" id="test-list">
		<div class="grid-x" id="filter">
			<div class="cell medium-2">
				<select name="task" v-model="filter.task">
					<option value="all">All</option>
					<option
						v-for="(task, index) in tasks"
						:key="index"
						:value="task"
					>
						{{ task }}
					</option>
				</select>
			</div>
			<div class="cell medium-2">
				<select name="date" v-model="filter.date">
					<option value="all">All</option>
					<option
						v-for="(date, index) in testDates"
						:key="index"
						:value="date"
					>
						{{ date }}
					</option>
				</select>
			</div>
			<div class="cell medium-2">
				<select
					name="limit"
					v-model="filter.limit"
					@change="getTests()"
				>
					<option value="all">All</option>
					<option value="50">Latest 50</option>
					<option value="100">Latest 100</option>
					<option value="200">Latest 200</option>
				</select>
			</div>
			<div class="cell medium-2">
				<input
					type="text"
					name="search"
					placeholder="Search..."
					v-model="searchQuery"
					data-cy="test-search"
				/>
			</div>
			<div class="cell medium-4">
				<div class="options">
					<span data-tooltip title="Export Tests">
						<button
							class="button success"
							@click="showExportModal()"
							v-if="!uploadBoxVisible"
							data-cy="export-tests"
						>
							Export
						</button>
					</span>
					<span data-tooltip title="Delete All Filtered Tests">
						<button
							class="button delete"
							@click="showDeleteFilteredTestsModal()"
							v-if="!uploadBoxVisible"
							data-cy="delete-tests"
						>
							Delete
						</button>
					</span>
					<span data-tooltip title="Show Upload Box">
						<button
							class="button upload"
							@click="toggleUploadBox()"
							v-if="!uploadBoxVisible"
							data-cy="upload-tests"
						>
							Upload
						</button>
					</span>
					<span data-tooltip title="Hide Upload Box">
						<button
							class="button close"
							@click="toggleUploadBox()"
							v-if="uploadBoxVisible"
							data-cy="hide-upload-box"
						>
							<font-awesome-icon icon="times"></font-awesome-icon>
						</button>
					</span>
				</div>
			</div>
		</div>
		<div class="grid-x" v-if="uploadBoxVisible">
			<div class="cell medium-12">
				<form enctype="multipart/form-data" novalidate>
					<div class="dropbox">
						<input
							type="file"
							multiple
							name="testUpload"
							@change="filesSelect($event.target.files)"
							accept="application/json"
							class="input-file"
							data-cy="test-import"
						/>
						<div class="content" v-if="isInitial">
							Drag your file(s) here to begin<br />
							or click to browse
						</div>
						<div class="content" v-if="isSelected">
							<div v-for="file in selectedFiles" :key="file.name">
								{{ file.name }}
							</div>
							<div
								class="button"
								v-if="selectedFiles.length > 0"
								@click="filesUpload()"
								data-cy="upload-tests"
								v-on:submit.prevent
							>
								Upload
							</div>
						</div>
					</div>
				</form>
			</div>
		</div>
		<div class="grid-x grid-list-header">
			<div
				class="cell medium-2"
				@click="sortBy('task.name')"
				:class="setSortingIconClass('task.name')"
			>
				Task
			</div>
			<div
				class="cell medium-2"
				@click="sortBy('stats.startTime')"
				:class="setSortingIconClass('stats.startTime')"
			>
				Start Time
			</div>
			<div
				class="cell medium-2"
				@click="sortBy('playerName')"
				:class="setSortingIconClass('playerName')"
			>
				Player Name
			</div>
			<div
				class="cell medium-1"
				@click="sortBy('trials.length')"
				:class="setSortingIconClass('trials.length')"
			>
				Trials
			</div>
			<div
				class="cell medium-1"
				@click="sortBy('timeTakenS')"
				:class="setSortingIconClass('timeTakenS')"
			>
				Time
			</div>
			<div class="cell medium-1 tooltip">
				T+
				<span class="tooltip-text">Correct Targets Selected</span>
			</div>
			<div class="cell medium-1 tooltip">
				F+
				<span class="tooltip-text">Correct Targets Missed</span>
			</div>
			<div class="cell medium-1 tooltip">
				F-
				<span class="tooltip-text">Incorrect Shapes Selected</span>
			</div>
		</div>
		<TestListItem
			v-for="(test, i) in orderedAndSearchedTestList"
			:key="`${i}-${test._id}`"
			:test="test"
			@update-tests="$emit('update-tests')"
		/>
		<modal
			name="export-options"
			class="modal"
			:adaptive="true"
			width="300px"
			height="auto"
			data-cy="test-export"
		>
			<div class="content">
				<div class="top-right">
					<button
						class="button close"
						@click="$modal.hide('export-options')"
					>
						<font-awesome-icon icon="times"></font-awesome-icon>
					</button>
				</div>
				<div class="title">
					Export {{ orderedAndSearchedTestList.length }} Test(s)
				</div>
				<div>
					<label for="detail">Detail</label>
					<select name="detail" v-model="exportDetail">
						<option value="trial">Trial By Trial</option>
						<option value="shape-select">Shape By Shape</option>
					</select>
				</div>
				<button
					class="button export"
					@click="downloadCSV()"
					data-cy="export"
				>
					Export
				</button>
			</div>
		</modal>
	</div>
</template>

<script>
	import axios from "axios";
	import lodash from "lodash";
	import moment from "moment";

	import TestListItem from "@/components/test/TestListItem";

	import { config } from "@/data/Config";

	import NotificationService from "@/services/NotificationService";
	const notificationService = new NotificationService();

	import DataExportService from "@/services/DataExportService";
	const dataExportService = new DataExportService();

	import UserService from "@/services/UserService";
	const userService = new UserService();

	const STATUS_INITIAL = 0,
		STATUS_SELECTED = 1;

	export default {
		name: "TestList",
		props: ["tests", "taskId"],
		components: {
			TestListItem,
		},
		data() {
			return {
				uploadedFiles: [],
				selectedFiles: [],
				uploadError: null,
				currentStatus: null,
				uploadBoxVisible: false,
				sortByColumn: "stats.startTime",
				sortByOrder: "desc",
				searchQuery: "",
				filter: {
					task: "all",
					date: "all",
					limit: 50,
				},
				exportDetail: "trial",
			};
		},
		methods: {
			reset() {
				// reset form to initial state
				this.currentStatus = STATUS_INITIAL;
				this.selectedFiles = [];
				this.uploadBoxVisible = false;
			},
			upload(files) {
				// upload data to the server
				files.forEach((file) => {
					let reader = new FileReader();
					reader.onload = (event) => {
						// convert to JS object
						const test = JSON.parse(event.target.result);

						// push json to database
						axios
							.post(process.env.VUE_APP_API_URL + "/saveTest", {
								test: test,
							})
							.then((resp) => {
								this.$emit("update-tests");
								if (resp.data.error) {
									notificationService.warning(
										resp.data.error
									);
								} else {
									notificationService.success(
										`${file.name} successfully uploaded.`
									);
								}
								this.toggleUploadBox();
							})
							.catch(() => {
								notificationService.error(`Upload failed.`);
							});
					};
					reader.readAsText(file);
				});
			},
			filesSelect(fileList) {
				if (fileList.length > 0) {
					this.selectedFiles = fileList;
					this.currentStatus = STATUS_SELECTED;
				} else {
					this.currentStatus = STATUS_INITIAL;
				}
			},
			filesUpload() {
				if (this.selectedFiles.length > 0) {
					// upload it
					this.upload(this.selectedFiles);
				}
			},
			toggleUploadBox() {
				this.uploadBoxVisible = !this.uploadBoxVisible;
				this.currentStatus = STATUS_INITIAL;
			},
			sortBy(column) {
				this.sortByColumn = column;
				if (this.sortByOrder === "asc") {
					this.sortByOrder = "desc";
				} else {
					this.sortByOrder = "asc";
				}
			},
			setSortingIconClass(column) {
				return {
					asc:
						this.sortByColumn === column &&
						this.sortByOrder === "asc",
					desc:
						this.sortByColumn === column &&
						this.sortByOrder === "desc",
				};
			},
			convertDateToCompareFormat(date) {
				return moment(date, config.dateFormat).format("YYYY-MM-DD");
			},
			showExportModal() {
				this.$modal.show("export-options");
			},
			downloadCSV() {
				// generate csv
				const csv = dataExportService.testsToCSV(
					this.orderedAndSearchedTestList,
					this.exportDetail
				);
				dataExportService.createFile(csv, this.generateCSVFilename());
				this.$modal.hide("export-options");
			},
			generateCSVFilename() {
				const user = userService.getCurrentUserInfo();
				const date = new Date().toISOString();

				let detail = "TrialByTrial";
				if (this.exportDetail === "shape-select") {
					detail = "ShapeByShape";
				}

				return (
					user.name.replace(/\s/g, "") +
					"CognitiveFunctionTaskDataExport" +
					detail +
					date.substring(0, 10) +
					".csv"
				);
			},
			getTests() {
				this.$emit("update-tests", this.filter.limit);
			},
			showDeleteFilteredTestsModal() {
				this.$modal.show("dialog", {
					title: `Delete ${this.orderedAndSearchedTestList.length} test(s)`,
					text: `Are you sure you want to delete the filtered tests?`,
					buttons: [
						{
							title: "Yes, delete them",
							default: true,
							handler: () => {
								this.deleteTests();
								this.$modal.hide("dialog");
							},
							class: "modal-button red-text",
						},
						{
							title: "No",
							handler: () => {
								this.$modal.hide("dialog");
							},
							class: "modal-button",
						},
					],
				});
			},
			deleteTests() {
				const config = {
					headers: {
						Authorization: "Bearer " + userService.getJwt(),
					},
					data: {
						ids: this.orderedAndSearchedTestList.map((t) => t._id),
					},
				};
				axios
					.delete(
						process.env.VUE_APP_API_URL + "/deleteTests",
						config
					)
					.then((resp) => {
						if (resp.data.ok) {
							notificationService.success(
								`Deleted ${resp.data.deletedCount} tests.`
							);
						} else {
							notificationService.error("Test delete failed.");
						}
						this.$emit("update-tests");
					})
					.catch((error) => {
						NotificationService.error(error);
					});
			},
		},
		computed: {
			isInitial() {
				return this.currentStatus === STATUS_INITIAL;
			},
			isSelected() {
				return this.currentStatus === STATUS_SELECTED;
			},
			tasks() {
				let uniqueTasks = [
					...new Set(this.tests.map((test) => test.name)),
				];
				uniqueTasks = uniqueTasks.sort();
				return uniqueTasks;
			},
			testDates() {
				let testDates = this.tests.map((test) => {
					return moment(test.stats.startTime).format(
						config.dateFormat
					);
				});
				let uniqueTestDates = [...new Set(testDates)];
				uniqueTestDates = lodash.sortBy(uniqueTestDates, (date) => {
					return new Date(moment(date, config.dateFormat));
				});
				return uniqueTestDates;
			},
			orderedAndSearchedTestList() {
				let filteredTestList = this.tests;

				if (this.searchQuery) {
					filteredTestList = filteredTestList.filter((test) => {
						// convert date time in format '21/05/2020 to comparable date
						const dateSearch = this.convertDateToCompareFormat(
							this.searchQuery
						);

						return (
							test.task.name
								.toLowerCase()
								.indexOf(this.searchQuery.toLowerCase()) > -1 ||
							test.stats.startTime.indexOf(dateSearch) > -1 ||
							test.playerName
								.toLowerCase()
								.indexOf(this.searchQuery.toLowerCase()) > -1
						);
					});
				}

				if (this.filter.task && this.filter.task !== "all") {
					filteredTestList = filteredTestList.filter((test) => {
						return test.task.name === this.filter.task;
					});
				}

				if (this.filter.date && this.filter.date !== "all") {
					filteredTestList = filteredTestList.filter((test) => {
						const dateFilter = this.convertDateToCompareFormat(
							this.filter.date
						);
						return moment(test.stats.startTime).isSame(
							dateFilter,
							"day"
						);
					});
				}

				return lodash.orderBy(
					filteredTestList,
					this.sortByColumn,
					this.sortByOrder
				);
			},
		},
		created() {
			this.reset();
		},
	};
</script>

<style lang="scss" scoped>
	@include foundation-button;

	#test-list {
		margin-bottom: 50px;
	}

	#filter {
		margin-top: 20px;

		select {
			width: 80%;
		}

		.buttons {
			float: right;
		}
	}

	.options {
		float: right;

		.upload {
			margin-left: 10px;
		}

		.delete {
			margin-left: 10px;
		}
	}

	.dropbox {
		outline: 2px dashed black; /* the dash box */
		outline-offset: -10px;
		background: white;
		color: black;
		padding: 10px 10px;
		min-height: 200px; /* minimum height */
		position: relative;
		cursor: pointer;
	}

	.input-file {
		opacity: 0; /* invisible but it's there! */
		width: 100%;
		height: 200px;
		position: absolute;
		cursor: pointer;
	}

	.dropbox:hover {
		background: #eee; /* when mouse over to the drop zone, change color */
	}

	.dropbox .content {
		text-align: center;
		line-height: 22px;
		padding: 71px 0;

		.button {
			display: block;
			left: 0;
			right: 0;
			margin: 10px auto;
			z-index: 1;
			position: absolute;
			width: 80px;
		}
	}
</style>
