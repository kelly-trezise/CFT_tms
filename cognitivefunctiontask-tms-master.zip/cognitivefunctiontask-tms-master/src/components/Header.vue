<template>
	<div class="top-bar">
		<div class="top-bar-left">
			<ul class="menu">
				<li>
					<button
						class="button"
						@click="back()"
						v-if="!hideBackButton"
						data-cy="back"
					>
						Back
					</button>
				</li>
			</ul>
		</div>
		<div class="top-bar-center" @click="home()">
			<div class="logo">
				<img src="/img/logo.png" alt="Cognitive Function Task" />
			</div>
			Task Management System
		</div>
		<div class="top-bar-right">
			<ul class="menu">
				<li class="menu-text" data-cy="current-user-name">
					{{ currentUserName }}
				</li>
				<li>
					<button
						type="button"
						class="button"
						@click="logout()"
						v-if="!hideLogoutButton"
						data-cy="logout"
					>
						Logout
					</button>
				</li>
			</ul>
		</div>
	</div>
</template>

<script>
	import UserService from "@/services/UserService";
	import router from "@/router";
	const userService = new UserService();

	export default {
		name: "Header",
		methods: {
			logout() {
				userService.logout();
				router.push({ name: "Login" });
			},
			hideIfLoginRoute() {
				if (this.$route.name === "Login") {
					this.hideLogoutButton = true;
				} else {
					this.hideLogoutButton = false;
				}
			},
			back() {
				router.go(-1);
			},
			hideIfHomeOrLoginRoute() {
				if (
					this.$route.name === "Home" ||
					this.$route.name === "Login"
				) {
					this.hideBackButton = true;
				} else {
					this.hideBackButton = false;
				}
			},
			home() {
				if (this.$route.name !== "Home") {
					router.push({
						path: "/",
					});
				}
			},
		},
		data() {
			return {
				hideLogoutButton: false,
				currentUserName: "",
				hideBackButton: false,
			};
		},
		watch: {
			$route() {
				this.hideIfLoginRoute();
				this.hideIfHomeOrLoginRoute();
				this.currentUserName = userService.getCurrentUserInfo().name;
			},
		},
		created() {
			this.hideIfLoginRoute();
			this.hideIfHomeOrLoginRoute();
			this.currentUserName = userService.getCurrentUserInfo().name;
		},
	};
</script>

<style lang="scss" scoped>
	@include foundation-top-bar;
	@include foundation-menu;
	@include foundation-button;

	.top-bar {
		margin-bottom: 20px;
		height: 60px;
		z-index: 10000; // over loading spinner
		position: relative;
		box-shadow: 0px 2px 11px 0px rgba(0, 0, 0, 0.5);
	}

	.top-bar-center {
		position: absolute;
		width: 50%;
		left: 25%;
		right: 25%;
		text-align: center;
		cursor: pointer;

		.logo img {
			width: 200px;
			margin-bottom: 5px;
		}
	}

	.menu-text {
		font-weight: normal !important;
	}
</style>
