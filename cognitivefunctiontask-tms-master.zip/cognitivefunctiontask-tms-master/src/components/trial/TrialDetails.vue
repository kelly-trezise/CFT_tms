<template>
	<div class="trial-form">
		<div class="grid-x">
			<div class="cell medium-1">
				<label for="" v-if="index">{{ index }}</label>
			</div>
			<div class="cell medium-11 trial-section-title">
				Grid
			</div>
		</div>
		<div class="grid-x trial-info-row">
			<div class="cell medium-1 large-offset-1">
				<label for="numRows">Rows</label>
				<input
					type="number"
					name="numRows"
					v-model="trialDetails.numRows"
					:class="{
						invalid:
							validation.numRowsError &&
							(!trialDetails.numRows ||
								parseInt(trialDetails.numRows) <= 0),
					}"
				/>
				<FormValidationError
					:error="validation.numRowsError"
					:showIf="
						!trialDetails.numRows ||
							parseInt(trialDetails.numRows) <= 0
					"
				/>
			</div>
			<div class="cell medium-2">
				<label for="numNodesPerRow">Nodes Per Row</label>
				<input
					type="number"
					name="numNodesPerRow"
					v-model="trialDetails.numNodesPerRow"
					:class="{
						invalid:
							validation.numNodesPerRowError &&
							(!trialDetails.numNodesPerRow ||
								parseInt(trialDetails.numNodesPerRow) <= 0),
					}"
				/>
				<FormValidationError
					:error="validation.numNodesPerRowError"
					:showIf="
						!trialDetails.numNodesPerRow ||
							parseInt(trialDetails.numNodesPerRow) <= 0
					"
				/>
			</div>
			<div class="cell medium-3">
				<label for="padding">Padding</label>
				<input
					type="number"
					name="padding"
					v-model="trialDetails.padding"
					placeholder="10"
					:class="{
						invalid:
							validation.paddingError &&
							(!trialDetails.padding ||
								parseInt(trialDetails.padding) <= 0),
					}"
				/>
				<FormValidationError
					:error="validation.paddingError"
					:showIf="
						!trialDetails.padding ||
							parseInt(trialDetails.padding) <= 0
					"
				/>
			</div>
		</div>
		<div class="grid-x">
			<div class="cell medium-6 large-offset-1 scanning-dir">
				<label for="scanningDirection">Scanning Direction </label>
				<select
					name="scanningDirection"
					v-model="trialDetails.scanningDirectionVertical"
				>
					<option value="tb">Top to bottom</option>
					<option value="bt">Bottom to top</option>
				</select>
				<select
					name="scanningDirection"
					v-model="trialDetails.scanningDirectionHorizontal"
				>
					<option value="lr">Left to right</option>
					<option value="rl">Right to left</option>
				</select>
				<select
					name="scanningDirection"
					v-model="trialDetails.scanningDirectionLineByLine"
				>
					<option value="sd">Same direction</option>
					<option value="snake">Snake</option>
				</select>
			</div>
		</div>
		<div class="grid-x">
			<div class="cell medium-11 large-offset-1 trial-section-title">
				Completing Trials
			</div>
		</div>
		<div class="grid-x">
			<div class="cell medium-2 large-offset-1">
				<label for="numTrials">Number of Trials</label>
				<input
					type="number"
					name="numTrials"
					v-model="trialDetails.numTrials"
					:class="{
						invalid:
							validation.numTrialsError &&
							(!trialDetails.numTrials ||
								parseInt(trialDetails.numTrials) <= 0),
					}"
				/>
				<FormValidationError
					:error="validation.numTrialsError"
					:showIf="
						!trialDetails.numTrials ||
							parseInt(trialDetails.numTrials) <= 0
					"
				/>
			</div>
		</div>
		<div class="grid-x">
			<div class="cell medium-4 large-offset-1">
				<label for="timeLimit">Time Limit (empty for no limit)</label>
				<input
					type="number"
					name="timeLimit"
					v-model="trialDetails.timeLimit"
					@keyup="showOrHideShowTimeLimit"
					class="proportion"
					placeholder="Seconds"
				/>
			</div>
			<div
				class="cell medium-2 large-offset-1"
				v-if="showTimeLimit || trialDetails.timeLimit"
			>
				<label for="showTimeLimit">Show Time Limit</label>
				<select
					name="showTimeLimit"
					v-model="trialDetails.showTimeLimit"
				>
					<option value="true">Yes</option>
					<option value="false">No</option>
				</select>
			</div>
		</div>
		<div class="grid-x">
			<div class="cell medium-4 large-offset-1">
				<label for="nextTrialWhenAllTargetsSelected"
					>Next Trial When All Targets Selected</label
				>
				<select
					name="nextTrialWhenAllTargetsSelected"
					v-model="trialDetails.nextTrialWhenAllTargetsSelected"
				>
					<option value="true">Yes</option>
					<option value="false">No</option>
				</select>
			</div>
			<div class="cell medium-3 large-offset-1">
				<label for="showTimeLimit">Show 'Done' Button</label>
				<select
					name="showTimeLimit"
					v-model="trialDetails.showNextButton"
				>
					<option value="true">Yes</option>
					<option value="false">No</option>
				</select>
			</div>
		</div>
		<div class="grid-x">
			<div class="cell medium-11 large-offset-1">
				<FormValidationError
					:error="validation.endTrialsError"
					:showIf="
						!trialDetails.timeLimit &&
							!JSON.parse(
								trialDetails.nextTrialWhenAllTargetsSelected
							) &&
							!JSON.parse(trialDetails.showNextButton)
					"
				/>
			</div>
		</div>
		<div class="grid-x">
			<div class="cell medium-2 large-offset-1">
				<label for="trialGap">Trial Gap (ms)</label>
				<input
					type="number"
					name="trialGap"
					v-model="trialDetails.trialGap"
					:class="{
						invalid:
							validation.trialGapError &&
							(!trialDetails.trialGap ||
								parseInt(trialDetails.trialGap) <= 0),
					}"
				/>
				<FormValidationError
					:error="validation.trialGapError"
					:showIf="
						!trialDetails.trialGap ||
							parseInt(trialDetails.trialGap) <= 0
					"
				/>
			</div>
		</div>
		<div v-if="order === 'sequential'">
			<div class="grid-x">
				<div class="cell medium-1 large-offset-1">
					<label for="adaptive">Adaptive</label>
					<select
						name="adaptive"
						v-model="trialDetails.adaptive"
						@change="showOrHideAdaptiveRuleSelect"
						:disabled="trialDetails.numTrials < 2"
						:title="
							trialDetails.numTrials < 2
								? 'Adaptive rules require more than 1 trial'
								: ''
						"
					>
						<option value="false">No</option>
						<option value="true">Yes</option>
					</select>
				</div>
				<div
					class="cell medium-1"
					id="num-rules"
					v-if="showAdaptiveRuleSelect"
					data-cy="num-rules"
				>
					{{ trialDetails.adaptiveRules.length }} rule(s)
				</div>
			</div>
			<div class="grid-x" v-if="showAdaptiveRuleSelect">
				<div class="cell medium-1"></div>
				<div class="cell medium-3">
					<button
						class="button"
						@click="showAdaptiveRules()"
						data-cy="select-rules"
					>
						Rules
					</button>
				</div>
			</div>
		</div>
		<div class="grid-x">
			<div class="cell medium-11 large-offset-1 trial-section-title">
				Trial Rules/Practice Trial
			</div>
		</div>
		<div class="grid-x" v-if="order === 'sequential'">
			<div class="cell medium-11 large-offset-1">
				<label for="showTrialRules"
					>Show Trial Rules/Practice Trial</label
				>
				<select
					name="showTrialRules"
					v-model="trialDetails.showTrialRules"
				>
					<option value="false">No</option>
					<option value="true">Yes</option>
				</select>
			</div>
		</div>
		<div class="grid-x" v-if="order !== 'sequential'">
			<div class="cell medium-11 large-offset-1">
				<label for="showTargetReminder">Show Target Reminder</label>
				<select
					name="showTargetReminder"
					v-model="trialDetails.showTargetReminder"
				>
					<option value="false">No</option>
					<option value="true">Yes</option>
				</select>
			</div>
		</div>
		<div class="grid-x trial-info-row">
			<div class="cell medium-1 large-offset-1">
				<label for="numRows">Rows</label>
				<input
					type="number"
					name="practiceTrialNumRows"
					placeholder="3"
					v-model="trialDetails.practiceTrialNumRows"
					:class="{
						invalid:
							validation.practiceTrialNumRowsError &&
							(!trialDetails.practiceTrialNumRows ||
								parseInt(trialDetails.practiceTrialNumRows) <=
									0),
					}"
				/>
				<FormValidationError
					:error="validation.practiceTrialNumRowsError"
					:showIf="
						!trialDetails.practiceTrialNumRows ||
							parseInt(trialDetails.practiceTrialNumRows) <= 0
					"
				/>
			</div>
			<div class="cell medium-2">
				<label for="numNodesPerRow">Nodes Per Row</label>
				<input
					type="number"
					name="practiceTrialNumNodesPerRow"
					placeholder="15"
					v-model="trialDetails.practiceTrialNumNodesPerRow"
					:class="{
						invalid:
							validation.practiceTrialNumNodesPerRowError &&
							(!trialDetails.practiceTrialNumNodesPerRow ||
								parseInt(
									trialDetails.practiceTrialNumNodesPerRow
								) <= 0),
					}"
				/>
				<FormValidationError
					:error="validation.practiceTrialNumNodesPerRowError"
					:showIf="
						!trialDetails.practiceTrialNumNodesPerRow ||
							parseInt(
								trialDetails.practiceTrialNumNodesPerRow
							) <= 0
					"
				/>
			</div>
		</div>
		<div v-if="order === 'sequential'">
			<div class="grid-x">
				<div class="cell medium-11 large-offset-1 trial-section-title">
					Messages
				</div>
			</div>
			<div class="grid-x">
				<div class="cell medium-11 large-offset-1">
					<label for="preTrialMessage">Pre-Trial Message</label>
					<textarea
						name="preTrialMessage"
						v-model="trialDetails.preTrialMessage"
					/>
				</div>
			</div>
			<div class="grid-x">
				<div class="cell medium-11 large-offset-1">
					<label for="postTrialMessage">End-Trial Message</label>
					<textarea
						name="postTrialMessage"
						v-model="trialDetails.postTrialMessage"
					/>
				</div>
			</div>
		</div>
		<div class="grid-x">
			<div class="cell medium-11 large-offset-1 trial-section-title">
				Shapes
			</div>
		</div>
		<div class="grid-x">
			<div class="cell medium-11 large-offset-1">
				<ShapesSelect
					:shapes="targetShapes"
					:config="{
						title: 'Targets',
						name: 'targets',
						label: 'targets',
					}"
					@update-shapes="updateTargets"
					@show-target-select="showRuleGenerator"
				/>
			</div>
		</div>
		<div class="grid-x">
			<div class="cell medium-11 large-offset-1">
				<FormValidationError
					:error="validation.targetsError"
					:showIf="trialDetails.targets.length === 0"
				/>
			</div>
		</div>
		<div class="grid-x">
			<div class="cell medium-4 large-offset-1">
				<label for="targetProportion">Target Proportion (%)</label>
				<input
					type="number"
					name="targetProportion"
					v-model="targetProportion"
					disabled
					class="proportion"
				/>
			</div>
		</div>
		<div class="grid-x">
			<div class="cell medium-11 large-offset-1">
				<FormValidationError
					:error="validation.targetProportionError"
					:showIf="targetProportion < 1 || targetProportion > 100"
				/>
			</div>
		</div>
		<div class="grid-x">
			<div class="cell medium-11 large-offset-1">
				<ShapesSelect
					:shapes="trialDetails.nearDistractors"
					:config="{
						title: 'Near Distractors',
						name: 'nearDistractors',
						label: 'near-distractors',
					}"
					@update-shapes="updateTargets"
				/>
			</div>
		</div>
		<div class="grid-x">
			<div class="cell medium-11 large-offset-1">
				<FormValidationError
					:error="validation.nearDistractorsError"
					:showIf="trialDetails.nearDistractors.length === 0"
				/>
			</div>
		</div>
		<div class="grid-x">
			<div class="cell medium-4 large-offset-1">
				<label for="nearDistractorProportion"
					>Near Distractor Proportion (%)</label
				>
				<input
					type="number"
					name="nearDistractorProportion"
					v-model="trialDetails.nearDistractorProportion"
					class="proportion"
					:class="{
						invalid:
							trialDetails.nearDistractorProportion === null ||
							trialDetails.nearDistractorProportion < 0 ||
							trialDetails.nearDistractorProportion > 100,
					}"
				/>
			</div>
		</div>
		<div class="grid-x">
			<div class="cell medium-11 large-offset-1">
				<FormValidationError
					:error="validation.nearDistractorProportionError"
					:showIf="
						trialDetails.nearDistractorProportion === null ||
							trialDetails.nearDistractorProportion < 0 ||
							trialDetails.nearDistractorProportion > 100
					"
				/>
			</div>
		</div>
		<div class="grid-x">
			<div class="cell medium-11 large-offset-1">
				<ShapesSelect
					:shapes="trialDetails.farDistractors"
					:config="{
						title: 'Far Distractors',
						name: 'farDistractors',
						label: 'far-distractors',
					}"
					@update-shapes="updateTargets"
				/>
			</div>
		</div>
		<div class="grid-x">
			<div class="cell medium-11 large-offset-1">
				<FormValidationError
					:error="validation.farDistractorsError"
					:showIf="trialDetails.farDistractors.length === 0"
				/>
			</div>
		</div>
		<div class="grid-x">
			<div class="cell medium-4 large-offset-1">
				<label for="farDistractorProportion"
					>Far Distractor Proportion (%)</label
				>
				<input
					type="number"
					name="farDistractorProportion"
					v-model="farDistractorProportion"
					class="proportion"
					disabled
				/>
			</div>
		</div>
		<div class="grid-x">
			<div class="cell medium-11 large-offset-1">
				<FormValidationError
					:error="validation.farDistractorProportionError"
					:showIf="
						farDistractorProportion < 0 ||
							farDistractorProportion > 100
					"
				/>
			</div>
		</div>
		<div class="grid-x footer">
			<div class="cell medium-5 large-offset-1">
				<FormValidationError
					:error="errorPrompt"
					:showIf="formInvalid && !validateForm(trialDetails)"
				/>
			</div>
			<div class="cell medium-2 large-offset-4">
				<div class="buttons">
					<span data-tooltip title="Add/Update Trial">
						<div
							class="button save"
							@click="updateTrialClick()"
							data-cy="save-trial"
						>
							<font-awesome-icon icon="check"></font-awesome-icon>
						</div>
					</span>
					<span data-tooltip title="Close">
						<div
							class="button delete"
							@click="$emit('toggle-trial-details')"
							data-cy="close-trial"
						>
							<font-awesome-icon icon="times"></font-awesome-icon>
						</div>
					</span>
				</div>
			</div>
		</div>
		<modal
			name="target-select"
			:adaptive="true"
			width="90%"
			height="auto"
			class="modal"
			:clickToClose="false"
			:scrollable="true"
			data-cy="target-select"
		>
			<div class="content">
				<div class="top-right">
					<span data-tooltip title="Close">
						<button
							class="button close"
							@click="$modal.hide('target-select')"
							data-cy="close-targets"
						>
							<font-awesome-icon icon="times"></font-awesome-icon>
						</button>
					</span>
				</div>
				<TargetList
					v-if="trialDetails.targets"
					@update-targets="updateTargets"
				/>
			</div>
		</modal>
		<modal
			name="adaptive-rules"
			:adaptive="true"
			width="90%"
			height="auto"
			class="modal"
			:clickToClose="false"
			:scrollable="true"
			data-cy="rules-select"
		>
			<div class="content">
				<div class="top-right">
					<span data-tooltip title="Close">
						<button
							class="button close"
							@click="$modal.hide('adaptive-rules')"
							data-cy="close-rules"
						>
							<font-awesome-icon icon="times"></font-awesome-icon>
						</button>
					</span>
				</div>
				<AdaptiveRuleList
					v-if="trialDetails.adaptive"
					:trial="trialDetails"
					@update-adaptive-rules="updateAdaptiveRules"
				/>
			</div>
		</modal>
	</div>
</template>

<script>
	import { mapActions } from "vuex";
	import lodash from "lodash";

	import ShapesSelect from "@/components/ShapesSelect";
	import FormValidationError from "@/components/FormValidationError";
	import TargetList from "@/components/trial/target/TargetList";
	import AdaptiveRuleList from "@/components/trial/adaptiveRules/AdaptiveRuleList";

	export default {
		name: "TrialDetails",
		props: ["trial", "index", "order"],
		data() {
			return {
				showTimeLimit: false,
				showWithholdNResponse: false,
				showAdaptiveRuleSelect: false,
				validation: {
					numRowsError: "",
					numNodesPerRowError: "",
					paddingError: "",
					numTrialsError: "",
					endTrialsError: "",
					practiceTrialNumRowsError: "",
					practiceTrialNumNodesPerRowError: "",
					trialGapError: "",
					targetsError: "",
					targetProportionError: "",
					nearDistractorsError: "",
					nearDistractorProportionError: "",
					farDistractorsError: "",
					farDistractorProportionError: "",
				},
				formInvalid: false,
				errorPrompt: "There are errors on the form",
				trialDetails: null,
			};
		},
		components: {
			ShapesSelect,
			FormValidationError,
			TargetList,
			AdaptiveRuleList,
		},
		methods: {
			...mapActions([
				"addTrial",
				"updateTrial",
				"setTargetList",
				"setAdaptiveRuleList",
			]),
			updateTrialClick() {
				if (this.validateForm(this.trialDetails)) {
					if (this.trialDetails._id || this.trialDetails.tempId) {
						this.updateTrial(this.trialDetails);
					} else {
						this.addTrial(this.trialDetails);
					}
					this.$emit("toggle-trial-details");
				}
			},
			updateTargets(targets, type) {
				this.trialDetails[type] = targets;
				if (type === "targets") {
					this.$modal.hide("target-select");
				}
			},
			updateAdaptiveRules(rules) {
				this.trialDetails.adaptiveRules = rules;
				this.$modal.hide("adaptive-rules");
			},
			showOrHideShowTimeLimit(ev) {
				if (ev.target.value && ev.target.value !== "") {
					this.showTimeLimit = true;
				} else {
					this.showTimeLimit = false;
				}
			},
			validateForm(trial) {
				let isValid = true;

				if (!trial.numRows) {
					this.validation.numRowsError = "Required field";
					isValid = false;
				}

				if (parseInt(trial.numRows) <= 0) {
					this.validation.numRowsError = "Must be 1 or more";
					isValid = false;
				}

				if (!trial.numNodesPerRow) {
					this.validation.numNodesPerRowError = "Required field";
					isValid = false;
				}

				if (parseInt(trial.numNodesPerRow) <= 0) {
					this.validation.numNodesPerRowError = "Must be 1 or more";
					isValid = false;
				}

				if (!trial.padding) {
					this.validation.paddingError = "Required field";
					isValid = false;
				}

				if (parseInt(trial.padding) <= 0) {
					this.validation.paddingError = "Must be 1 or more";
					isValid = false;
				}

				if (!trial.numTrials) {
					this.validation.numTrialsError = "Required field";
					isValid = false;
				}

				if (parseInt(trial.numTrials) <= 0) {
					this.validation.numTrialsError = "Must be 1 or more";
					isValid = false;
				}

				if (!trial.practiceTrialNumRows) {
					this.validation.practiceTrialNumRowsError =
						"Required field";
					isValid = false;
				}

				if (parseInt(trial.practiceTrialNumRows) <= 0) {
					this.validation.practiceTrialNumRowsError =
						"Must be 1 or more";
					isValid = false;
				}

				if (!trial.practiceTrialNumNodesPerRow) {
					this.validation.practiceTrialNumNodesPerRowError =
						"Required field";
					isValid = false;
				}

				if (parseInt(trial.practiceTrialNumNodesPerRow) <= 0) {
					this.validation.practiceTrialNumNodesPerRowError =
						"Must be 1 or more";
					isValid = false;
				}

				if (
					!trial.timeLimit &&
					!JSON.parse(trial.nextTrialWhenAllTargetsSelected) &&
					!JSON.parse(trial.showNextButton)
				) {
					this.validation.endTrialsError =
						"Trials will never end, please add a time limit or set one or both of the above dropdowns to true";
					isValid = false;
				}

				if (parseInt(trial.trialGap) <= 0) {
					this.validation.trialGapError = "Must be 1 or more";
					isValid = false;
				}

				if (!trial.trialGap) {
					this.validation.trialGapError = "Required field";
					isValid = false;
				}

				if (trial.targets.length === 0) {
					this.validation.targetsError =
						"Must select at least 1 target";
					isValid = false;
				}

				if (
					parseInt(this.targetProportion) < 1 ||
					parseInt(this.targetProportion) > 100
				) {
					this.validation.targetProportionError =
						"Target proportion must be between 1 and 100%";
					isValid = false;
				}

				if (trial.nearDistractors.length === 0) {
					this.validation.nearDistractorsError =
						"Must select at least 1 near distractor";
					isValid = false;
				}

				if (
					trial.nearDistractorProportion === null ||
					parseInt(trial.nearDistractorProportion) < 0 ||
					parseInt(trial.nearDistractorProportion) > 100
				) {
					this.validation.nearDistractorProportionError =
						"Near distractor proportion must be between 0 and 100%";
					isValid = false;
				}

				if (trial.farDistractors.length === 0) {
					this.validation.farDistractorsError =
						"Must select at least 1 far distractor";
					isValid = false;
				}

				if (
					parseInt(this.farDistractorProportion) < 0 ||
					parseInt(this.farDistractorProportion) > 100
				) {
					this.validation.farDistractorProportionError =
						"Far distractor proportion must be between 0 and 100%";
					isValid = false;
				}

				this.formInvalid = !isValid;

				return isValid;
			},
			showRuleGenerator() {
				// set target list when opening modal to refresh every time
				this.setTargetList({
					targetList: lodash.cloneDeep(this.trialDetails.targets),
					referingComponent: this.$options.name,
				});
				this.$modal.show("target-select");
			},
			showAdaptiveRules() {
				this.setAdaptiveRuleList(
					lodash.cloneDeep(this.trialDetails.adaptiveRules)
				);
				this.$modal.show("adaptive-rules");
			},
			showOrHideWithholdNResponse(ev) {
				if (JSON.parse(ev.target.value) === true) {
					this.showWithholdNResponse = true;
				} else {
					this.showWithholdNResponse = false;
				}
			},
			showOrHideAdaptiveRuleSelect(ev) {
				if (JSON.parse(ev.target.value) === true) {
					this.showAdaptiveRuleSelect = true;
				} else {
					this.showAdaptiveRuleSelect = false;
				}
			},
		},
		computed: {
			farDistractorProportion() {
				return (
					100 -
					this.targetProportion -
					this.trialDetails.nearDistractorProportion
				);
			},
			targetProportion() {
				let proportion = 0;
				this.trialDetails.targets.forEach((element) => {
					proportion += parseInt(element.proportion);
				});
				return proportion;
			},
			targetShapes() {
				// concat all target shapes into a single array
				let shapes = [];
				this.trialDetails.targets.forEach((element) => {
					shapes = shapes.concat(element.shapes);
				});
				return shapes;
			},
		},
		created() {
			if (this.trial) {
				this.trialDetails = lodash.cloneDeep(this.trial);
				this.showAdaptiveRuleSelect = JSON.parse(
					this.trialDetails.adaptive
				);
			} else {
				this.trialDetails = {
					numRows: 1,
					numNodesPerRow: 1,
					padding: 10,
					timeLimit: null,
					showTimeLimit: false,
					showNextButton: false,
					nextTrialWhenAllTargetsSelected: true,
					numTrials: 1,
					targets: [],
					targetProportion: 20,
					nearDistractors: [],
					nearDistractorProportion: 20,
					farDistractors: [],
					scanningDirectionVertical: "tb",
					scanningDirectionHorizontal: "lr",
					scanningDirectionLineByLine: "sd",
					adaptive: false,
					adaptiveRules: [],
					showTrialRules: true,
					preTrialMessage: "",
					postTrialMessage: "",
					trialGap: 200,
					practiceTrialNumRows: 3,
					practiceTrialNumNodesPerRow: 15,
					showTargetReminder: true,
				};
			}
		},
	};
</script>

<style lang="scss">
	@include foundation-xy-grid-classes;
	@include foundation-button;
	@include foundation-forms;

	.trial-form {
		padding: 10px;
		background: $selectedBackground;

		.footer {
			.cell {
				.buttons {
					float: right;
				}
			}
		}

		.button.target-select {
			position: absolute;
		}

		.trial-info-row {
			.cell {
				margin-right: 5px;
			}
		}

		.trial-section-title {
			font-weight: bold;
			border-bottom: $border;
			line-height: 28px;
		}
	}

	.empty-label {
		height: 28px;
	}

	.proportion {
		width: 100px;
	}

	#num-rules {
		line-height: 93px;
	}
</style>
