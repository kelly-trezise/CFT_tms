<template>
	<div class="adaptive-rule-form">
		<div class="grid-x">
			<div class="cell medium-2 large-offset-1">
				After
				<select
					name="afterNTrials"
					v-model="ruleDetails.afterNTrials"
					@change="updateAfterNTrialsString()"
				>
					<option value="1">1 trial</option>
					<option
						v-for="i in trial.numTrials - 2"
						:key="i"
						:value="i + 1"
					>
						{{ i + 1 }} trials
					</option>
				</select>
			</div>
			<div class="cell medium-4">
				if the average
				<select
					name="averageStatistic"
					v-model="ruleDetails.averageStatistic"
					@change="updateAverageStatisticChange()"
				>
					<option value="selectedTargets">targets selected</option>
					<option value="timeRemaining" v-if="trial.timeLimit"
						>time remaining</option
					>
				</select>
				is
			</div>
			<div class="cell medium-1">
				<select
					name="averageStatisticComparison"
					v-model="ruleDetails.averageStatisticComparison"
				>
					<option value="lessThan">&lt;</option>
					<option value="greaterThan">&gt;</option>
				</select>
			</div>
			<div class="cell medium-1">
				<input
					type="number"
					name="averageStatisticPercentage"
					v-model="ruleDetails.averageStatisticPercentage"
					@keyup="updateAverageStatisticChange()"
					:class="{
						invalid:
							!ruleDetails.averageStatisticPercentage ||
							ruleDetails.averageStatisticPercentage < 0 ||
							ruleDetails.averageStatisticPercentage > 100 ||
							ruleDetails.averageStatisticPercentage === '',
					}"
				/>
			</div>
			<div class="cell medium-2">
				% {{ updatedAverageStatisticExample }}
			</div>
		</div>
		<div class="grid-x">
			<div class="cell medium-4 large-offset-8">
				<FormValidationError
					:error="validation.updateAverageStatisticChangeError"
					:showIf="
						!ruleDetails.averageStatisticPercentage ||
							ruleDetails.averageStatisticPercentage < 0 ||
							ruleDetails.averageStatisticPercentage > 100 ||
							ruleDetails.averageStatisticPercentage === ''
					"
				/>
			</div>
		</div>
		<div class="grid-x">
			<div class="cell medium-4 large-offset-3">
				then change
				<select
					name="updateVariable"
					v-model="ruleDetails.updateVariable"
					@change="updateVariableChange()"
				>
					<option value="gridSize">grid size</option>
					<option value="targetProportion">target proportion</option>
					<option value="timeLimit" v-if="trial.timeLimit"
						>time limit</option
					>
				</select>
				by
			</div>
			<div class="cell medium-1">
				<input
					type="number"
					name="updateVariableChange"
					v-model="ruleDetails.updateVariablePercentage"
					@keyup="updateVariableChange()"
					:class="{
						invalid:
							validation.updateVariableChangeError &&
							(!ruleDetails.updateVariablePercentage ||
								ruleDetails.updateVariablePercentage === ''),
					}"
				/>
				<FormValidationError
					:error="validation.updateVariableChangeError"
					:showIf="
						!ruleDetails.updateVariablePercentage ||
							ruleDetails.updateVariablePercentage === ''
					"
				/>
			</div>
			<div class="cell medium-3" data-cy="updated-variable-example">
				% ({{ updatedVariableExample }})
			</div>
		</div>
		<div class="grid-x">
			<div class="cell medium-3 large-offset-1">
				{{ updatedAfterNTrialsString }}
				<select name="continuous" v-model="ruleDetails.continuous">
					<option value="false">No, only check once</option>
					<option value="true">Yes</option>
				</select>
			</div>
		</div>
		<div class="grid-x footer">
			<div
				class="cell medium-2 large-offset-10"
				v-if="!ruleDetailsVisible"
			>
				<div class="buttons">
					<div
						class="button save"
						@click="updateAdaptiveRuleClick()"
						data-cy="save-rule"
					>
						<font-awesome-icon icon="check"></font-awesome-icon>
					</div>
					<div
						class="button close"
						@click="$emit('toggle-adaptive-rule-details')"
						data-cy="close-rule"
					>
						<font-awesome-icon icon="times"></font-awesome-icon>
					</div>
				</div>
			</div>
		</div>
	</div>
</template>

<script>
	import lodash from "lodash";

	import { mapActions } from "vuex";

	import FormValidationError from "@/components/FormValidationError";

	export default {
		name: "AdaptiveRuleDetails",
		props: ["rule", "index", "trial"],
		components: {
			FormValidationError,
		},
		data() {
			return {
				ruleDetailsVisible: false,
				updatedVariableExample: null,
				updatedAverageStatisticExample: null,
				updatedAfterNTrialsString: null,
				validation: {
					updateAverageStatisticChangeError: "",
					updateVariableChangeError: "",
				},
			};
		},
		methods: {
			...mapActions(["addAdaptiveRule", "updateAdaptiveRule"]),
			updateAdaptiveRuleClick() {
				if (this.validateForm(this.ruleDetails)) {
					if (this.ruleDetails._id || this.ruleDetails.tempId) {
						this.updateAdaptiveRule(this.ruleDetails);
					} else {
						this.addAdaptiveRule(this.ruleDetails);
					}
					this.$emit("toggle-adaptive-rule-details");
				}
			},
			validateForm(rule) {
				let isValid = true;

				if (
					!rule.averageStatisticPercentage ||
					rule.averageStatisticPercentage === ""
				) {
					this.validation.updateAverageStatisticChangeError =
						"Required field";
					isValid = false;
				}

				if (
					rule.averageStatisticPercentage < 0 ||
					rule.averageStatisticPercentage > 100
				) {
					this.validation.updateAverageStatisticChangeError =
						"Must be between 1 and 100";
					isValid = false;
				}

				if (
					!rule.updateVariablePercentage ||
					rule.updateVariablePercentage === ""
				) {
					this.validation.updateVariableChangeError =
						"Required field";
					isValid = false;
				}

				return isValid;
			},
			toggleNewAdaptiveRuleVisible(visible) {
				this.ruleDetailsVisible = visible;
			},
			updateAverageStatisticChange() {
				let newVarString = "";

				const perc = this.ruleDetails.averageStatisticPercentage / 100;

				if (this.ruleDetails.averageStatistic === "timeRemaining") {
					const secondsRemaining = Math.round(
						this.trial.timeLimit * perc
					);

					newVarString = `(e.g. ${secondsRemaining}s)`;
				}

				this.updatedAverageStatisticExample = newVarString;
			},
			updateVariableChange() {
				let newVarString = "";

				const perc = this.ruleDetails.updateVariablePercentage / 100;

				if (this.ruleDetails.updateVariable === "gridSize") {
					const numRows = parseInt(this.trialDetails.numRows);
					const calcNumRows = Math.round(numRows + numRows * perc);
					const numNodesPerRow = parseInt(
						this.trialDetails.numNodesPerRow
					);
					const calcNumNodesPerRow = Math.round(
						numNodesPerRow + numNodesPerRow * perc
					);

					newVarString = `e.g. from ${numRows}x${numNodesPerRow} to ${calcNumRows}x${calcNumNodesPerRow}`;
				} else if (
					this.ruleDetails.updateVariable === "targetProportion"
				) {
					let targetProportion = 0;
					this.trialDetails.targets.forEach((element) => {
						targetProportion += parseInt(element.proportion);
					});

					const calcTargetProportion = Math.round(
						targetProportion + targetProportion * perc
					);

					newVarString = `e.g. from ${targetProportion}% to ${calcTargetProportion}%`;
				} else if (this.ruleDetails.updateVariable === "timeLimit") {
					const timeLimit = parseInt(this.trialDetails.timeLimit);
					const calcTimeLimit = Math.round(
						timeLimit + timeLimit * perc
					);

					newVarString = `e.g. from ${this.trialDetails.timeLimit}s to ${calcTimeLimit}s`;
				}

				this.updatedVariableExample = newVarString;
			},
			updateAfterNTrialsString() {
				this.updatedAfterNTrialsString = `Check after every ${this.ruleDetails.afterNTrials} trial(s)?`;
			},
		},
		created() {
			if (this.rule) {
				this.ruleDetails = lodash.cloneDeep(this.rule);
			} else {
				this.ruleDetails = {
					afterNTrials: 1,
					averageStatistic: "selectedTargets",
					averageStatisticComparison: "lessThan",
					averageStatisticPercentage: 50,
					updateVariable: "targetProportion",
					updateVariablePercentage: 10,
					continuous: false,
				};
			}
			this.trialDetails = lodash.cloneDeep(this.trial);
			this.updateVariableChange();
			this.updateAverageStatisticChange();
			this.updateAfterNTrialsString();
		},
	};
</script>

<style lang="scss" scoped>
	.adaptive-rule-form {
		padding: 10px;
		background: $selectedBackground;

		line-height: 35px;

		.footer {
			margin-top: 10px;

			.cell {
				.buttons {
					float: right;
				}
			}
		}
	}
</style>
