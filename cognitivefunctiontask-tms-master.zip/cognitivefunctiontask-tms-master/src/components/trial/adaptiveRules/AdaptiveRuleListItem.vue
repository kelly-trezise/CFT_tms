<template>
	<div class="adaptive-rule-list-item">
		<div class="grid-x grid-list-row" v-if="!ruleForEdit" data-cy="rule">
			<div class="cell medium-1">
				{{ index }}
			</div>
			<div class="cell medium-1">{{ rule.afterNTrials }} trial(s)</div>
			<div class="cell medium-3">
				{{ formatCondition() }}
			</div>
			<div class="cell medium-2">
				{{ rule.updateVariable }}
			</div>
			<div class="cell medium-1">
				{{ rule.updateVariablePercentage }}%
			</div>
			<div class="cell medium-1">
				{{ rule.continuous | boolToText }}
			</div>
			<div class="cell medium-3">
				<div class="buttons">
					<span data-tooltip title="Edit Rule">
						<div
							class="button edit"
							@click="showAdaptiveRuleDetails()"
							data-cy="edit-rule"
						>
							<font-awesome-icon icon="edit"></font-awesome-icon>
						</div>
					</span>
					<span data-tooltip title="Delete Rule">
						<div
							class="button delete"
							@click="showDeleteRuleModal()"
							data-cy="delete-rule"
						>
							<font-awesome-icon
								icon="trash-alt"
							></font-awesome-icon>
						</div>
					</span>
					<span data-tooltip title="Duplicate Rule">
						<div
							class="button copy"
							@click="duplicateAdaptiveRule(rule)"
							data-cy="duplicate-rule"
						>
							<font-awesome-icon icon="copy"></font-awesome-icon>
						</div>
					</span>
				</div>
			</div>
		</div>
		<AdaptiveRuleDetails
			v-if="ruleForEdit"
			:rule="ruleForEdit"
			:index="index"
			:trial="trial"
			@toggle-adaptive-rule-details="hideAdaptiveRuleDetails"
		/>
	</div>
</template>

<script>
	import { mapActions } from "vuex";

	import AdaptiveRuleDetails from "@/components/trial/adaptiveRules/AdaptiveRuleDetails";

	export default {
		name: "AdaptiveRuleListItem",
		props: ["rule", "index", "trial"],
		components: {
			AdaptiveRuleDetails,
		},
		data() {
			return {
				ruleForEdit: null,
			};
		},
		methods: {
			...mapActions(["deleteAdaptiveRule", "duplicateAdaptiveRule"]),
			showAdaptiveRuleDetails() {
				this.ruleForEdit = this.rule;
				this.$emit("toggle-adaptive-rule-details");
			},
			hideAdaptiveRuleDetails() {
				this.ruleForEdit = null;
				this.$emit("toggle-adaptive-rule-details");
			},
			formatCondition() {
				let conditionString = "";

				conditionString += this.rule.averageStatistic;

				if (this.rule.averageStatisticComparison === "lessThan") {
					conditionString += " < ";
				} else if (
					this.rule.averageStatisticComparison === "greaterThan"
				) {
					conditionString += " > ";
				}

				conditionString += `${this.rule.averageStatisticPercentage}%`;

				return conditionString;
			},
			showDeleteRuleModal() {
				this.$modal.show("dialog", {
					title: `Delete rule`,
					text: `Are you sure you want to delete this rule?`,
					clickToClose: false,
					buttons: [
						{
							title: "Yes, delete it",
							default: true,
							handler: () => {
								this.deleteAdaptiveRule(this.rule);
								this.$modal.hide("dialog");
							},
							class: "modal-button red-text",
						},
						{
							title: "No",
							handler: () => {
								this.$modal.hide("dialog");
							},
							class: "modal-button",
						},
					],
				});
			},
		},
	};
</script>

<style></style>
