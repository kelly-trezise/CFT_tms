<template>
	<div class="grid-container">
		<div class="grid-x grid-list-title">
			<div class="cell medium-12">
				Adaptive Rules
			</div>
		</div>
		<div class="grid-x grid-list-header">
			<div class="cell medium-1"></div>
			<div class="cell medium-1">
				After
			</div>
			<div class="cell medium-3">
				Condition
			</div>
			<div class="cell medium-2">
				Change
			</div>
			<div class="cell medium-1">
				By
			</div>
			<div class="cell medium-1">
				Cont.
			</div>
		</div>
		<AdaptiveRuleListItem
			v-for="(rule, i) in adaptiveRuleList"
			:key="i"
			:rule="rule"
			:index="i + 1"
			:trial="trial"
			@toggle-adaptive-rule-details="toggleEditAdaptiveRule"
		/>
		<div
			class="grid-x grid-list-footer"
			v-if="!createAdaptiveRuleVisible && !editAdaptiveRuleVisible"
		>
			<div class="cell medium-2 large-offset-10">
				<div class="buttons">
					<span data-tooltip title="Create Rule">
						<div
							class="button add"
							@click="toggleCreateAdaptiveRule()"
							data-cy="create-rule"
						>
							<font-awesome-icon icon="plus"></font-awesome-icon>
						</div>
					</span>
				</div>
			</div>
		</div>
		<AdaptiveRuleDetails
			v-if="createAdaptiveRuleVisible"
			:trial="trial"
			@toggle-adaptive-rule-details="toggleCreateAdaptiveRule"
		/>
		<div class="grid-x grid-list-footer">
			<div
				class="cell medium-2 large-offset-10"
				v-if="!createAdaptiveRuleVisible && !editAdaptiveRuleVisible"
			>
				<div class="buttons">
					<span data-tooltip title="Update Adaptive Rules">
						<div
							class="button save"
							@click="saveAdaptiveRules()"
							data-cy="save-rules"
						>
							<font-awesome-icon icon="check"></font-awesome-icon>
						</div>
					</span>
				</div>
			</div>
		</div>
	</div>
</template>

<script>
	import { mapGetters, mapActions } from "vuex";

	import AdaptiveRuleDetails from "@/components/trial/adaptiveRules/AdaptiveRuleDetails";
	import AdaptiveRuleListItem from "@/components/trial/adaptiveRules/AdaptiveRuleListItem";

	export default {
		name: "AdaptiveRuleList",
		props: ["trial"],
		components: {
			AdaptiveRuleDetails,
			AdaptiveRuleListItem,
		},
		data() {
			return {
				createAdaptiveRuleVisible: false,
				editAdaptiveRuleVisible: false,
			};
		},
		methods: {
			...mapActions(["setAdaptiveRuleList"]),
			...mapGetters(["getAdaptiveRuleList"]),
			toggleCreateAdaptiveRule() {
				this.createAdaptiveRuleVisible = !this
					.createAdaptiveRuleVisible;
			},
			toggleEditAdaptiveRule() {
				this.editAdaptiveRuleVisible = !this.editAdaptiveRuleVisible;
			},
			saveAdaptiveRules() {
				this.$emit(
					"update-adaptive-rules",
					this.adaptiveRuleList,
					"adaptiveRules"
				);
			},
		},
		computed: {
			adaptiveRuleList() {
				return this.getAdaptiveRuleList();
			},
		},
	};
</script>

<style></style>
