<template>
	<div class="grid-container">
		<div class="grid-x grid-list-title">
			<div class="cell medium-12">
				Trials
			</div>
		</div>
		<div class="grid-x grid-list-header" v-if="trialList.length > 0">
			<div class="cell medium-1"></div>
			<div class="cell medium-1">Rows</div>
			<div class="cell medium-1">NPR</div>
			<div class="cell medium-1">TL (S)</div>
			<div class="cell medium-1">SD</div>
			<div class="cell medium-3">Targets</div>
			<div class="cell medium-1">Trials</div>
		</div>
		<draggable
			class="trial-list"
			v-model="trialList"
			draggable=".draggable"
		>
			<TrialListItem
				v-for="(trial, i) in trialList"
				:class="{ draggable: !createTrialVisible && !editTrialVisible }"
				:key="trial._id"
				:trial="trial"
				:index="i + 1"
				:order="order"
				@trial-preview="generateTrialPreview"
				@toggle-trial-details="toggleEditTrial"
			/>
		</draggable>
		<div
			class="grid-x grid-list-row empty-warning"
			v-if="trialList.length === 0 && !createTrialVisible"
		>
			<div class="cell medium-12">
				Please add a trial
			</div>
		</div>
		<div
			class="grid-x grid-list-footer"
			v-if="!createTrialVisible && !editTrialVisible"
		>
			<div class="cell medium-1 large-offset-11">
				<div class="buttons">
					<span data-tooltip title="Create Trial">
						<div
							class="button add"
							@click="toggleCreateTrial()"
							data-cy="create-trial"
						>
							<font-awesome-icon icon="plus"></font-awesome-icon>
						</div>
					</span>
				</div>
			</div>
		</div>
		<TrialDetails
			v-if="createTrialVisible"
			:order="order"
			@toggle-trial-details="toggleCreateTrial"
		/>
		<modal
			name="trial-preview"
			id="trial-preview"
			:adaptive="true"
			width="80%"
			height="auto"
			class="modal"
			data-cy="trial-preview"
		>
			<div class="content">
				<div class="top-right">
					<button
						class="button close"
						@click="$modal.hide('trial-preview')"
						data-cy="close-trial-preview"
					>
						<font-awesome-icon icon="times"></font-awesome-icon>
					</button>
				</div>
				<GeneratedTrial :trial="generatedTrial" />
			</div>
		</modal>
	</div>
</template>

<script>
	import draggable from "vuedraggable";

	import TrialListItem from "@/components/trial/TrialListItem";
	import TrialDetails from "@/components/trial/TrialDetails";
	import GeneratedTrial from "@/components/task/GeneratedTrial";

	import { mapGetters, mapActions } from "vuex";

	export default {
		name: "TrialList",
		components: {
			TrialListItem,
			TrialDetails,
			GeneratedTrial,
			draggable,
		},
		props: ["order"],
		data() {
			return {
				createTrialVisible: false,
				editTrialVisible: false,
				generatedTrial: null,
			};
		},
		methods: {
			...mapActions(["setTrialList"]),
			...mapGetters(["getTrialList"]),
			generateTrialPreview(trial) {
				this.generatedTrial = trial;
				this.$modal.show("trial-preview");
			},
			toggleCreateTrial() {
				this.createTrialVisible = !this.createTrialVisible;
				this.$emit("toggle-is-editing", this.createTrialVisible);
			},
			toggleEditTrial() {
				this.editTrialVisible = !this.editTrialVisible;
				this.$emit("toggle-is-editing", this.editTrialVisible);
			},
		},
		computed: {
			trialList: {
				get() {
					return this.getTrialList();
				},
				set(trialList) {
					this.setTrialList(trialList);
				},
			},
		},
	};
</script>

<style lang="scss" scoped>
	@include foundation-xy-grid-classes;
	@include foundation-button;

	#trial-preview {
		.content {
			height: 100%;
		}
	}
</style>
