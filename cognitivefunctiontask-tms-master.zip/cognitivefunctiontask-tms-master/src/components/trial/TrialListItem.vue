<template>
	<div class="trial-list-item">
		<div
			class="grid-x grid-list-row sortable"
			v-if="!trialForEdit"
			data-cy="trial"
		>
			<div class="cell medium-1">{{ index }}</div>
			<div class="cell medium-1">{{ trial.numRows }}</div>
			<div class="cell medium-1">
				{{ trial.numNodesPerRow }}
			</div>
			<div class="cell medium-1" v-if="trial.timeLimit">
				{{ trial.timeLimit }}s ({{
					trial.showTimeLimit | boolToTextShort
				}})
			</div>
			<div class="cell medium-1" v-if="!trial.timeLimit"></div>
			<div class="cell medium-1">
				{{ trial.scanningDirectionVertical }}
				{{ trial.scanningDirectionHorizontal }}
				{{ trial.scanningDirectionLineByLine | stringLimit(2) }}
			</div>
			<div class="cell medium-3">
				<ShapesSummary :shapes="shapes" :limit="true" />
			</div>
			<div class="cell medium-1">
				{{ trial.numTrials }}
			</div>
			<div class="cell medium-3">
				<div class="buttons">
					<span data-tooltip title="Edit Trial">
						<div
							class="button edit"
							@click="showTrialDetails()"
							data-cy="edit-trial"
						>
							<font-awesome-icon icon="edit"></font-awesome-icon>
						</div>
					</span>
					<span data-tooltip title="Delete Trial">
						<div
							class="button delete"
							@click="showDeleteTrialModal()"
							data-cy="delete-trial"
						>
							<font-awesome-icon
								icon="trash-alt"
							></font-awesome-icon>
						</div>
					</span>
					<span data-tooltip title="Duplicate Trial">
						<div
							class="button copy"
							@click="duplicateTrial(trial)"
							data-cy="duplicate-trial"
						>
							<font-awesome-icon icon="copy"></font-awesome-icon>
						</div>
					</span>
					<span data-tooltip title="Preview Trial Grid">
						<div
							class="button view"
							@click="$emit('trial-preview', trial)"
							data-cy="preview-trial"
						>
							<font-awesome-icon icon="eye"></font-awesome-icon>
						</div>
					</span>
				</div>
			</div>
		</div>
		<TrialDetails
			v-if="trialForEdit"
			:trial="trialForEdit"
			:index="index"
			:order="order"
			@toggle-trial-details="hideTrialDetails"
		/>
	</div>
</template>

<script>
	import TrialDetails from "@/components/trial/TrialDetails";
	import ShapesSummary from "@/components/ShapesSummary";
	import { mapActions } from "vuex";

	export default {
		name: "TrialListItem",
		props: ["trial", "index", "order"],
		components: {
			TrialDetails,
			ShapesSummary,
		},
		data() {
			return {
				trialForEdit: null,
				publicPath: process.env.BASE_URL,
			};
		},
		methods: {
			...mapActions(["deleteTrial", "duplicateTrial"]),
			showDeleteTrialModal() {
				this.$modal.show("dialog", {
					title: `Delete trial`,
					text: `Are you sure you want to delete this trial?`,
					buttons: [
						{
							title: "Yes, delete it",
							default: true,
							handler: () => {
								this.deleteTrial(this.trial);
								this.$modal.hide("dialog");
							},
							class: "modal-button red-text",
						},
						{
							title: "No",
							handler: () => {
								this.$modal.hide("dialog");
							},
							class: "modal-button",
						},
					],
				});
			},
			showTrialDetails() {
				this.trialForEdit = this.trial;
				this.$emit("toggle-trial-details");
			},
			hideTrialDetails() {
				this.trialForEdit = null;
				this.$emit("toggle-trial-details");
			},
		},
		computed: {
			shapes() {
				// concat all target shapes into a single array
				let shapes = [];
				this.trial.targets.forEach((element) => {
					shapes = shapes.concat(element.shapes);
				});
				return shapes;
			},
		},
	};
</script>

<style lang="scss" scoped>
	@include foundation-xy-grid-classes;
	@include foundation-button;
</style>
