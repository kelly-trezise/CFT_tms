<template>
	<div class="trial" data-cy="trial-grid">
		<div
			class="row"
			v-for="(row, i) in grid"
			:key="i"
			:style="{ 'max-height': calcRowHeight() + '%' }"
		>
			<div
				class="shape"
				v-for="(shape, j) in row"
				:key="j"
				:class="{
					target:
						shape.isTarget & showColours.all & showColours.target,
					'not-nth-target':
						shape.isNotNthTarget &
						showColours.all &
						showColours.notNthTarget,
					'distractor-target':
						shape.isDistractorTarget &
						showColours.all &
						showColours.distractorTarget,
					'is-relationship':
						shape.isRelationship &
						showColours.all &
						showColours.isRelationship,
					'near-distractor':
						shape.isNearDistractor &
						showColours.all &
						showColours.nearDistractor,
					'far-distractor':
						shape.isFarDistractor &
						showColours.all &
						showColours.farDistractor,
					'withhold-response':
						shape.withholdResponse &
						showColours.all &
						showColours.withholdResponse,
				}"
				:style="{
					margin: padding / 20 + '%',
					'flex-basis': calcBasis(shape, row),
				}"
			>
				<div class="numbers" v-if="showColours.numbers">
					{{ shape.overallPosition }}
				</div>
				<div
					class="shape-img"
					:style="{
						'background-image': `url(${publicPath}img/shapes/${shape.file})`,
					}"
				></div>
			</div>
		</div>
	</div>
</template>

<script>
	export default {
		name: "TrialGrid",
		props: ["grid", "padding", "showColours"],
		data() {
			return {
				publicPath: process.env.BASE_URL,
			};
		},
		methods: {
			calcRowHeight() {
				return 100 / this.grid.length;
			},
			getRowWidth(row) {
				let rowWidth = 0;
				row.forEach((shape) => {
					rowWidth += shape.width;
				});
				return rowWidth;
			},
			calcBasis(shape, row) {
				return (shape.width / this.getRowWidth(row)) * 100 + "%";
			},
		},
	};
</script>

<style lang="scss" scoped>
	.trial {
		width: 100%;
		height: 65vh;
		display: flex;
		flex-direction: column;
		min-height: 0;
	}

	.row {
		display: flex;
		flex-direction: row;
		min-height: 0;
		justify-content: space-between;
		flex: 1;
	}

	.shape {
		flex: 1 1 auto;

		.shape-img {
			background-repeat: no-repeat;
			background-size: contain;
			background-position: center;
			height: 100%;
		}
	}

	.target {
		background-color: $target;
	}

	.not-nth-target {
		background-color: $notNthTarget !important;
	}

	.distractor-target {
		background-color: $distractorTarget;
	}

	.near-distractor {
		background-color: $nearDistractor;
	}

	.is-relationship {
		background-color: $isRelationship;
	}

	.far-distractor {
		background-color: $farDistractor;
	}

	.withhold-response {
		filter: $withholdResponse;
	}

	.numbers {
		position: absolute;
	}
</style>
