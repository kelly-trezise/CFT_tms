<template>
	<div class="grid-container">
		<div class="grid-x">
			<div class="cell medium-3">
				<input
					type="text"
					name="search"
					placeholder="Search..."
					v-model="searchQuery"
				/>
			</div>
		</div>
		<div class="grid-x grid-list-header sortable">
			<div
				class="cell medium-3"
				@click="sortBy('name')"
				:class="setSortingIconClass('name')"
			>
				Name
			</div>
			<div
				class="cell medium-4"
				@click="sortBy('email')"
				:class="setSortingIconClass('email')"
			>
				Email
			</div>
			<div
				class="cell medium-3"
				@click="sortBy('admin')"
				:class="setSortingIconClass('admin')"
			>
				Admin
			</div>
		</div>
		<UserListItem
			v-for="user in orderedAndSearchedUserList"
			:key="user._id"
			:user="user"
		/>
		<div class="grid-x grid-list-footer ">
			<div class="cell medium-1 large-offset-11">
				<div class="buttons">
					<router-link
						:to="{ name: 'CreateUser' }"
						class="button add"
						data-cy="create-user"
						><font-awesome-icon icon="plus"></font-awesome-icon
					></router-link>
				</div>
			</div>
		</div>
	</div>
</template>

<script>
	import lodash from "lodash";
	import { mapGetters, mapActions } from "vuex";

	import UserListItem from "@/components/user/UserListItem";

	export default {
		name: "UserList",
		components: {
			UserListItem,
		},
		data() {
			return {
				sortByColumn: "email",
				sortByOrder: "asc",
				searchQuery: "",
			};
		},
		methods: {
			...mapActions(["getUsers"]),
			sortBy(column) {
				this.sortByColumn = column;
				if (this.sortByOrder === "asc") {
					this.sortByOrder = "desc";
				} else {
					this.sortByOrder = "asc";
				}
			},
			setSortingIconClass(column) {
				return {
					asc:
						this.sortByColumn === column &&
						this.sortByOrder === "asc",
					desc:
						this.sortByColumn === column &&
						this.sortByOrder === "desc",
				};
			},
		},
		computed: {
			...mapGetters(["userList"]),
			orderedAndSearchedUserList() {
				let filteredUserList = this.userList;

				if (this.searchQuery) {
					filteredUserList = filteredUserList.filter((user) => {
						return (
							user.name
								.toLowerCase()
								.indexOf(this.searchQuery.toLowerCase()) > -1 ||
							user.email
								.toLowerCase()
								.indexOf(this.searchQuery.toLowerCase()) > -1
						);
					});
				}

				return lodash.orderBy(
					filteredUserList,
					(o) => {
						return o[this.sortByColumn] || "";
					},
					this.sortByOrder
				);
			},
		},
		created() {
			this.getUsers();
		},
	};
</script>

<style lang="scss" scoped></style>
