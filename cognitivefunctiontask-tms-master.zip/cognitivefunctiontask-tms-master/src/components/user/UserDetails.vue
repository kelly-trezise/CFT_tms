<template>
	<div class="grid-container" v-if="user">
		<div class="grid-x">
			<div class="cell medium-3">
				<label for="name" class="data-title">
					Name
				</label>
				<input
					type="text"
					name="name"
					autocomplete="no"
					v-model="userDetails.name"
					:class="{
						invalid:
							validation.nameError && userDetails.name === '',
					}"
				/>
				<FormValidationError
					:error="validation.nameError"
					:showIf="userDetails.name === ''"
				/>
			</div>
			<div class="cell medium-5 large-offset-1">
				<label for="email" class="data-title">
					Email
				</label>
				<input
					type="email"
					name="email"
					autocomplete="no"
					v-model="userDetails.email"
					:class="{
						invalid:
							(validation.emailError &&
								userDetails.email === '') ||
							!emailValid ||
							emailExists,
					}"
				/>
				<FormValidationError
					:error="validation.emailError"
					:showIf="
						userDetails.email === '' || !emailValid || emailExists
					"
				/>
			</div>
			<div class="cell medium-2 large-offset-1">
				<label for="admin" class="data-title">Admin</label>
				<select name="admin" v-model="userDetails.admin">
					<option value="true">Yes</option>
					<option value="false">No</option>
				</select>
			</div>
		</div>
		<div class="grid-x">
			<div class="cell medium-4">
				<label for="password" class="data-title">
					Password
				</label>
				<input
					type="password"
					name="password"
					autocomplete="no"
					v-model="userDetails.password"
					@keyup="updateProp"
					:class="{
						invalid: !passwordValid.valid,
					}"
				/>
				<div class="errors" v-if="passwordValid.errors.length > 0">
					<div
						class="error"
						v-for="(error, i) in passwordValid.errors"
						:key="i"
					>
						<FormValidationError :error="error" :showIf="true" />
					</div>
				</div>
			</div>
		</div>
		<div class="grid-x">
			<div class="cell medium-4">
				<label for="password-confirm" class="data-title">
					Confirm Password
				</label>
				<input
					type="password"
					autocomplete="no"
					name="password-confirm"
					v-model="passwordConfirmInput"
					:class="{
						invalid:
							validation.passwordError &&
							userDetails.password !== passwordConfirmInput,
					}"
				/>
				<FormValidationError
					:error="validation.passwordError"
					:showIf="userDetails.password !== passwordConfirmInput"
				/>
			</div>
		</div>
		<div class="grid-x grid-list-footer">
			<div class="cell medium-1 large-offset-11">
				<div class="buttons">
					<button
						class="button save"
						@click="updateUserClick()"
						data-cy="save-user"
					>
						<font-awesome-icon icon="save"></font-awesome-icon>
					</button>
				</div>
			</div>
		</div>
	</div>
</template>

<script>
	import { mapActions, mapGetters } from "vuex";
	import router from "@/router";

	import FormValidationError from "@/components/FormValidationError";

	export default {
		name: "UserDetails",
		props: ["user"],
		components: {
			FormValidationError,
		},
		data() {
			return {
				userDetails: null,
				passwordConfirmInput: "",
				validation: {
					nameError: "",
					emailError: "",
					passwordError: "",
				},
				passwordRules: [
					{ message: "8 characters minimum", regex: /.{8,}/ },
					{
						message: "One lowercase letter required",
						regex: /[a-z]+/,
					},
					{
						message: "One uppercase letter required",
						regex: /[A-Z]+/,
					},
					{ message: "One number required", regex: /[0-9]+/ },
				],
				passwordValid: { valid: true, errors: [] },
			};
		},
		methods: {
			...mapActions(["addUser", "updateUser"]),
			...mapGetters(["userList"]),
			updateUserClick() {
				if (this.validateForm(this.userDetails)) {
					if (this.userDetails._id) {
						this.updateUser(this.userDetails);
					} else {
						this.addUser(this.userDetails);
					}
					this.$emit("save-clicked");
					router.push({ name: "Users" });
				}
			},
			validateForm(user) {
				let isValid = true;

				if (user.name === "") {
					this.validation.nameError = "Name is required";
					isValid = false;
				}

				if (user.email === "") {
					this.validation.emailError = "Email is required";
					isValid = false;
				}

				if (!this.emailValid) {
					this.validation.emailError = "Email is not valid";
					isValid = false;
				}

				if (this.emailExists) {
					this.validation.emailError = "Another user has this email";
					isValid = false;
				}

				if (!user._id) {
					// only check password if creating new user
					if (user.password === "") {
						this.validation.passwordError = "Password is required";
						isValid = false;
					}
				}

				if (user.password.length > 0) {
					// password policy
					if (!this.passwordValid.valid) {
						isValid = false;
					}

					if (user.password !== this.passwordConfirmInput) {
						this.validation.passwordError = "Passwords must match";
						isValid = false;
					}
				}

				return isValid;
			},
			updateProp(ev) {
				this.userDetails.password = ev.target.value;
				if (this.userDetails.password) {
					let errors = [];
					for (let condition of this.passwordRules) {
						if (!condition.regex.test(this.userDetails.password)) {
							errors.push(condition.message);
						}
					}
					if (errors.length === 0) {
						this.passwordValid = { valid: true, errors };
					} else {
						this.passwordValid = { valid: false, errors };
					}
				} else {
					this.passwordValid = { valid: true, errors: [] };
				}
			},
		},
		computed: {
			emailValid() {
				const re = /\S+@\S+\.\S+/;
				if (this.userDetails.email) {
					return re.test(
						String(this.userDetails.email).toLowerCase()
					);
				} else {
					return true;
				}
			},
			emailExists() {
				return (
					this.userList().filter(
						(u) =>
							u.email === this.userDetails.email &&
							u._id !== this.userDetails._id
					).length > 0
				);
			},
		},
		created() {
			if (this.user) {
				this.userDetails = this.user;
				this.userDetails.password = "";
			}
		},
	};
</script>

<style></style>
