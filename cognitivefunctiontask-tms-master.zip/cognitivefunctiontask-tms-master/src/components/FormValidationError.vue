<template>
	<div class="validationError" v-if="error && showIf" data-cy="validation">
		<font-awesome-icon icon="exclamation-triangle"></font-awesome-icon
		><span class="errorText">{{ error }}</span>
	</div>
</template>

<script>
	export default {
		name: "FormValidationError",
		props: ["error", "showIf"],
	};
</script>

<style lang="scss" scoped>
	.validationError {
		color: #e54d42;
		margin-bottom: 10px;

		.errorText {
			margin-left: 5px;
			font-style: italic;
		}
	}
</style>
