<template>
	<div class="grid-container">
		<div class="grid-x shape-select">
			<div class="cell medium-12">
				<label :for="config.label" v-if="config.label">{{
					config.title
				}}</label>
				<div class="selected-shapes" data-cy="selected-shapes">
					<div
						class="shape"
						v-for="(shape, i) in selectedShapes"
						:key="i"
						:style="{
							'background-image': `url(${publicPath}img/shapes/${shape})`,
						}"
					></div>
				</div>
				<select
					multiple
					:name="config.label"
					ref="shapeSelect"
					v-model="selectedShapes"
					v-if="displayShapesSelect && !isSafari"
					@focusout="saveSelectedShapes()"
				>
					<option
						v-for="(shape, i) in allShapes"
						:key="i"
						:value="shape.file"
						class="shape"
						:style="{
							'background-image': `url(${publicPath}img/shapes/${shape.file})`,
						}"
					>
					</option>
				</select>
				<!-- Safari fallback because it can't load background images in selects -->
				<select
					multiple
					:name="config.label"
					ref="shapeSelect"
					v-model="selectedShapes"
					class="text-list"
					v-if="displayShapesSelect && isSafari"
					@focusout="saveSelectedShapes()"
				>
					<option
						v-for="(shape, i) in allShapes"
						:key="i"
						:value="shape.file"
					>
						{{ shape.file }}
					</option>
				</select>
				<div class="warning" v-if="displayShapesSelect && isSafari">
					<font-awesome-icon
						icon="exclamation-triangle"
					></font-awesome-icon>
					Shape selection appears as filename only in Safari.
					<br />To view these as images please use Chrome or Firefox.
				</div>
			</div>
		</div>
		<div class="grid-x">
			<div class="cell medium-12" v-if="!displayShapesSelect">
				<div
					class="button"
					@click="toggleShapesSelect()"
					data-cy="select-shapes"
				>
					Select
				</div>
				<div
					class="button secondary"
					@click="setDefaultsClick()"
					v-if="isNotShapesSelect"
					data-cy="default-shapes"
				>
					Default
				</div>
			</div>
			<div class="cell medium-12" v-if="displayShapesSelect">
				<div
					class="button"
					@click="saveSelectedShapes()"
					data-cy="save-shapes"
				>
					Close
				</div>
			</div>
		</div>
	</div>
</template>

<script>
	import lodash from "lodash";

	import { shapes } from "@/data/Shapes.js";
	import { defaults } from "@/data/Config.js";

	export default {
		name: "ShapesSelect",
		props: ["shapes", "config"],
		data() {
			return {
				publicPath: process.env.BASE_URL,
				displayShapesSelect: false,
				selectedShapes: [],
				isSafari: this.$browserDetect.isSafari,
			};
		},
		methods: {
			toggleShapesSelect() {
				if (this.config.name === "targets") {
					this.$emit("show-target-select");
				} else {
					this.displayShapesSelect = !this.displayShapesSelect;
					if (this.displayShapesSelect) {
						this.$nextTick(() => {
							this.$refs.shapeSelect.focus();
						});
					}
				}
			},
			saveSelectedShapes() {
				this.$emit(
					"update-shapes",
					this.selectedShapes,
					this.config.name
				);
				this.toggleShapesSelect();
			},
			showSetDefaultsModal() {
				this.$modal.show("dialog", {
					title: `Are you sure you want to set default targets?`,
					text: `This will delete any existing rules.`,
					buttons: [
						{
							title: "Yes, set defaults",
							default: true,
							handler: () => {
								this.setDefaults();
								this.$modal.hide("dialog");
							},
							class: "modal-button red-text",
						},
						{
							title: "No",
							handler: () => {
								this.$modal.hide("dialog");
							},
							class: "modal-button",
						},
					],
				});
			},
			setDefaultsClick() {
				if (
					this.shapes &&
					this.shapes.length > 0 &&
					this.config.name === "targets"
				) {
					this.showSetDefaultsModal();
				} else {
					this.setDefaults();
				}
			},
			setDefaults() {
				this.selectedShapes = lodash.cloneDeep(
					defaults[this.config.name]
				);
				this.$emit(
					"update-shapes",
					this.selectedShapes,
					this.config.name
				);
			},
		},
		computed: {
			allShapes() {
				return shapes;
			},
			isNotShapesSelect() {
				return this.config.name !== "shapes";
			},
		},
		watch: {
			shapes() {
				this.selectedShapes = this.shapes;
			},
		},
		created() {
			// create a new property to stop prop edit error
			this.selectedShapes = this.shapes;

			// https://stackoverflow.com/questions/9847580/how-to-detect-safari-chrome-ie-firefox-and-opera-browser
		},
	};
</script>

<style lang="scss" scoped>
	@include foundation-xy-grid-classes;
	@include foundation-button;
	@include foundation-forms;

	.shape-select {
		width: 100%;
	}

	.selected-shapes {
		width: 100%;
		height: fit-content;

		.shape {
			background-size: contain;
			background-repeat: no-repeat;
			height: 50px;
			width: 50px;
			display: inline-block;
		}
	}

	select {
		width: 100%;
		// overflow: hidden;
		margin-top: 10px;

		&.text-list {
			height: 400px !important;
		}

		.shape {
			height: 70px;
			width: 70px;
			background-size: contain;
			background-repeat: no-repeat;
			margin: 5px 0;
			float: left;
		}
	}

	.warning {
		color: darkorange;
		line-height: 25px;
	}

	.buttons {
		margin-top: 10px;
	}

	.target-select {
		margin-left: 5px;
	}

	.button {
		margin-top: 9px;
		margin-right: 5px;
	}
</style>
