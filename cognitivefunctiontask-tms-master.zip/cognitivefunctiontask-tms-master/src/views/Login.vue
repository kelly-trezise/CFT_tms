<template>
	<div class="grid-container">
		<div class="grid-x">
			<div class="cell medium-4 large-offset-4">
				<label for="email">Email</label>
				<input
					type="text"
					name="email"
					v-model="email"
					:class="{
						invalid:
							(validation.emailError && email.length === 0) ||
							validation.loginError.includes('email'),
					}"
				/>
				<FormValidationError
					:error="validation.emailError"
					:showIf="email.length === 0"
				/>
			</div>
		</div>
		<div class="grid-x">
			<div class="cell medium-4 large-offset-4">
				<label for="password">Password:</label>
				<input
					type="password"
					name="password"
					v-on:keyup.enter="submit()"
					v-model="password"
					:class="{
						invalid:
							(validation.passwordError &&
								password.length === 0) ||
							validation.loginError.includes('password'),
					}"
				/>
				<FormValidationError
					:error="validation.passwordError"
					:showIf="password.length === 0"
				/>
			</div>
		</div>
		<div class="grid-x">
			<div class="cell medium-4 large-offset-4">
				<input
					type="checkbox"
					name="rememberMe"
					v-model="rememberMe"
				/>Remember me (uses cookies)
			</div>
		</div>
		<div class="grid-x">
			<div class="cell medium-1 large-offset-4">
				<button class="button" @click="submit()" data-cy="submit">
					Login
				</button>
			</div>
		</div>
		<div class="grid-x">
			<div class="cell medium-4 large-offset-4">
				<div class="loginError" v-if="validation.loginError">
					<font-awesome-icon icon="times-circle"></font-awesome-icon
					><span class="errorText">{{ validation.loginError }}</span>
				</div>
			</div>
		</div>
	</div>
</template>

<script>
	import FormValidationError from "@/components/FormValidationError";

	import UserService from "@/services/UserService";
	const userService = new UserService();

	export default {
		name: "Login",
		components: {
			FormValidationError,
		},
		data() {
			return {
				email: "",
				password: "",
				rememberMe: false,
				validation: {
					emailError: "",
					passwordError: "",
					loginError: "",
				},
			};
		},
		methods: {
			submit() {
				if (this.validateForm()) {
					userService
						.login(this.email, this.password, this.rememberMe)
						.then((resp) => {
							if (resp.error) {
								this.validation.loginError = resp.error;
							} else {
								if (userService.getJwt()) {
									if (this.$route.params.nextUrl) {
										this.$router.push(
											this.$route.params.nextUrl
										);
									} else {
										this.$router.push("/");
									}
								}
							}
						});
				}
			},
			validateForm() {
				let isValid = true;

				if (this.email === "") {
					this.validation.emailError = "Email is required";
					isValid = false;
				}

				if (this.password === "") {
					this.validation.passwordError = "Password is required";
					isValid = false;
				}

				return isValid;
			},
		},
	};
</script>

<style lang="scss" scoped>
	@include foundation-xy-grid-classes;
	@include foundation-forms;
	@include foundation-button;

	.loginError {
		background: #e54d42;
		color: white;
		padding: 10px;

		.errorText {
			margin-left: 5px;
			line-height: 22px;
		}
	}

	.invalid {
		border: #e54d42 solid thin;
	}

	input[type="checkbox"] {
		margin-right: 10px;
	}
</style>
