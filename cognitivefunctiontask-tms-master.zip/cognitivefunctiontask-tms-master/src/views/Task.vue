<template>
	<div class="task">
		<TaskDetails
			v-if="taskDetails"
			:task="taskDetails"
			@save-clicked="saved = true"
		/>
	</div>
</template>

<script>
	import TaskDetails from "@/components/task/TaskDetails";
	import { mapGetters, mapActions } from "vuex";

	import UserService from "@/services/UserService";
	const userService = new UserService();

	export default {
		name: "Task",
		components: {
			TaskDetails,
		},
		data() {
			return {
				saved: false,
			};
		},
		methods: {
			...mapActions(["getTasks"]),
		},
		created() {
			if (this.$route.params.id) {
				this.getTasks();
			}
		},
		computed: {
			...mapGetters(["getTask"]),
			taskDetails() {
				if (this.$route.params.id) {
					const task = this.getTask(this.$route.params.id);
					return task;
				} else {
					return {
						name: "",
						description: "",
						customUrl: null,
						authorId: userService.getCurrentUserInfo()._id,
						dateCreated: null,
						lastModifierId: null,
						dateModified: null,
						trialOrder: "sequential",
						lockForEdit: false,
						editPermissions: [userService.getCurrentUserInfo()._id],
						theme: "basic",
						trials: [],
						tutorialTargetProportion: 50,
						tutorialDemoCycleSpeed: 100,
						firstDemoTargets: [
							"L_0_sharp.png",
							"L_90_sharp.png",
							"L_180_sharp.png",
							"L_270_sharp.png",
						],
						firstDemoScanningDirectionVertical: "tb",
						firstDemoScanningDirectionHorizontal: "lr",
						firstDemoScanningDirectionLineByLine: "sd",
						secondDemoTargets: [
							"T_0_sharp.png",
							"T_90_sharp.png",
							"T_180_sharp.png",
							"T_270_sharp.png",
						],
						secondDemoScanningDirectionVertical: "bt",
						secondDemoScanningDirectionHorizontal: "rl",
						secondDemoScanningDirectionLineByLine: "sd",
						postTutorialMessage: "",
					};
				}
			},
		},
		beforeRouteLeave(to, from, next) {
			if (!this.saved) {
				this.$modal.show("dialog", {
					title: `Unsaved changes`,
					text: `You may have unsaved changes, do you still want to go back?`,
					clickToClose: false,
					buttons: [
						{
							title: "Yes, go back",
							default: true,
							handler: () => {
								next();
								this.$modal.hide("dialog");
							},
							class: "modal-button",
						},
						{
							title: "No",
							handler: () => {
								next(false);
								this.$modal.hide("dialog");
							},
							class: "modal-button",
						},
					],
				});
			} else {
				next();
			}
		},
	};
</script>

<style></style>
