<template>
	<div class="grid-container">
		<Loading :active.sync="!this.test" :can-cancel="true" />
		<TestDetails :test="test" v-if="test" />
	</div>
</template>

<script>
	import axios from "axios";
	import Loading from "vue-loading-overlay";

	import TestDetails from "@/components/test/TestDetails";

	import NotificationService from "@/services/NotificationService";
	const notificationService = new NotificationService();

	import UserService from "@/services/UserService";
	const userService = new UserService();

	export default {
		name: "Test",
		components: {
			TestDetails,
			Loading,
		},
		data() {
			return {
				test: null,
			};
		},
		methods: {
			getTest() {
				const config = {
					params: {
						_id: this.$route.params.testId,
					},
					headers: {
						Authorization: "Bearer " + userService.getJwt(),
					},
				};

				axios
					.get(process.env.VUE_APP_API_URL + "/getTest", config)
					.then((resp) => {
						this.test = resp.data;
					})
					.catch((error) => {
						notificationService.error(error);
					});
			},
		},
		created() {
			this.getTest();
		},
	};
</script>

<style lang="scss" scoped></style>
