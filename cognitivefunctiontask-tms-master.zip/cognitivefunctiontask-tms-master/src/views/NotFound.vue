<template>
    <div></div>
</template>

<script>
import router from "@/router";

export default {
    name: "NotFound",
    beforeCreate() {
        router.push("/");
    },
};
</script>

<style></style>
