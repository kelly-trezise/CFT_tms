<template>
	<div class="home">
		<TaskList />
	</div>
</template>

<script>
	import TaskList from "@/components/task/TaskList.vue";

	export default {
		name: "Home",
		components: {
			TaskList,
		},
	};
</script>

<style lang="scss" scoped></style>
