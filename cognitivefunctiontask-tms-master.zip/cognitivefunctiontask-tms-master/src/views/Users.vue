<template>
	<div>
		<UserList />
	</div>
</template>

<script>
	import UserList from "@/components/user/UserList";

	export default {
		name: "Users",
		components: {
			UserList,
		},
	};
</script>

<style lang="scss">
	* {
		font-family: "Open Sans", Avenir, Helvetica, Arial, sans-serif;
	}
</style>
