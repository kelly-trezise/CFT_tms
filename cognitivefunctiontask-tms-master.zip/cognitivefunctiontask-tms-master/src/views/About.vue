<template>
	<div class="grid-container" id="about">
		<div class="grid-x">
			<div class="cell medium-4">
				<h1>Cognitive Function Task</h1>
				Kelly Trezise<br />
				<a href="mailto:k.trezise@lboro.ac.uk">k.trezise@lboro.ac.uk</a
				><br />
				<a href="http://kellytrezise.com/" target="_blank"
					>kellytrezise.com</a
				>
			</div>
			<div class="cell medium-4">
				<h1>Software Development</h1>
				<img
					src="img/simonrose_logo.png"
					alt="Simon Rose Software Development"
				/>
				<a href="mailto:simonrose121@gmail.com"
					>simonrose121@gmail.com</a
				><br />
				<a href="https://simon-rose.co.uk" target="_blank"
					>simon-rose.co.uk</a
				>
			</div>
			<div class="cell medium-4">
				<h1>Funding</h1>
				Centre for Mathematical Cognition<br />
				Loughborough University
				<a href="https://www.lboro.ac.uk/research/cmc/" target="_blank">
					<img
						class="lboro"
						src="img/loughborough_logo.png"
						alt="Loughborough University"
					/>
				</a>
			</div>
		</div>
		<div class="grid-x">
			<div class="cell medium-12">
				<h1>What is the Cognitive Function Task?</h1>
				<p>
					The Cognitive Function Task is a new way to assess cognitive
					functioning across development. The toolbox allows
					researchers to flexibly develop or customise their own
					cognitive function task assessment in minutes, or use
					existing assessments within the software. Cognitive
					assessments can be flexibly be designed to assess one or
					many different cognitive functions from simple (e.g.,
					inhibition) through to complex cognition (e.g., coordination
					of rules and responses), the impact of visual perception
					and/or motor coordination, and the impact of time pressure
					and gamification. The stimuli for the Cognitive Function
					Task are made up of a small set of shapes, and researchers
					can choose to use one, two or all shapes. The stimuli are
					arranged in a matrix form onscreen, changes in matrix size
					allows for the task to be potentially used across all ages
					from 3 years and up. The approach of this task: consistent
					stimuli used flexibly allows a wide variety of cognitive
					functions to be assessed and easily compared.
				</p>
				<p>
					Once a researcher has customised their task, they can then
					send the link of the assessment to any participant or
					another research group. Participants can complete the task
					on any touchscreen tablet or computer. An internet
					connection is required to download the customised task and
					upload results, but not needed to complete the task, meaning
					easy data collection at schools and non-university
					locations. The task also provides all output at the click of
					a button. The Cognitive Function Task has the potential to
					improve assessment and understanding of different cognitive
					functions and their development, while also improving the
					ease and speed for researchers to develop assessments,
					collect data and summarise data.
				</p>
			</div>
		</div>
		<div class="grid-x">
			<div class="cell medium-12">
				<h1>How To Cite</h1>
				Trezise, K. (2020) Cognitive Function Task [Computer software].
				Retrieved from https://www.cognitivefunctiontask.com
			</div>
		</div>
		<div class="grid-x">
			<div class="cell medium-12">
				<h1>User Manual</h1>
				<a href="pdf/CFTUserManual.pdf" target="_blank">Download</a>
			</div>
		</div>
		<div class="grid-x">
			<div class="cell medium-12">
				<h1>Questions</h1>
				Please email
				<a href="http://kellytrezise.com/" target="_blank"
					>kellytrezise.com</a
				>
			</div>
		</div>
		<div class="grid-x">
			<div class="cell medium-12">
				<h1>Privacy Policy</h1>
				<p>
					Personal information of participants will be collected for
					the core purpose of carrying out research examining
					cognitive, motor or perceptual functioning. The data may
					also be used to help understand how to improve and/or
					further develop the website. Personal information of
					researchers will be collected for the core purpose of
					improving and developing the website and examining how
					researchers use the website and/or examine cognitive, motor
					or perceptual functioning.
				</p>
				<p>
					Data will collected, stored and managed in accordance with
					the Loughborough University Data Management Policy and GDPR
					Principles. Personal data will be stored on Loughborough
					University servers, accessible only through password
					protection for approved researchers. Personal data is likely
					to be shared within the project team, primarily in a way
					that we can identify you as a participant. Information where
					you can be identified will be kept for a minimum amount of
					time and in accordance with the research objectives.
				</p>
				<p>
					The data from this project might be used for other, future
					research projects in addition to the project you are
					currently participating in. Those future projects can focus
					on any topic that might be unrelated to the goals of this
					study. We will give access to the data we are collecting to
					the general public via the Internet. Any personal
					information that would possibly identify you will be removed
					or changed before data are shared or results are made
					public.
				</p>
			</div>
		</div>
	</div>
</template>

<script>
	export default {
		name: "About",
	};
</script>

<style lang="scss" scoped>
	@include foundation-xy-grid-classes;

	#about {
		line-height: 2rem;
	}

	h1 {
		font-weight: bold;
	}

	img {
		display: block;
		width: 50%;

		&.lboro {
			margin-top: 10px;
		}
	}

	.grid-x {
		margin-bottom: 20px;
	}
</style>
