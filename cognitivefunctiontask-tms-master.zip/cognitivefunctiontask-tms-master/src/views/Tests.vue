<template>
	<div>
		<Loading :active.sync="!this.testsRetrieved" :can-cancel="true" />
		<TestList
			:tests="tests"
			v-if="tests.length > 0"
			@update-tests="getTests"
		/>
		<div class="grid-container" v-if="testsRetrieved && tests.length === 0">
			<div class="grid-x">
				<div class="cell medium-12 empty-warning">
					There are no tests.
				</div>
			</div>
		</div>
	</div>
</template>

<script>
	import axios from "axios";

	import TestList from "@/components/test/TestList";
	import Loading from "vue-loading-overlay";

	import NotificationService from "@/services/NotificationService";
	const notificationService = new NotificationService();

	import UserService from "@/services/UserService";
	const userService = new UserService();

	export default {
		name: "Tests",
		components: {
			TestList,
			Loading,
		},
		data() {
			return {
				tests: [],
				testsRetrieved: false,
			};
		},
		methods: {
			getTests(limit) {
				this.testsRetrieved = false;
				const config = {
					params: {
						limit: limit,
					},
					headers: {
						Authorization: "Bearer " + userService.getJwt(),
					},
				};
				axios
					.get(process.env.VUE_APP_API_URL + "/getTests", config)
					.then((resp) => {
						this.tests = resp.data;
						this.testsRetrieved = true;
					})
					.catch((error) => {
						notificationService.error(error);
					});
			},
		},
		created() {
			this.getTests(50);
		},
	};
</script>

<style></style>
