<template>
	<div class="user">
		<UserDetails
			v-if="userDetails"
			:user="userDetails"
			@save-clicked="saved = true"
		/>
	</div>
</template>

<script>
	import UserDetails from "@/components/user/UserDetails";
	import { mapGetters, mapActions } from "vuex";

	export default {
		name: "User",
		components: {
			UserDetails,
		},
		data() {
			return {
				saved: false,
			};
		},
		methods: mapActions(["getUsers"]),
		created() {
			if (this.$route.params.id) {
				this.getUsers();
			}
		},
		computed: {
			...mapGetters(["getUser"]),
			userDetails() {
				if (this.$route.params.id) {
					let user = this.getUser(this.$route.params.id);
					return user;
				} else {
					return {
						name: "",
						email: "",
						admin: false,
						password: "",
					};
				}
			},
		},
		beforeRouteLeave(to, from, next) {
			if (!this.saved) {
				this.$modal.show("dialog", {
					title: `Unsaved changes`,
					text: `You may have unsaved changes, do you still want to go back?`,
					clickToClose: false,
					buttons: [
						{
							title: "Yes, go back",
							default: true,
							handler: () => {
								next();
								this.$modal.hide("dialog");
							},
							class: "modal-button",
						},
						{
							title: "No",
							handler: () => {
								next(false);
								this.$modal.hide("dialog");
							},
							class: "modal-button",
						},
					],
				});
			} else {
				next();
			}
		},
	};
</script>

<style></style>
