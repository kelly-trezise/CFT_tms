export default class DataExportService {
	testsToCSV(tests, detail) {
		let csv = "";

		if (detail === "trial") {
			csv = this._testTrialsToCSV(tests);
		} else if (detail === "shape-select") {
			csv = this._testLogsToCSV(tests);
		}

		return csv;
	}

	createFile(csv, fileName) {
		var blob = new Blob([csv], { type: "text/csv;charset=utf/8;" });
		if (navigator.msSaveBlob) {
			// IE 10+
			navigator.msSaveBlob(blob, fileName);
		} else {
			var link = document.createElement("a");
			if (link.download !== undefined) {
				// feature detection
				// Browsers that support HTML5 download attribute
				var url = URL.createObjectURL(blob);
				link.setAttribute("href", url);
				link.setAttribute("download", fileName);
				link.style.visibility = "hidden";
				document.body.appendChild(link);
				link.click();
				document.body.removeChild(link);
			}
		}
	}

	_testTrialsToCSV(tests) {
		let csv = "";

		// row = trial
		const headings = this._getDefaultHeadings();

		csv += headings.join(",") + "\r\n";

		tests.forEach((test) => {
			test.trials.forEach((trial) => {
				const row = this._getDefaultRow(test, trial);

				csv += row.join(",") + "\r\n";
			});
		});

		return csv;
	}

	_testLogsToCSV(tests) {
		let csv = "";

		// row = log
		let headings = this._getDefaultHeadings();
		const logHeadings = [
			"shape",
			"row",
			"positionInRow",
			"overallPosition",
			"isTarget",
			"isNotNthTarget",
			"isDistractorTarget",
			"isNearDistractor",
			"isFarDistractor",
			"isRelationship",
			"withholdResponse",
			"timeRemaining",
			"timestamp",
		];
		headings = headings.concat(logHeadings);

		csv += headings.join(",") + "\r\n";

		tests.forEach((test) => {
			test.trials.forEach((trial) => {
				trial.log.forEach((log) => {
					let row = this._getDefaultRow(test, trial);

					logHeadings.forEach((heading) => {
						row.push(log[heading]);
					});

					csv += row.join(",") + "\r\n";
				});
			});
		});

		return csv;
	}

	_getDefaultHeadings() {
		return [
			"testId",
			"taskId",
			"taskName",
			"playerName",
			"dob",
			"startTime",
			"endTime",
			"description",
			"trialOrder",
			"tutorialTargetProportion",
			"tutorialDemoCycleSpeed",
			"firstDemoTargets",
			"firstDemoScanningDirectionVertical",
			"firstDemoScanningDirectionHorizontal",
			"firstDemoScanningDirectionLineByLine",
			"secondDemoTargets",
			"secondDemoScanningDirectionVertical",
			"secondDemoScanningDirectionHorizontal",
			"secondDemoScanningDirectionLineByLine",
			"theme",
			"trialId",
			"numRows",
			"numNodesPerRow",
			"timeLimit",
			"showTimeLimit",
			"numberOfTrials",
			"nextTrialWhenAllTargetsSelected",
			"showNextButton",
			"trialGap",
			"showTrialRules",
			"practiceTrialNumRows",
			"practiceTrialNumNodesPerRow",
			"scanningDirectionVertical",
			"scanningDirectionHorizontal",
			"scanningDirectionLineByLine",
			"targets",
			"nearDistractors",
			"nearDistractorProportion",
			"farDistractors",
			"adaptiveRules",
			"preTrialsMessage",
			"preTrialMessage",
			"postTrialMessage",
			"totalShapeCount",
			"targetCount",
			"trialNumberInTask",
			"trialSet",
			"trialNumberInSet",
			"trialStartTime",
			"trialEndTime",
			"trialTimeTakenS",
			"truePositive",
			"falsePositive",
			"falseNegative",
			"trueNegative",
			"correctionTruePositive",
			"correctionFalseNegative",
			"wrongDirection",
			"timeRemaining",
			"grid",
		];
	}

	_getDefaultRow(test, trial) {
		// test.task contains all the trial information
		const taskTrial = test.task.trials.find((t) => t._id === trial.trialId);

		return [
			test._id,
			test.taskId,
			test.name,
			test.playerName,
			test.dob,
			test.stats ? test.stats.startTime : "",
			test.stats ? test.stats.endTime : "",
			this._cleanStrings(test.task.description),
			test.task.trialOrder,
			test.task.tutorialTargetProportion,
			test.task.tutorialDemoCycleSpeed,
			this._generateShapesString(test.task.firstDemoTargets),
			test.task.firstDemoScanningDirectionVertical,
			test.task.firstDemoScanningDirectionHorizontal,
			test.task.firstDemoScanningDirectionLineByLine,
			this._generateShapesString(test.task.secondDemoTargets),
			test.task.secondDemoScanningDirectionVertical,
			test.task.secondDemoScanningDirectionHorizontal,
			test.task.secondDemoScanningDirectionHorizontal,
			test.task.theme,
			trial.trialId,
			trial.numRows,
			trial.numNodesPerRow,
			taskTrial.timeLimit,
			taskTrial.showTimeLimit,
			taskTrial.numTrials,
			taskTrial.nextTrialWhenAllTargetsSelected,
			taskTrial.showNextButton,
			taskTrial.trialGap,
			taskTrial.showTrialRules,
			taskTrial.practiceTrialNumRows,
			taskTrial.practiceTrialNumNodesPerRow,
			taskTrial.scanningDirectionVertical,
			taskTrial.scanningDirectionHorizontal,
			taskTrial.scanningDirectionLineByLine,
			this._generateTargetsString(taskTrial.targets),
			this._generateShapesString(taskTrial.nearDistractors),
			taskTrial.nearDistractorProportion,
			this._generateShapesString(taskTrial.farDistractors),
			this._generateAdaptiveRuleString(taskTrial.adaptiveRules),
			this._cleanStrings(test.task.postTutorialMessage),
			this._cleanStrings(taskTrial.preTrialMessage),
			this._cleanStrings(taskTrial.postTrialMessage),
			trial.totalShapeCount,
			trial.targetCount,
			trial.trialNumberInTask,
			trial.trialSet,
			trial.trialNumberInSet,
			trial.stats ? trial.stats.startTime : "",
			trial.stats ? trial.stats.endTime : "",
			trial.stats ? trial.stats.timeTakenS : "",
			trial.stats ? trial.stats.truePositive : "",
			trial.stats ? trial.stats.falsePositive : "",
			trial.stats ? trial.stats.falseNegative : "",
			trial.stats ? trial.stats.trueNegative : "",
			trial.stats ? trial.stats.correctionTruePositive : "",
			trial.stats ? trial.stats.correctionFalseNegative : "",
			trial.stats ? trial.stats.wrongDirection : "",
			trial.stats ? trial.stats.timeRemaining : "",
			this._generateGridString(trial),
		];
	}

	_generateTargetsString(targets) {
		let targetArray = [];
		targets.forEach((target) => {
			let element = `(S=${this._generateShapesString(target.shapes)})`;
			element += `(NT=${target.isNTarget})`;
			element += `(WH=${target.withholdResponseFor})`;
			element += `(PR=${target.proportion})`;
			element += `(R=${target.relationship})`;
			if (target.relationship) {
				element += `(REL=(S=${this._generateShapesString(
					target.relationshipRule.shapes
				)})(N=${target.relationshipRule.not})(P=${
					target.relationshipRule.position
				})(PR=${target.relationshipRule.proportion}))`;
			}
			targetArray.push(element);
		});
		return targetArray.join("/");
	}

	_generateShapesString(shapes) {
		let shapesArray = [];
		if (shapes) {
			shapes.forEach((shape) => {
				shapesArray.push(shape);
			});
			return shapesArray.join("/");
		}
		return shapesArray;
	}

	_generateAdaptiveRuleString(rules) {
		let ruleArray = [];
		rules.forEach((rule) => {
			let element = `(A=${rule.afterNTrials})`;
			element += `(IF=${rule.averageStatistic})`;
			element += `(C=${rule.averageStatisticComparison})`;
			element += `(CP=${rule.averageStatisticPercentage})`;
			element += `(U=${rule.updateVariable})`;
			element += `(UP=${rule.updateVariablePercentage})`;
			element += `(CONT=${rule.continuous})`;
			ruleArray.push(element);
		});
		return ruleArray.join("/");
	}

	_generateGridString(trial) {
		let gridStringArray = [];
		// no commas due to CSV format so using / instead
		trial.grid.forEach((row) => {
			row.forEach((shape) => {
				let element = `${shape.file}(${shape.row}/${shape.positionInRow})(${shape.overallPosition})`;
				element += shape.isTarget ? "(A)" : "";
				element += shape.withholdResponse ? "(B)" : "";
				element += shape.isNotNthTarget ? "(C)" : "";
				element += shape.isDistractorTarget ? "(D)" : "";
				element += shape.isRelationship ? "(E)" : "";
				element += shape.isNearDistractor ? "(F)" : "";
				element += shape.isFarDistractor ? "(G)" : "";
				gridStringArray.push(element);
			});
		});
		return gridStringArray.join("/");
	}

	_cleanStrings(message) {
		if (message) {
			const strippedMessage = message
				.replace(/,/g, "/")
				.replace("\t", "")
				.replace("\n", "")
				.replace("\r", "")
				.replace(/([^;])\n/g, "$1");

			return '"' + strippedMessage + '"';
		} else {
			return "";
		}
	}
}
