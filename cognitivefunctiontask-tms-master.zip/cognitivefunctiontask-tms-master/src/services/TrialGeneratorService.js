import lodash from "lodash";

import { shapes as shapesData } from "@/data/Shapes.js";

export default class TrialGeneratorService {
	generateTrialOrder(trials, order) {
		let generatedTrials = [];
		let allTrials = [];
		const trialVals = lodash.cloneDeep(trials);
		let trialIndexInSet = 0;
		trialVals.forEach((trial, index) => {
			trialIndexInSet = 0;
			for (let i = 0; i < trial.numTrials; i++) {
				let trialToPush = lodash.cloneDeep(trial);
				trialToPush.trialIndex = index;
				trialToPush.trialIndexInSet = trialIndexInSet;
				allTrials.push(trialToPush);
				trialIndexInSet++;
			}
		});

		if (order === "sequential") {
			// do nothing
			generatedTrials = lodash.sortBy(allTrials, "trialIndex");
		} else if (order === "randomised") {
			generatedTrials = lodash.shuffle(allTrials);
			// always the first trial in the index
			generatedTrials.forEach((trial) => {
				trial.trialIndexInSet = 0;
			});
		} else if (order === "alternate") {
			// array of target trial indices
			let targetIndex = 0;
			while (allTrials.length > 0) {
				// find trial that matches index
				const trial = allTrials.find(
					(t) => t.trialIndex === targetIndex
				);
				// if that trial exists
				if (trial) {
					// add trial to alternating list
					generatedTrials.push(trial);

					// delete trial from allTrials
					const index = allTrials.indexOf(trial);
					if (index > -1) {
						allTrials.splice(index, 1);
					}
				}
				// get next index or revert to 0 if end of list
				targetIndex++;
				if (targetIndex === trials.length) {
					targetIndex = 0;
				}
			}
			generatedTrials.forEach((trial) => {
				trial.trialIndexInSet = 0;
			});
		}
		return generatedTrials;
	}

	generateSingleShapeGrid(trial) {
		let totalTargetProportion = 0;
		trial.targets.forEach((target) => {
			totalTargetProportion += parseInt(target.proportion);
		});

		let shape = this.selectShape(
			trial.targets,
			totalTargetProportion,
			trial.nearDistractors,
			trial.nearDistractorProportion,
			trial.farDistractors
		);

		// shape info for analytics
		shape.selected = false;
		shape.row = 1;
		shape.positionInRow = 1;
		shape.overallPosition = 0;
		shape.correct = false;
		shape.incorrect = false;

		let grid = [[shape]];

		return {
			grid: grid,
			shapes: [shape],
			totalShapeCount: 1,
			targetCount: shape.isTarget ? 1 : 0,
		};
	}

	generateGrid(trial) {
		// ensure that trials aren't created without targets but are still random
		const maxTrialCreationAttempts = 100;
		let trialCreationAttempts = 0;
		let numTargetShapesPerTarget = [];

		// store shapes in a 1D array so shapes on next/previous rows can be altered
		let shapes = [];

		let totalTargetProportion = 0;
		trial.targets.forEach((target) => {
			totalTargetProportion += parseInt(target.proportion);
			numTargetShapesPerTarget.push({
				id: target._id,
				numTargets: 0,
				numTargetsWithholdResponse: 0,
			});
		});

		while (
			!this.oneShapeFromEachTarget(numTargetShapesPerTarget) &&
			trialCreationAttempts < maxTrialCreationAttempts
		) {
			shapes = [];
			trialCreationAttempts++;
			numTargetShapesPerTarget.forEach((element) => {
				element.numTargets = 0;
				element.numTargetsWithholdResponse = 0;
			});

			// generate grid using correct proportions
			for (let row = 0; row < Math.round(trial.numRows); row++) {
				let positionInRow = 1;
				let nodesRemaining = lodash.clone(trial.numNodesPerRow);

				while (nodesRemaining > 0) {
					let shape = this.selectShape(
						trial.targets,
						totalTargetProportion,
						trial.nearDistractors,
						trial.nearDistractorProportion,
						trial.farDistractors
					);

					// shape info for analytics
					shape.selected = false;
					shape.row = row + 1;
					shape.positionInRow = positionInRow;
					shape.overallPosition = shapes.length;
					shape.correct = false;
					shape.incorrect = false;

					shape.rowNum = row;
					shapes.push(shape);
					nodesRemaining -= shape.width;
					positionInRow++;
				}
			}

			// adjust grid for relationship
			shapes.forEach((shape, index) => {
				// if shape is a target
				if (shape.isTarget && shape.targetInfo) {
					// check if it has relationships
					if (JSON.parse(shape.targetInfo.relationship)) {
						// depending on the type of relationship - randomly set the shapes around the target based on target proportion
						if (
							shape.targetInfo.relationshipRule.position ===
							"after"
						) {
							this.setRelationshipShapes(
								shapes,
								this.stringToBool(
									shape.targetInfo.relationshipRule.not
								),
								index,
								-1,
								shape.targetInfo.relationshipRule,
								trial
							);
						} else if (
							shape.targetInfo.relationshipRule.position ===
							"before"
						) {
							this.setRelationshipShapes(
								shapes,
								this.stringToBool(
									shape.targetInfo.relationshipRule.not
								),
								index,
								1,
								shape.targetInfo.relationshipRule,
								trial
							);
						}
					}
				}
			});

			// handle non mutually exclusive relationships by doing another pass through the grid
			// only if there are non mutually exclusive relationships
			let mutuallyExclusive = true;
			trial.targets.forEach((target) => {
				if (target.relationship) {
					target.relationshipRule.shapes.forEach(
						(relationshipShape) => {
							if (
								target.shapes.filter(
									(s) => s === relationshipShape
								).length > 0
							) {
								mutuallyExclusive = false;
							}
						}
					);
				}
			});

			if (!mutuallyExclusive) {
				let targetShapes = [];
				trial.targets.forEach((target) => {
					targetShapes = targetShapes.concat(target.shapes);
				});

				shapes.forEach((shape, index) => {
					// if there is a row of 3 or more of the same shape
					if (shapes[index + 1] && shapes[index + 2]) {
						if (
							shape.file === shapes[index + 1].file &&
							shapes[index + 1].file === shapes[index + 2].file
						) {
							// differentiate per relationship type
							this.log(
								"row of 3 shape files starting at..." + index
							);

							// remove distractor targets in the line
							for (let offset = 0; offset <= 2; offset++) {
								if (shapes[index + offset].isDistractorTarget) {
									this.log(
										"resetting distractor target to other shape at " +
											(index + offset)
									);
									shapes[index + offset].isTarget = false;
									shapes[
										index + offset
									].isDistractorTarget = false;
									shapes[
										index + offset
									].isRelationship = false;

									const newShape = this.getNearOrFarDistractorShape(
										trial,
										null,
										targetShapes
									);
									shapes[index + offset].file = newShape.file;
									shapes[index + offset].width =
										newShape.width;
									this.resetDistractorFlags(
										shapes[index + offset],
										trial,
										targetShapes
									);
								}
							}
						}
					}

					// redo check for rows of 3 or more after distractor targets are set
					if (shapes[index + 1] && shapes[index + 2]) {
						if (
							shape.file === shapes[index + 1].file &&
							shapes[index + 1].file === shapes[index + 2].file
						) {
							// check relationship of first target in chain
							let firstTargetInfo = null;
							for (let offset = 0; offset <= 2; offset++) {
								if (shapes[index + offset].targetInfo) {
									firstTargetInfo =
										shapes[index + offset].targetInfo;
									break;
								}
							}

							// before 'is' relationship
							if (
								firstTargetInfo &&
								firstTargetInfo.relationship
							) {
								if (
									firstTargetInfo.relationshipRule
										.position === "before"
								) {
									if (!firstTargetInfo.relationshipRule.not) {
										// last shape in chain should be a relationship shape
										// the rest should be targets
										for (
											let offset = 0;
											offset <= 2;
											offset++
										) {
											if (offset === 2) {
												shapes[
													index + offset
												].isTarget = false;
												shapes[
													index + offset
												].isDistractorTarget = false;
												shapes[
													index + offset
												].isRelationship = true;
											} else {
												shapes[
													index + offset
												].isTarget = true;
												shapes[
													index + offset
												].isDistractorTarget = false;
												shapes[
													index + offset
												].isRelationship = false;
												shapes[
													index + offset
												].targetInfo = firstTargetInfo;
											}
										}
									}
								} else if (
									firstTargetInfo.relationshipRule
										.position === "after"
								) {
									if (!firstTargetInfo.relationshipRule.not) {
										// first shape in chain should be a relationship shape
										// the rest should be targets
										for (
											let offset = 0;
											offset <= 2;
											offset++
										) {
											if (offset === 0) {
												// find closest previous relationship
												let setRelationship = true;

												for (
													let offset = 1;
													offset < index;
													offset++
												) {
													if (
														shapes[index - offset]
															.isRelationship
													) {
														setRelationship = false;
													} else {
														if (
															!shapes[
																index - offset
															].isTarget
														) {
															break;
														}
													}
												}

												if (setRelationship) {
													this.log(
														"setting " +
															(index + offset) +
															" to relationship shape"
													);
													shapes[
														index + offset
													].isTarget = false;
													shapes[
														index + offset
													].isDistractorTarget = false;
													shapes[
														index + offset
													].isRelationship = true;
												}
											} else {
												this.log(
													"setting " +
														(index + offset) +
														" to target"
												);
												shapes[
													index + offset
												].isTarget = true;
												shapes[
													index + offset
												].isDistractorTarget = false;
												shapes[
													index + offset
												].isRelationship = false;
												shapes[
													index + offset
												].targetInfo = firstTargetInfo;
											}
										}
									}
								}
							}
						}
					}

					// if there is a row of 2 or more that are all distractor targets
					if (shapes[index + 1]) {
						if (
							shape.file === shapes[index + 1].file &&
							shape.isDistractorTarget &&
							shapes[index + 1].isDistractorTarget
						) {
							this.log(
								"two distractor targets together starting at " +
									index +
									" resetting one..."
							);

							shapes[index + 1].isTarget = false;
							shapes[index + 1].isDistractorTarget = false;
							shapes[index + 1].isRelationship = false;

							const newShape = this.getNearOrFarDistractorShape(
								trial,
								null,
								targetShapes
							);
							shapes[index + 1].file = newShape.file;
							shapes[index + 1].width = newShape.width;
							this.resetDistractorFlags(
								shapes[index + 1],
								trial,
								targetShapes
							);
						}
					}
				});
			}

			// adjust grid for n targets
			trial.targets.forEach((target) => {
				let targetNum = 0;
				shapes.forEach((shape) => {
					if (shape.isTarget && shape.targetInfo._id === target._id) {
						shape = this.checkIsNTarget(shape, target, targetNum);
						targetNum++;
					}
				});
			});

			// adjust grid for withhold response (has to happen after adjust grid for n targets)
			trial.targets.forEach((target) => {
				let targetNum = 0;
				if (target.withholdResponseFor > 0) {
					shapes.forEach((shape) => {
						if (
							shape.isTarget &&
							shape.targetInfo._id === target._id
						) {
							this.log("checking wh for " + targetNum);
							shape = this.checkIsResponseWithheld(
								shape,
								target.withholdResponseFor,
								targetNum
							);
							targetNum++;
						}
					});
				}
			});

			// count total target shapes for each target
			shapes.forEach((shape) => {
				if (shape.isTarget) {
					let numTarget = numTargetShapesPerTarget.find(
						(t) => t.id === shape.targetInfo._id
					);

					if (numTarget) {
						if (!shape.withholdResponse) {
							numTarget.numTargets++;
						} else {
							numTarget.numTargetsWithholdResponse++;
						}
					}
				}
			});
		}

		let numTargets = 0;
		numTargetShapesPerTarget.forEach((target) => {
			// targets only count if they aren't withhold response
			numTargets += target.numTargets;
		});

		if (process.env.JEST_WORKER_ID === undefined) {
			let numDistractorTargets = 0;
			shapes.forEach((shape) => {
				if (shape.isDistractorTarget) {
					numDistractorTargets++;
				}
			});

			let numWithheldResponseTargets = 0;
			shapes.forEach((shape) => {
				if (shape.withholdResponse) {
					numWithheldResponseTargets++;
				}
			});

			const targetShapeCount =
				numTargets + numDistractorTargets + numWithheldResponseTargets;

			console.log(`created grid with ${shapes.length} shapes:\n 
				target shapes: ${targetShapeCount}/${shapes.length} (${(
				(targetShapeCount / shapes.length) *
				100
			).toFixed(3)}%)\n
				targets: ${numTargets}/${targetShapeCount} (${(
				(numTargets / targetShapeCount) *
				100
			).toFixed(3)}%)\n
				withhold response: ${numWithheldResponseTargets}/${targetShapeCount} (${(
				(numWithheldResponseTargets / targetShapeCount) *
				100
			).toFixed(3)}%)\n
				distractor targets: ${numDistractorTargets}/${targetShapeCount} (${(
				(numDistractorTargets / targetShapeCount) *
				100
			).toFixed(3)}%)`);
		}

		// set grid before return
		let grid = [];

		// empty row arrays
		for (let row = 0; row < Math.round(trial.numRows); row++) {
			grid[row] = [];
		}

		// populate grid rows
		for (let index = 0; index < shapes.length; index++) {
			grid[shapes[index].rowNum].push(lodash.cloneDeep(shapes[index]));
		}

		return {
			grid: grid,
			shapes: shapes,
			totalShapeCount: shapes.length,
			targetCount: numTargets,
		};
	}

	oneShapeFromEachTarget(numTargetShapesPerTarget) {
		let hasOneOfEach = false;

		numTargetShapesPerTarget.forEach((target) => {
			if (target.numTargets > 0) {
				hasOneOfEach = true;
			}
		});

		return hasOneOfEach;
	}

	selectShape(
		targets,
		totalTargetProportion,
		nearDistractors,
		nearDistractorProportion,
		farDistractors
	) {
		const rand = Math.random();
		const targetChance = totalTargetProportion / 100;
		const nearDistractoryChance =
			targetChance + nearDistractorProportion / 100;

		let targetShapes = [];
		targets.forEach((target) => {
			targetShapes = targetShapes.concat(target.shapes);
		});

		if (rand < targetChance) {
			return this.selectTarget(targets, totalTargetProportion);
		} else if (rand >= targetChance && rand <= nearDistractoryChance) {
			return this.selectNearDistractorShape(
				nearDistractors,
				targetShapes
			);
		} else {
			return this.selectFarDistractorShape(farDistractors, targetShapes);
		}
	}

	selectTarget(targets, totalTargetProportion) {
		let shape = null;

		const rand = Math.random();
		let incChance = 0;

		// select shape from one of the targets randomly
		targets.forEach((target) => {
			if (!shape) {
				const adjustedChance =
					target.proportion / totalTargetProportion;
				if (rand < incChance + adjustedChance) {
					shape = this.randomArrayElement(
						shapesData.filter((s) => target.shapes.includes(s.file))
					);
					shape.isTarget = true;
					shape.isNearDistractor = false;
					shape.isFarDistractor = false;
					shape.targetInfo = target;
				}
				incChance += adjustedChance;
			}
		});

		return shape;
	}

	selectNearDistractorShape(nearDistractors, targetShapes) {
		let shape = this.randomArrayElement(
			shapesData.filter(
				(s) =>
					nearDistractors.includes(s.file) &&
					!targetShapes.includes(s.file)
			)
		);
		shape.isTarget = false;
		shape.isNearDistractor = true;
		shape.isFarDistractor = false;
		return shape;
	}

	selectFarDistractorShape(farDistractors, targetShapes) {
		let shape = this.randomArrayElement(
			shapesData.filter(
				(s) =>
					farDistractors.includes(s.file) &&
					!targetShapes.includes(s.file)
			)
		);
		shape.isTarget = false;
		shape.isNearDistractor = false;
		shape.isFarDistractor = true;
		return shape;
	}

	setRelationshipShapes(shapes, not, index, offset, relationship, trial) {
		// this method sets the relationship shapes for a target based on an offset (before or after)

		// get all the targets (may be multiple)
		let targetShapes = [];
		let targets = [];
		trial.targets.forEach((target) => {
			targetShapes = targetShapes.concat(target.shapes);
			targets = targets.concat(target);
		});

		// override any previous changes to the shape file by setting it back to a target
		const targetShape = this.randomArrayElement(
			shapesData.filter((s) => targetShapes.includes(s.file))
		);
		shapes[index].file = targetShape.file;
		shapes[index].width = targetShape.width;

		if (shapes[index + offset]) {
			// if shape has previous/next shape to apply the relationship to

			const rand = Math.random();
			if (rand < relationship.proportion / 100) {
				// there is a relationship
				this.log(index + " is a target");

				// set next or previous shape to have relationship flag
				this.log(index + offset + " becomes a relationship shape");
				shapes[index + offset].isTarget = false;
				shapes[index + offset].isDistractorTarget = false;
				shapes[index + offset].isRelationship = true;
				this.resetDistractorFlags(
					shapes[index + offset],
					trial,
					targetShapes
				);

				// check if two shapes ago is a relationship shape on 'after' relationship
				// because of the way this works, chained targets won't reset the relationship flag
				// for the previous target... we handle that here
				if (
					relationship.position === "after" &&
					shapes[index + offset * 2] &&
					shapes[index + offset * 2].isRelationship
				) {
					shapes[index + offset * 2].isTarget = false;
					shapes[index + offset * 2].isDistractorTarget = false;
					shapes[index + offset * 2].isRelationship = false;

					// and reset it to a near or far distractor
					const newShape = this.getNearOrFarDistractorShape(
						trial,
						relationship,
						targetShapes
					);
					shapes[index + offset * 2].file = newShape.file;
					shapes[index + offset * 2].width = newShape.width;

					this.resetDistractorFlags(
						shapes[index + offset * 2],
						trial,
						targetShapes
					);
				}

				if (!not) {
					// an 'is' relationship
					// change shape file to a random relationship shape
					const relationshipShape = this.randomArrayElement(
						shapesData.filter((s) =>
							relationship.shapes.includes(s.file)
						)
					);

					shapes[index + offset].file = relationshipShape.file;
					shapes[index + offset].width = relationshipShape.width;
				} else {
					// an 'is not' relationship
					// change shape file to a random shape that is neither a target or a relationship shape
					const newShape = this.getNearOrFarDistractorShape(
						trial,
						relationship,
						targetShapes
					);
					shapes[index + offset].file = newShape.file;
					shapes[index + offset].width = newShape.width;
				}
			} else {
				// there is not a relationship (shape becomes a distractor target)
				this.log(index + " is a distractor target");

				shapes[index].isTarget = false;
				shapes[index].isDistractorTarget = true;
				this.resetDistractorFlags(shapes[index], trial, targetShapes);

				if (!not) {
					// an 'is' relationship
					// make sure that offset shape is not a relationship or a target if it's not a target shape
					if (
						!shapes[index + offset].isDistractorTarget &&
						!shapes[index + offset].isTarget
					) {
						this.log(
							index +
								offset +
								" gets reset to a different shape because it's not another target or distractor target"
						);
						const newShape = this.getNearOrFarDistractorShape(
							trial,
							relationship,
							targetShapes
						);
						shapes[index + offset].file = newShape.file;
						shapes[index + offset].width = newShape.width;

						// reset flags
						shapes[index + offset].isTarget = false;
						shapes[index + offset].isDistractorTarget = false;
						shapes[index + offset].isRelationship = false;
						this.resetDistractorFlags(
							shapes[index + offset],
							trial,
							targetShapes
						);
					}
				} else {
					// an 'is not' relationship

					if (shapes[index + offset].isTarget) {
						// if it's a target then unset distractor target - precedence goes to targets
						this.log(
							index +
								offset +
								" is a target - unsetting distractor target flags for " +
								index
						);

						shapes[index].isTarget = false;
						shapes[index].isDistractorTarget = false;
						shapes[index].isRelationship = false;

						// make sure it's not a target or a relationship shape
						const newShape = this.getNearOrFarDistractorShape(
							trial,
							relationship,
							targetShapes
						);
						shapes[index].file = newShape.file;
						shapes[index].width = newShape.width;

						this.resetDistractorFlags(
							shapes[index],
							trial,
							targetShapes
						);
					} else {
						// else make sure that offset shape is a relationship shape (and reset flags)
						// flags are reset here because relationship shapes in 'not' relationships
						// are only displayed next to targets
						this.log(
							index + offset + " setting to relationship shape"
						);

						shapes[index + offset].file = this.randomArrayElement(
							shapesData.filter((s) =>
								relationship.shapes.includes(s.file)
							)
						).file;

						shapes[index + offset].isTarget = false;
						shapes[index + offset].isDistractorTarget = false;
						shapes[index + offset].isRelationship = false;
						this.resetDistractorFlags(
							shapes[index],
							trial,
							targetShapes
						);
					}
				}
			}
		} else {
			// it's the first or last shape
			// reset it
			shapes[index].isTarget = false;
			shapes[index].isDistractorTarget = false;
			shapes[index].isRelationship = false;

			// make sure it's not a target or a relationship shape
			const newShape = this.getNearOrFarDistractorShape(
				trial,
				relationship,
				targetShapes
			);
			shapes[index].file = newShape.file;
			shapes[index].width = newShape.width;

			this.resetDistractorFlags(shapes[index], trial, targetShapes);
		}
	}

	resetDistractorFlags(shape, trial, targetShapes) {
		// shapes can only be near or far distractors
		// near distractors take priority if the shape is in both
		if (trial.nearDistractors.filter((s) => s === shape.file).length > 0) {
			shape.isNearDistractor = true;
			shape.isFarDistractor = false;
		} else if (
			trial.farDistractors.filter((s) => s === shape.file).length > 0
		) {
			shape.isNearDistractor = false;
			shape.isFarDistractor = true;
		}
		if (shape.isRelationship || shape.isTarget) {
			shape.isFarDistractor = false;
			shape.isNearDistractor = false;
		}
		if (targetShapes.filter((s) => s === shape.file).length === 0) {
			shape.isTarget = false;
			shape.isDistractorTarget = false;
			delete shape.targetInfo;
		}
	}

	checkIsNTarget(selectedShape, target, targetNum) {
		let shape = selectedShape;

		if (target.isNTarget > 1) {
			if ((targetNum + 1) % target.isNTarget === 0) {
				shape.isTarget = true;
				shape.isDistractorTarget = false;
				shape.isNotNthTarget = false;
			} else {
				shape.isTarget = false;
				shape.isDistractorTarget = true;
				shape.isNotNthTarget = true;
			}
		} else {
			shape.isTarget = true;
			shape.isDistractorTarget = false;
			shape.isNotNthTarget = false;
		}

		return shape;
	}

	checkIsResponseWithheld(selectedShape, withholdResponseFor, targetNum) {
		let shape = selectedShape;

		if ((targetNum + 1) % withholdResponseFor === 0) {
			shape.withholdResponse = true;
		} else {
			shape.withholdResponse = false;
		}

		return shape;
	}

	getNearOrFarDistractorShape(trial, relationship, targetShapes) {
		let totalTargetProportion = 0;
		trial.targets.forEach((target) => {
			totalTargetProportion += parseInt(target.proportion);
		});

		const rand =
			Math.floor(Math.random() * (100 - totalTargetProportion - 0)) + 0;

		if (!relationship) {
			relationship = {
				shapes: [],
			};
		}

		const nearDistractorChance = trial.nearDistractorProportion;

		let shape = {};
		if (rand < nearDistractorChance) {
			shape = this.randomArrayElement(
				shapesData.filter(
					(s) =>
						!relationship.shapes.includes(s.file) &&
						!targetShapes.includes(s.file) &&
						trial.nearDistractors.includes(s.file)
				)
			);
		} else {
			shape = this.randomArrayElement(
				shapesData.filter(
					(s) =>
						!relationship.shapes.includes(s.file) &&
						!targetShapes.includes(s.file) &&
						trial.farDistractors.includes(s.file)
				)
			);
		}

		return shape;
	}

	randomArrayElement(arr) {
		return lodash.cloneDeep(arr[Math.floor(Math.random() * arr.length)]);
	}

	stringToBool(string) {
		return JSON.parse(string) === true;
	}

	log(text) {
		if (
			process.env.JEST_WORKER_ID === undefined &&
			process.env.NODE_ENV === "development"
		) {
			console.log(text);
		}
	}
}
