import Vue from "vue";
import moment from "moment";

import { config } from "@/data/Config";

export default class NotificationService {
	error(text) {
		Vue.notify({
			group: "alert",
			type: "error",
			title: text,
			text: `${this.getFormattedDateTime()}`,
			duration: config.notificationDuration,
		});
	}
	success(text) {
		Vue.notify({
			group: "alert",
			type: "success",
			title: text,
			text: `${this.getFormattedDateTime()}`,
			duration: config.notificationDuration,
		});
	}
	warning(text) {
		Vue.notify({
			group: "alert",
			type: "warn",
			title: text,
			text: `${this.getFormattedDateTime()}`,
			duration: config.notificationDuration,
		});
	}
	getFormattedDateTime() {
		return moment().format(config.dateTimeExactFormat);
	}
}
