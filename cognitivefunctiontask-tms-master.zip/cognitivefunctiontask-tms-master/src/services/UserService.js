import axios from "axios";

import NotificationService from "@/services/NotificationService";

const notificationService = new NotificationService();

export default class UserService {
	async login(email, password, rememberMe) {
		return await axios
			.post(process.env.VUE_APP_API_URL + "/login", {
				email: email,
				password: password,
			})
			.then((resp) => {
				if (resp.data.token) {
					if (rememberMe) {
						localStorage.setItem(
							"user",
							JSON.stringify(resp.data.user)
						);
						localStorage.setItem("jwt", resp.data.token);
					} else {
						sessionStorage.setItem(
							"user",
							JSON.stringify(resp.data.user)
						);
						sessionStorage.setItem("jwt", resp.data.token);
					}
					notificationService.success(
						`${resp.data.user.email} logged in successfuly.`
					);
				}
				return resp.data;
			})
			.catch((error) => {
				notificationService.error(error);
			});
	}

	logout() {
		this._getStorageSystem().removeItem("user");
		this._getStorageSystem().removeItem("jwt");
		notificationService.success("Logout successful.");
	}

	userIsLoggedIn() {
		if (this._getStorageSystem().getItem("user")) {
			return true;
		} else {
			return false;
		}
	}

	getCurrentUserInfo() {
		if (this._getStorageSystem().getItem("user")) {
			return JSON.parse(this._getStorageSystem().getItem("user"));
		} else {
			return {};
		}
	}

	getJwt() {
		return this._getStorageSystem().getItem("jwt");
	}

	_getStorageSystem() {
		let storageSystem;

		if (sessionStorage.getItem("jwt")) {
			storageSystem = sessionStorage;
		} else {
			storageSystem = localStorage;
		}

		return storageSystem;
	}
}
