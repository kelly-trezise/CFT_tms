/// <reference types="cypress" />
// ***********************************************************
// This example plugins/index.js can be used to load plugins
//
// You can change the location of this file or turn off loading
// the plugins file with the 'pluginsFile' configuration option.
//
// You can read more here:
// https://on.cypress.io/plugins-guide
// ***********************************************************

// This function is called when a project is opened or re-opened (e.g. due to
// the project's config changing)

const path = require("path");
const fs = require("fs");
const seeder = require("cypress-mongo-seeder");
const clipboardy = require("clipboardy");

const mongouri = "mongodb://localhost:27017/dummy-cft";
const folder = "./cypress/plugins/db/data";
const dropCollections = true;

/**
 * @type {Cypress.PluginConfig}
 */
module.exports = (on, config) => {
	// `on` is used to hook into various events Cypress emits
	// `config` is the resolved Cypress config
	on("task", {
		"db:seed": () => {
			return new Promise((resolve) => {
				seeder.seedAll(mongouri, folder, dropCollections);
				// give seeder enough time to seed big test records
				setTimeout(() => resolve(null), 10000);
			});
		},
		"delete-file": (path) => {
			if (fs.existsSync(path)) {
				fs.unlinkSync(path);
				return true;
			}

			return null;
		},
		"get-clipboard"() {
			return clipboardy.readSync();
		},
	});
};
