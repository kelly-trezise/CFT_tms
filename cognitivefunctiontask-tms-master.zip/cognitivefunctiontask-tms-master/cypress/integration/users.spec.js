describe("Users", () => {
	before(() => {
		cy.request("POST", Cypress.env("api") + "/test/connect").then(() => {
			cy.request("POST", Cypress.env("api") + "/test/empty").then(() => {
				cy.task("db:seed");
			});
		});
	});

	beforeEach(() => {
		// log in programatically
		cy.request("POST", Cypress.env("api") + "/login", {
			email: "jsmith@test.com",
			password: "test",
		}).then((resp) => {
			localStorage.setItem("user", JSON.stringify(resp.body.user));
			localStorage.setItem("jwt", resp.body.token);
		});
	});

	after(() => {
		cy.request("POST", Cypress.env("api") + "/connect");
	});

	it("successfully loads page", () => {
		cy.visit("/users");
	});

	it("admin user can view a list of users", () => {
		cy.get("[data-cy=user]").should("have.length", 2);
		cy.get("[data-cy=user]")
			.first()
			.children()
			.first()
			.should("contain", "Another User");

		cy.get("[data-cy=user]")
			.first()
			.children()
			.eq(2)
			.should("contain", "No");

		cy.get("[data-cy=user]")
			.eq(1)
			.children()
			.first()
			.should("contain", "Jerald Smith");

		cy.get("[data-cy=user]")
			.eq(1)
			.children()
			.eq(2)
			.should("contain", "Yes");
	});

	it("admin user can navigate to create a user screen", () => {
		cy.get("[data-cy=create-user]").click();

		cy.url().should("include", "/user");
	});

	it("admin user cannot create a user with missing information or password not meeting requirements", () => {
		cy.get("[data-cy=save-user]").click();

		cy.get("[data-cy=validation]")
			.eq(0)
			.should("contain", "Name is required");

		cy.get("[data-cy=validation]")
			.eq(1)
			.should("contain", "Email is required");

		cy.get("input[name=password]").type("t");

		cy.get("[data-cy=validation]")
			.eq(2)
			.should("contain", "8 characters minimum");

		cy.get("[data-cy=validation]")
			.eq(3)
			.should("contain", "One uppercase letter required");

		cy.get("[data-cy=validation]")
			.eq(4)
			.should("contain", "One number required");

		cy.get("input[name=name]").type("New User");

		cy.get("input[name=email]").type("newuser@test.com");

		cy.get("input[name=password]").clear("Test1234");

		cy.get("input[name=password]").type("Test1234");

		cy.get("input[name=password-confirm]").type("test123");

		cy.get("[data-cy=save-user]").click();

		cy.get("[data-cy=validation]")
			.eq(0)
			.should("contain", "Passwords must match");

		cy.get("input[name=name]").clear();
		cy.get("input[name=email]").clear();
		cy.get("input[name=password]").clear();
		cy.get("input[name=password-confirm]").clear();
	});

	it("admin user cannot create a user with an invalid email or the same email as an existing user", () => {
		cy.get("input[name=email]").type("jsmith");

		cy.get("[data-cy=save-user]").click();

		cy.get("[data-cy=validation]")
			.eq(1)
			.should("contain", "Email is not valid");

		cy.get("input[name=email]").clear();

		cy.get("input[name=email]").type("jsmith@test.com");

		cy.get("[data-cy=save-user]").click();

		cy.get("[data-cy=validation]")
			.eq(1)
			.should("contain", "Another user has this email");

		cy.get("input[name=email]").clear();
	});

	it("admin user can create a user", () => {
		cy.get("input[name=name]").type("New User");

		cy.get("input[name=email]").type("newuser@test.com");

		cy.get("select[name=admin]").select("true");

		cy.get("input[name=password]").type("Test1234");

		cy.get("input[name=password-confirm]").type("Test1234");

		cy.get("[data-cy=save-user]").click();

		cy.get("[data-cy=notification]").should("be.visible");
		cy.get("[data-cy=notification]").should("contain", "created");

		cy.get("[data-cy=user]").should("have.length", 3);

		cy.get("[data-cy=user]")
			.eq(2)
			.children()
			.first()
			.should("contain", "New User");
	});

	it("admin user can navigate to edit a user screen", () => {
		cy.get("[data-cy=edit-user]")
			.eq(2)
			.click();

		cy.url().should("include", "/user");

		cy.get("input[name=name]").should("have.value", "New User");

		cy.get("input[name=email]").should("have.value", "newuser@test.com");

		cy.get("input[name=password]").should("have.value", "");

		cy.get("input[name=password-confirm]").should("have.value", "");
	});

	it("admin user can edit a user", () => {
		cy.get("input[name=name]").clear();
		cy.get("input[name=name]").type("Edited User");

		cy.get("input[name=email]").clear();
		cy.get("input[name=email]").type("editeduser@test.com");

		cy.get("select[name=admin]").select("false");

		cy.get("input[name=password]").type("test123");

		cy.get("[data-cy=validation]")
			.eq(0)
			.should("contain", "8 characters minimum");

		cy.get("[data-cy=validation]")
			.eq(1)
			.should("contain", "One uppercase letter required");

		cy.get("input[name=password]").clear();
		cy.get("input[name=password]").type("Test1234");

		cy.get("input[name=password-confirm]").type("Test1234");

		cy.get("[data-cy=save-user]").click();

		cy.get("[data-cy=notification]").should("be.visible");
		cy.get("[data-cy=notification]").should("contain", "updated");

		cy.url().should("eq", Cypress.config().baseUrl + "/users");

		cy.get("[data-cy=user]").should("have.length", 3);

		// wait for sorting
		cy.wait(1000);

		cy.get("[data-cy=user]")
			.eq(1)
			.children()
			.first()
			.should("contain", "Edited User");

		cy.get("[data-cy=user]")
			.eq(1)
			.children()
			.eq(1)
			.should("contain", "editeduser@test.com");

		cy.get("[data-cy=user]")
			.eq(1)
			.children()
			.eq(2)
			.should("contain", "No");
	});

	it("admin user can delete a user", () => {
		cy.get("[data-cy=delete-user]")
			.eq(1)
			.click();

		cy.contains("Yes, delete")
			.first()
			.click()
			.then(() => {
				cy.get("[data-cy=notification]").should("be.visible");
				cy.get("[data-cy=notification]").should("contain", "deleted");

				cy.get("[data-cy=user]").should("have.length", 2);
			});
	});
});
