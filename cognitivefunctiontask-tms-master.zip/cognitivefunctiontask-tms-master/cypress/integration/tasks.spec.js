describe("Tasks", () => {
	before(() => {
		cy.request("POST", Cypress.env("api") + "/test/connect").then(() => {
			cy.request("POST", Cypress.env("api") + "/test/empty").then(() => {
				cy.task("db:seed");
			});
		});
	});

	beforeEach(() => {
		// log in programatically
		cy.request("POST", Cypress.env("api") + "/login", {
			email: "jsmith@test.com",
			password: "test",
		}).then((resp) => {
			localStorage.setItem("user", JSON.stringify(resp.body.user));
			localStorage.setItem("jwt", resp.body.token);
		});
	});

	after(() => {
		cy.request("POST", Cypress.env("api") + "/connect");
	});

	it("successfully loads page", () => {
		cy.visit("/");
	});

	it("user can view a list of tasks", () => {
		cy.get("[data-cy=task]").should("have.length", 2);
		cy.get("[data-cy=task]")
			.first()
			.children()
			.first()
			.should("contain", "Task 1");
		cy.get("[data-cy=task]")
			.first()
			.children()
			.eq(1)
			.should("contain", "Jerald Smith");
	});

	it("user can navigate to the create a task screen", () => {
		cy.get("[data-cy=create-task]").click();

		cy.url().should("include", "/task");
	});

	it("user cannot create a task with an empty name, target proportion or cycle speed", () => {
		cy.get("input[name=tutorialTargetProportion]").clear();

		cy.get("input[name=tutorialDemoCycleSpeed]").clear();

		cy.get("[data-cy=save-task]").click();

		cy.url().should("include", "/task");

		cy.get("[data-cy=validation]")
			.eq(0)
			.should("contain", "Name is required");

		cy.get("[data-cy=validation]")
			.eq(1)
			.should("contain", "Required field");

		cy.get("[data-cy=validation]")
			.eq(2)
			.should("contain", "Required field");
	});

	it("user cannot create a task with a name that matches an existing task name", () => {
		cy.get("input[name=name]").type("Task 1");

		cy.get("[data-cy=save-task]").click();

		cy.get("[data-cy=validation]")
			.eq(0)
			.should("contain", "A task already exists with that name");

		cy.get("input[name=name]").clear();
	});

	it("user can create a task", () => {
		cy.get("input[name=name]").type("New Task");

		cy.get("input[name=custom-url]").type("new-task");

		cy.get("textarea[name=description]").type("This is a new task.");

		cy.get("input[name=tutorialTargetProportion]").type(50);

		cy.get("input[name=tutorialDemoCycleSpeed]").type(100);

		cy.get("[data-cy=save-task]").click();

		cy.get("[data-cy=notification]").should("be.visible");
		cy.get("[data-cy=notification]").should("contain", "created");

		cy.url().should("eq", Cypress.config().baseUrl + "/");

		cy.get("[data-cy=task]").should("have.length", 3);

		cy.get("[data-cy=task]")
			.eq(2)
			.children()
			.first()
			.should("contain", "New Task");

		cy.get("[data-cy=task]")
			.eq(2)
			.children()
			.eq(1)
			.should("contain", "Jerald Smith");
	});

	it("user can navigate to edit task screen", () => {
		cy.get("[data-cy=edit-task]")
			.first()
			.click();

		cy.url().should("include", "/task");

		cy.get("input[name=name]").should("have.value", "Task 1");

		cy.get("input[name=custom-url]").should("have.value", "task-1");
	});

	it("user can edit a task", () => {
		// basic edit for now
		cy.get("input[name=name]").clear();
		cy.get("input[name=name]").type("Edited Task");

		cy.get("input[name=custom-url]").clear();

		cy.get("[data-cy=save-task]").click();

		cy.get("[data-cy=notification]").should("be.visible");
		cy.get("[data-cy=notification]").should("contain", "updated");

		cy.url().should("eq", Cypress.config().baseUrl + "/");

		cy.get("[data-cy=task]").should("have.length", 3);

		cy.get("[data-cy=task]")
			.first()
			.children()
			.first()
			.should("contain", "Edited Task");

		cy.get("[data-cy=task]")
			.first()
			.children()
			.eq(3)
			.should("not.be.empty");
	});

	it("user can view a task", () => {
		cy.get("[data-cy=view-task]")
			.first()
			.click();

		cy.get("[data-cy=task-name]").should("contain", "Edited Task");

		cy.get("[data-cy=task-url]").should(
			"contain",
			Cypress.env("app") + "/#/?task=5ef32f9d19656d9241ed7920"
		);

		// TODO: fix
		// currently doesn't work because execCommand('copy') doesn't work in cypress
		// waiting for a fix: https://github.com/cypress-io/cypress/issues/2851

		// cy.get("[data-cy=copy-task-url]")
		// 	.first()
		// 	.click({ native: true });

		// cy.task("get-clipboard").should(
		// 	"contain",
		// 	Cypress.env("app") + "/#/?task=5ef32f9d19656d9241ed7920"
		// );

		cy.get("[data-cy=close-task]").click();
	});

	it("user can duplicate a task", () => {
		cy.get("[data-cy=duplicate-task]")
			.first()
			.click();

		cy.get("[data-cy=task]").should("have.length", 4);
	});

	it("user can export a task to a json file", () => {
		cy.get("[data-cy=export-task]")
			.first()
			.click()
			.then(() => {
				cy.readFile(Cypress.env("downloadPath") + "EditedTask.json")
					.its("name")
					.should("eq", "Edited Task");
				cy.task(
					"delete-file",
					Cypress.env("downloadPath") + "EditedTask.json"
				);
			});
	});

	it("user can search tasks", () => {
		cy.get("[data-cy=task-search]").type("Task 2");

		cy.get("[data-cy=task]").should("have.length", 1);

		cy.get("[data-cy=task-search]").clear();

		cy.get("[data-cy=task]").should("have.length", 4);

		cy.get("[data-cy=task-search]").clear();
	});

	it("user can delete a task", () => {
		cy.get("[data-cy=delete-task]")
			.first()
			.click();

		cy.contains("Yes")
			.first()
			.click()
			.then(() => {
				cy.get("[data-cy=notification]").should("be.visible");
				cy.get("[data-cy=notification]").should("contain", "deleted");

				cy.get("[data-cy=task]").should("have.length", 3);
			});
	});

	it("user can import a task from a json file", () => {
		cy.fixture("importtask").then((task) => {
			cy.get('[data-cy="task-import"]').attachFile({
				fileContent: task,
				fileName: "ImportedTask.json",
				mimeType: "application/json",
			});

			cy.get("[data-cy=notification]").should("be.visible");
			cy.get("[data-cy=notification]").should("contain", "created");

			cy.get("[data-cy=task]").should("have.length", 4);

			cy.get("[data-cy=task]")
				.eq(3)
				.children()
				.first()
				.should("contain", "Imported Task");
		});
	});
});
