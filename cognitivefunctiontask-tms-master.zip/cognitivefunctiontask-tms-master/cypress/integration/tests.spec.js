describe("Tests", () => {
	before(() => {
		cy.request("POST", Cypress.env("api") + "/test/connect").then(() => {
			cy.request("POST", Cypress.env("api") + "/test/empty").then(() => {
				cy.task("db:seed");
			});
		});
	});

	beforeEach(() => {
		// log in programatically
		cy.request("POST", Cypress.env("api") + "/login", {
			email: "jsmith@test.com",
			password: "test",
		}).then((resp) => {
			localStorage.setItem("user", JSON.stringify(resp.body.user));
			localStorage.setItem("jwt", resp.body.token);
		});
	});

	after(() => {
		cy.request("POST", Cypress.env("api") + "/connect");
	});

	it("successfully loads page", () => {
		cy.visit("/tests");
	});

	it("user can view a list of tests", () => {
		cy.get("[data-cy=test]").should("have.length", 1);

		cy.get("[data-cy=test]")
			.eq(0)
			.children()
			.eq(0)
			.should("contain", "Task");

		cy.get("[data-cy=test]")
			.eq(0)
			.children()
			.eq(2)
			.should("contain", "Simon");
	});

	it("user can view an individual test", () => {
		cy.get("[data-cy=test]")
			.first()
			.click();

		cy.url().should("include", "/test/5f1558fe5a44a98d7c70c051");

		cy.get("[data-cy=test-task-details]")
			.children()
			.first()
			.should("contain", "Task");

		cy.get("[data-cy=test-player-name]").should("contain", "Simon");

		cy.get("[data-cy=test-detail-time]")
			.children()
			.eq(2)
			.should("contain", "28.746");

		cy.get("[data-cy=test-detail-stats]")
			.children()
			.eq(0)
			.should("contain", "50");

		cy.get("[data-cy=test-detail-stats]")
			.children()
			.eq(3)
			.should("contain", "54");

		// trials
		cy.get("[data-cy=test-trial]").should("have.length", 2);

		cy.get("[data-cy=test-trial]")
			.first()
			.children()
			.eq(3)
			.should("contain", "");

		cy.get("[data-cy=test-trial]")
			.first()
			.children()
			.eq(5)
			.should("contain", "25");

		cy.get("[data-cy=test-trial]")
			.first()
			.children()
			.eq(10)
			.should("contain", "30");
	});

	it("user can view the task of a test", () => {
		cy.get("[data-cy=test-task-details]").click();

		cy.get("[data-cy=test-task-trial-summary]").should("have.length", 1);

		cy.get("[data-cy=test-task-trial-summary]")
			.first()
			.children()
			.eq(0)
			.should("contain", "5");

		cy.get("[data-cy=test-task-trial-summary]")
			.first()
			.children()
			.eq(3)
			.should("contain", "2");

		cy.get("[data-cy=test-task-trial-summary]")
			.first()
			.children()
			.eq(4)
			.should("contain", "tb lr sd");

		cy.get("[data-cy=shapes]")
			.eq(2)
			.children()
			.eq(0)
			.should(
				"have.css",
				"background-image",
				`url("${Cypress.config().baseUrl}/img/shapes/L_0_sharp.png")`
			);
	});

	it("user can view the trial summary of a test task", () => {
		cy.get("[data-cy=test-task-trial-summary]")
			.first()
			.click();

		cy.get("[data-cy=test-task-trial-details]").should("be.visible");

		cy.get("[data-cy=test-task-trial-grid]")
			.first()
			.children()
			.eq(0)
			.should("contain", "5");

		cy.get("[data-cy=test-task-trial-grid]")
			.first()
			.children()
			.eq(2)
			.should("contain", "2");

		cy.get("[data-cy=test-task-trial-scanning]")
			.first()
			.children()
			.first()
			.should("contain", "Top to bottom, left to right, same direction");

		cy.get("[data-cy=test-task-trial-targets]").should("have.length", 1);

		cy.get("[data-cy=test-task-trial-target]")
			.first()
			.children()
			.eq(1)
			.should("contain", "All");

		cy.get("[data-cy=test-task-trial-target]")
			.first()
			.children()
			.eq(2)
			.should("contain", "None");

		cy.get("[data-cy=test-task-trial-target]")
			.first()
			.children()
			.eq(3)
			.should("contain", "50%");

		cy.get("[data-cy=close-test-task-trial-summary]").click();
	});

	it("user can view individual test trial information", () => {
		cy.get("[data-cy=test-trial]")
			.first()
			.click();

		cy.get("[data-cy=trial-grid]").should("be.visible");

		cy.get("[data-cy=test-trial-log]").should("have.length", 25);

		cy.get("[data-cy=test-trial-log]")
			.first()
			.children()
			.eq(1)
			.should("contain", "Yes");

		cy.get("[data-cy=test-trial-log]")
			.first()
			.children()
			.eq(6)
			.should("contain", "2 (1, 2)");

		cy.get("[data-cy=back]").click();
	});

	it("user can filter tests by task and/or date", () => {
		cy.get("select[name=task]")
			.children()
			.should("have.length", 2);

		cy.get("select[name=task]").select("Task");

		cy.get("[data-cy=test]").should("have.length", 1);

		cy.get("select[name=date]")
			.children()
			.should("have.length", 2);

		cy.get("select[name=date]").select("20/07/2020");

		cy.get("[data-cy=test]").should("have.length", 1);

		cy.get("select[name=task]").select("All");

		cy.get("[data-cy=test]").should("have.length", 1);

		cy.get("select[name=date]").select("All");
	});

	it("user can search tests", () => {
		cy.get("[data-cy=test-search]").type("Jerald");

		cy.get("[data-cy=test]").should("have.length", 0);

		cy.get("[data-cy=test-search]").clear();
		cy.get("[data-cy=test-search]").type("Simon");

		cy.get("[data-cy=test]").should("have.length", 1);

		cy.get("[data-cy=test-search]").clear();
	});

	it("user can export tests to csv", () => {
		cy.get("[data-cy=export-tests]").click();

		cy.get("[data-cy=test-export]").should("be.visible");

		cy.get("[data-cy=export]")
			.click()
			.then(() => {
				const date = new Date().toISOString();
				cy.readFile(
					Cypress.env("downloadPath") +
						`JeraldSmithCognitiveFunctionTaskDataExportTrialByTrial${date.substring(
							0,
							10
						)}.csv`
				).then((file) => {
					const array = file.split(/\r?\n/);
					const headers = array[0].split(",");
					expect(headers[2]).to.equal("taskName");
					const firstRow = array[1].split(",");
					expect(firstRow[2]).to.equal("Task");
				});
				cy.task(
					"delete-file",
					Cypress.env("downloadPath") +
						`JeraldSmithCognitiveFunctionTaskDataExportTrialByTrial${date.substring(
							0,
							10
						)}.csv`
				);
			});
	});

	it("user can import a test from json", () => {
		cy.get("[data-cy=upload-tests]").click();

		cy.fixture("importtest").then((test) => {
			cy.get('[data-cy="test-import"]').attachFile({
				fileContent: test,
				fileName: "Task2Simon2020-06-01.json",
				mimeType: "application/json",
			});

			cy.fixture("importtest2").then((test) => {
				cy.get('[data-cy="test-import"]').attachFile({
					fileContent: test,
					fileName: "Task4Simon2020-06-01.json",
					mimeType: "application/json",
				});

				cy.get("[data-cy=upload-tests]").click();

				cy.get("[data-cy=notification]").should("be.visible");
				cy.get("[data-cy=notification]").should("contain", "uploaded");

				cy.get("[data-cy=test]").should("have.length", 3);

				cy.get("[data-cy=test]")
					.eq(1)
					.children()
					.first()
					.should("contain", "Task 2");

				cy.get("[data-cy=hide-upload-box]").click();
			});
		});
	});

	it("user can delete an individual test", () => {
		cy.get("[data-cy=delete-test]")
			.eq(2)
			.click();

		cy.contains("Yes")
			.first()
			.click()
			.then(() => {
				cy.get("[data-cy=notification]").should("be.visible");
				cy.get("[data-cy=notification]").should("contain", "deleted");

				cy.get("[data-cy=test]").should("have.length", 2);
			});
	});

	it("user can delete multiple filtered tests", () => {
		cy.get("[data-cy=test-search]").type("Simon");

		cy.get("[data-cy=test]").should("have.length", 2);

		cy.get("[data-cy=delete-tests]").click();

		cy.contains("Yes")
			.first()
			.click()
			.then(() => {
				cy.get("[data-cy=notification]").should("be.visible");
				cy.get("[data-cy=notification]").should("contain", "deleted");

				cy.get("[data-cy=test]").should("have.length", 0);
			});
	});
});
