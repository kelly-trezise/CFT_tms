describe("Trials", () => {
	before(() => {
		cy.request("POST", Cypress.env("api") + "/test/connect").then(() => {
			cy.request("POST", Cypress.env("api") + "/test/empty").then(() => {
				cy.task("db:seed");
			});
		});
	});

	beforeEach(() => {
		// log in programatically
		cy.request("POST", Cypress.env("api") + "/login", {
			email: "jsmith@test.com",
			password: "test",
		}).then((resp) => {
			localStorage.setItem("user", JSON.stringify(resp.body.user));
			localStorage.setItem("jwt", resp.body.token);
		});
	});

	after(() => {
		cy.request("POST", Cypress.env("api") + "/connect");
	});

	it("successfully loads task", () => {
		// id taken from seeded records
		cy.visit("/task/5ef32f9d19656d9241ed7920");

		cy.get("input[name=name]").should("have.value", "Task 1");

		cy.get("input[name=custom-url]").should("have.value", "task-1");

		cy.get("[data-cy=trial]").should("have.length", 1);
	});

	it("user cannot add a trial with missing information or negative numbers", () => {
		// open trial section
		cy.get("[data-cy=create-trial]").click();

		cy.get("input[name=numRows]").clear();

		cy.get("input[name=numNodesPerRow]").clear();

		cy.get("input[name=numTrials]").clear();

		cy.get("[data-cy=save-trial]").click();

		cy.get("[data-cy=validation]")
			.eq(0)
			.should("contain", "Required field");

		cy.get("[data-cy=validation]")
			.eq(1)
			.should("contain", "Required field");

		cy.get("[data-cy=validation]")
			.eq(2)
			.should("contain", "Required field");

		cy.get("[data-cy=validation]")
			.eq(3)
			.should("contain", "Must select at least 1 target");

		cy.get("[data-cy=validation]")
			.eq(4)
			.should("contain", "Target proportion must be between 1 and 100%");

		cy.get("[data-cy=validation]")
			.eq(5)
			.should("contain", "Must select at least 1 near distractor");

		cy.get("[data-cy=validation]")
			.eq(6)
			.should("contain", "Must select at least 1 far distractor");

		cy.get("input[name=numRows]").type(-1);

		cy.get("input[name=numNodesPerRow]").type(-10);

		cy.get("input[name=numTrials]").type(-5);

		cy.get("[data-cy=save-trial]").click();

		cy.get("[data-cy=validation]")
			.eq(0)
			.should("contain", "Must be 1 or more");

		cy.get("[data-cy=validation]")
			.eq(1)
			.should("contain", "Must be 1 or more");

		cy.get("[data-cy=validation]")
			.eq(2)
			.should("contain", "Must be 1 or more");

		cy.get("[data-cy=close-trial]").click();
	});

	it("user can add a trial", () => {
		// open trial section
		cy.get("[data-cy=create-trial]").click();

		// populate
		cy.get("input[name=numRows]").clear();
		cy.get("input[name=numRows]").type(3);

		cy.get("input[name=numNodesPerRow]").clear();
		cy.get("input[name=numNodesPerRow]").type(10);

		cy.get("input[name=numTrials]").clear();
		cy.get("input[name=numTrials]").type(5);

		cy.get("[data-cy=default-shapes]")
			.eq(2)
			.click();
		cy.get("[data-cy=default-shapes]")
			.eq(3)
			.click();
		cy.get("[data-cy=default-shapes]")
			.eq(4)
			.click();

		cy.get("[data-cy=save-trial]").click();

		cy.get("[data-cy=trial]").should("have.length", 2);

		cy.get("[data-cy=trial]")
			.eq(1)
			.children()
			.eq(1)
			.should("contain", 3);
		cy.get("[data-cy=trial]")
			.eq(1)
			.children()
			.eq(2)
			.should("contain", 10);
		cy.get("[data-cy=trial]")
			.eq(1)
			.children()
			.eq(4)
			.should("contain", "tb lr sd");
		cy.get("[data-cy=trial]")
			.eq(1)
			.children()
			.eq(6)
			.should("contain", 5);
	});

	it("user can edit a trial", () => {
		// open trial section
		cy.get("[data-cy=edit-trial]")
			.first()
			.click();

		cy.get("input[name=numRows]").clear();
		cy.get("input[name=numRows]").type(5);

		cy.get("input[name=numNodesPerRow]").clear();
		cy.get("input[name=numNodesPerRow]").type(20);

		cy.get("input[name=numTrials]").clear();
		cy.get("input[name=numTrials]").type(10);

		cy.get("select[name=scanningDirection]")
			.eq(6)
			.select("bt");

		cy.get("[data-cy=save-trial]").click();

		cy.get("[data-cy=trial]").should("have.length", 2);

		cy.get("[data-cy=trial]")
			.eq(0)
			.children()
			.eq(1)
			.should("contain", 5);
		cy.get("[data-cy=trial]")
			.eq(0)
			.children()
			.eq(2)
			.should("contain", 20);
		cy.get("[data-cy=trial]")
			.eq(0)
			.children()
			.eq(4)
			.should("contain", "bt lr sd");
		cy.get("[data-cy=trial]")
			.eq(0)
			.children()
			.eq(6)
			.should("contain", 10);
	});

	it("user can discard a trial edit without it saving", () => {
		// open trial section
		cy.get("[data-cy=edit-trial]")
			.first()
			.click();

		cy.get("input[name=numRows]").clear();
		cy.get("input[name=numRows]").type(2);

		cy.get("input[name=numNodesPerRow]").clear();
		cy.get("input[name=numNodesPerRow]").type(2);

		cy.get("input[name=numTrials]").clear();
		cy.get("input[name=numTrials]").type(2);

		cy.get("select[name=scanningDirection]")
			.eq(6)
			.select("bt");

		cy.get("[data-cy=close-trial]").click();

		cy.get("[data-cy=trial]").should("have.length", 2);

		cy.get("[data-cy=trial]")
			.eq(0)
			.children()
			.eq(1)
			.should("contain", 5);
		cy.get("[data-cy=trial]")
			.eq(0)
			.children()
			.eq(2)
			.should("contain", 20);
		cy.get("[data-cy=trial]")
			.eq(0)
			.children()
			.eq(4)
			.should("contain", "bt lr sd");
		cy.get("[data-cy=trial]")
			.eq(0)
			.children()
			.eq(6)
			.should("contain", 10);
	});

	it("user can view a generated trial preview", () => {
		cy.get("[data-cy=preview-trial]")
			.eq(1)
			.click();

		cy.get("[data-cy=trial-preview]").should("be.visible");

		cy.get("[data-cy=trial-grid]").should("be.visible");

		cy.get("[data-cy=close-trial-preview]").click();
	});

	it("user can duplicate a trial", () => {
		cy.get("[data-cy=duplicate-trial]")
			.eq(1)
			.click();

		cy.get("[data-cy=trial]").should("have.length", 3);

		cy.get("[data-cy=trial]")
			.eq(2)
			.children()
			.eq(1)
			.should("contain", 3);
		cy.get("[data-cy=trial]")
			.eq(2)
			.children()
			.eq(2)
			.should("contain", 10);
		cy.get("[data-cy=trial]")
			.eq(2)
			.children()
			.eq(4)
			.should("contain", "tb lr sd");
		cy.get("[data-cy=trial]")
			.eq(2)
			.children()
			.eq(6)
			.should("contain", 5);
	});

	it("user can delete a trial", () => {
		cy.get("[data-cy=delete-trial]")
			.eq(2)
			.click();

		cy.contains("Yes, delete")
			.first()
			.click();

		cy.get("[data-cy=trial]").should("have.length", 2);
	});

	it("user can change trial order and generate a preview", () => {
		cy.get("select[name=trialOrder]")
			.first()
			.select("randomised");

		cy.get("[data-cy=preview-trial-order]").click();

		cy.get("[data-cy=trial-order-preview]").should("be.visible");

		cy.get("[data-cy=close-trial-order-preview]").click();
	});

	it("user can set lock for edit permissions", () => {
		cy.get("select[name=locked]")
			.first()
			.select("true");

		cy.get("[data-cy=show-task-permissions]").click();

		cy.get("[data-cy=task-permissions]").should("be.visible");

		cy.get("[data-cy=permissions-user-name]")
			.first()
			.should("contain", "Jerald Smith");

		cy.get("[data-cy=permissions-user-name]")
			.eq(1)
			.should("contain", "Another User");

		// current user checkbox should be disabled
		cy.get("[data-cy=can-edit]")
			.first()
			.should("be.disabled");

		// other user checkbox can be checked
		cy.get("[data-cy=can-edit]")
			.eq(1)
			.should("not.be.disabled");

		cy.get("[data-cy=can-edit]")
			.eq(1)
			.check();

		cy.get("[data-cy=can-edit]")
			.eq(1)
			.should("be.checked");

		cy.get("[data-cy=can-edit]")
			.eq(1)
			.uncheck();

		cy.get("[data-cy=can-edit]")
			.eq(1)
			.should("not.be.checked");

		// close modal
		cy.get("[data-cy=save-task-permissions]").click();
	});

	it("user can begin managing trial targets", () => {
		cy.get("[data-cy=edit-trial]")
			.first()
			.click();

		cy.get("[data-cy=select-shapes]")
			.eq(2)
			.click();

		cy.get("[data-cy=target-select]").should("be.visible");
	});

	it("user cannot add targets to a trial without selecting shapes", () => {
		cy.get("[data-cy=create-target]").click();

		cy.get("[data-cy=save-target").click();

		cy.get("[data-cy=validation]")
			.eq(0)
			.should("contain", "Must select at least 1 shape");

		cy.get("[data-cy=close-target]").click();
	});

	it("user can add targets to a trial", () => {
		// with every n and relationship
		cy.get("[data-cy=create-target]").click();

		cy.get("[data-cy=select-shapes]")
			.eq(5)
			.click();

		cy.get("select[name=shapes]").select([
			"T_0_sharp.png",
			"T_90_sharp.png",
		]);

		cy.get("select[name=isTarget]").select("2");

		cy.get("input[name=proportion]").clear();
		cy.get("input[name=proportion]").type(30);

		cy.get("[data-cy=save-target").click();

		cy.get("[data-cy=target]").should("have.length", 2);

		cy.get("[data-cy=shapes]")
			.eq(1)
			.children()
			.eq(0)
			.should(
				"have.css",
				"background-image",
				`url("${Cypress.config().baseUrl}/img/shapes/T_0_sharp.png")`
			);

		cy.get("[data-cy=target]")
			.eq(1)
			.children()
			.eq(2)
			.should("contain", "2nd");

		cy.get("[data-cy=target]")
			.eq(1)
			.children()
			.eq(3)
			.should("contain", "None");

		cy.get("[data-cy=target]")
			.eq(1)
			.children()
			.eq(4)
			.should("contain", "No");

		cy.get("[data-cy=target]")
			.eq(1)
			.children()
			.eq(5)
			.should("contain", "30%");
	});

	it("user can edit a target", () => {
		cy.get("[data-cy=edit-target]")
			.eq(1)
			.click();

		cy.get("input[name=proportion]").clear();
		cy.get("input[name=proportion]").type(15);

		cy.get("[data-cy=save-target").click();

		cy.get("[data-cy=shapes]")
			.eq(1)
			.children()
			.eq(0)
			.should(
				"have.css",
				"background-image",
				`url("${Cypress.config().baseUrl}/img/shapes/T_0_sharp.png")`
			);

		cy.get("[data-cy=target]")
			.eq(1)
			.children()
			.eq(2)
			.should("contain", "2nd");

		cy.get("[data-cy=target]")
			.eq(1)
			.children()
			.eq(3)
			.should("contain", "None");

		cy.get("[data-cy=target]")
			.eq(1)
			.children()
			.eq(4)
			.should("contain", "No");

		cy.get("[data-cy=target]")
			.eq(1)
			.children()
			.eq(5)
			.should("contain", "15%");
	});

	it("user can delete targets from a trial", () => {
		cy.get("[data-cy=delete-target]")
			.eq(1)
			.click();

		cy.contains("Yes, delete")
			.first()
			.click();

		cy.get("[data-cy=target]").should("have.length", 1);
	});

	it("user can only have a relationship when there is a single target", () => {
		cy.get("[data-cy=edit-target]")
			.eq(0)
			.click();

		cy.get("select[name=relationship]").select("Yes");

		cy.get("[data-cy=select-shapes]")
			.eq(6)
			.click();

		cy.get("select[name=shapes]").select(["T_0_sharp.png"]);

		cy.get("[data-cy=save-target").click();

		cy.get("[data-cy=target]")
			.eq(0)
			.children()
			.eq(4)
			.should("contain", "Yes");

		cy.get("[data-cy=create-target]").click();

		cy.get("[data-cy=select-shapes]")
			.eq(5)
			.click();

		cy.get("select[name=shapes]").select(["T_0_sharp.png"]);

		cy.get("[data-cy=save-target]").click();

		cy.contains("Continue")
			.first()
			.click();

		cy.get("[data-cy=target]")
			.eq(0)
			.children()
			.eq(4)
			.should("contain", "No");

		cy.get("[data-cy=delete-target]")
			.eq(1)
			.click();

		cy.contains("Yes, delete")
			.first()
			.click();

		cy.get("[data-cy=target]").should("have.length", 1);
	});

	it("user cannot create non-mutually exclusive relationships that are not matching single shapes", () => {
		cy.get("[data-cy=edit-target]")
			.eq(0)
			.click();

		cy.get("select[name=relationship]").select("Yes");

		cy.get("[data-cy=select-shapes]")
			.eq(6)
			.click();

		cy.get("select[name=shapes]").select(["L_0_sharp.png"]);

		cy.get("[data-cy=save-target").click();

		cy.get("[data-cy=validation]")
			.eq(0)
			.should(
				"contain",
				"Must not contain same shapes as the target (unless both are the same single shape)"
			);

		cy.get("[data-cy=close-target").click();
	});

	it("user cannot create two rules for one shape", () => {
		cy.get("[data-cy=create-target]").click();

		cy.get("[data-cy=select-shapes]")
			.eq(5)
			.click();

		cy.get("select[name=shapes]").select([
			"L_0_sharp.png",
			"L_90_sharp.png",
			"L_180_sharp.png",
			"L_270_sharp.png",
		]);

		cy.get("[data-cy=save-target").click();

		cy.get("[data-cy=validation]")
			.eq(0)
			.should("contain", "Shapes can only be part of one target rule");

		cy.get("[data-cy=close-target]").click();
	});

	it("user can save updated targets", () => {
		cy.get("[data-cy=save-targets]").click();

		cy.get("[data-cy=selected-shapes")
			.eq(0)
			.children()
			.eq(0)
			.should(
				"have.css",
				"background-image",
				`url("${Cypress.config().baseUrl}/img/shapes/L_0_sharp.png")`
			);

		cy.get("input[name=targetProportion]").should("have.value", 20);
	});

	it("user can close select targets without saving", () => {
		cy.get("[data-cy=select-shapes]")
			.eq(2)
			.click();

		cy.get("[data-cy=target-select]").should("be.visible");

		cy.get("[data-cy=edit-target]")
			.first()
			.click();

		cy.get("input[name=proportion]").clear();
		cy.get("input[name=proportion]").type(30);

		cy.get("[data-cy=save-target").click();

		cy.get("[data-cy=target]")
			.eq(0)
			.children()
			.eq(5)
			.should("contain", "30%");

		cy.get("[data-cy=close-targets]").click();

		cy.get("input[name=targetProportion]").should("have.value", 20);

		cy.get("[data-cy=save-trial").click();
	});

	it("user can set adaptive rules and begin managing those rules on a trial", () => {
		cy.get("select[name=trialOrder]")
			.first()
			.select("sequential");

		cy.get("[data-cy=edit-trial]")
			.first()
			.click();

		cy.get("select[name=adaptive]").select("true");

		cy.get("[data-cy=select-rules]").should("be.visible");

		cy.get("[data-cy=select-rules]").click();

		cy.get("[data-cy=rules-select]").should("be.visible");

		cy.get("[data-cy=rules]").should("have.length", 0);
	});

	it("user cannot add a rule with missing information or out of bounds numbers", () => {
		cy.get("[data-cy=create-rule]").click();

		cy.get("input[name=averageStatisticPercentage]").clear();

		cy.get("input[name=updateVariableChange]").clear();

		cy.get("[data-cy=save-rule]").click();

		cy.get("[data-cy=validation]")
			.eq(0)
			.should("contain", "Required field");

		cy.get("[data-cy=validation]")
			.eq(1)
			.should("contain", "Required field");

		cy.get("input[name=averageStatisticPercentage]").type(-10);

		cy.get("[data-cy=save-rule]").click();

		cy.get("[data-cy=validation]")
			.eq(0)
			.should("contain", "Must be between 1 and 100");

		cy.get("input[name=averageStatisticPercentage]").clear();

		cy.get("[data-cy=close-rule]").click();
	});

	it("user can add a rule to a trial", () => {
		cy.get("[data-cy=create-rule]").click();

		cy.get("select[name=updateVariable]").select("gridSize");

		cy.get("input[name=updateVariableChange]").clear();
		cy.get("input[name=updateVariableChange]").type(20);

		cy.get("[data-cy=updated-variable-example").should(
			"contain",
			"e.g. from 5x20 to 6x24"
		);

		cy.get("[data-cy=save-rule]").click();

		cy.get("[data-cy=rule]").should("have.length", 1);

		cy.get("[data-cy=rule]")
			.eq(0)
			.children()
			.eq(1)
			.should("contain", "1 trial(s)");

		cy.get("[data-cy=rule]")
			.eq(0)
			.children()
			.eq(2)
			.should("contain", "selectedTargets < 50%");

		cy.get("[data-cy=rule]")
			.eq(0)
			.children()
			.eq(3)
			.should("contain", "gridSize");

		cy.get("[data-cy=rule]")
			.eq(0)
			.children()
			.eq(4)
			.should("contain", "20%");

		cy.get("[data-cy=rule]")
			.eq(0)
			.children()
			.eq(5)
			.should("contain", "No");
	});

	it("user can edit a trial rule", () => {
		cy.get("[data-cy=edit-rule]")
			.first()
			.click();

		cy.get("select[name=afterNTrials]").select("2");

		cy.get("select[name=averageStatistic]").select("timeRemaining");

		cy.get("select[name=averageStatisticComparison").select("greaterThan");

		cy.get("input[name=averageStatisticPercentage").clear();
		cy.get("input[name=averageStatisticPercentage").type("80");

		cy.get("select[name=continuous]").select("true");

		cy.get("[data-cy=save-rule]").click();

		cy.get("[data-cy=rule]").should("have.length", 1);

		cy.get("[data-cy=rule]")
			.eq(0)
			.children()
			.eq(1)
			.should("contain", "2 trial(s)");

		cy.get("[data-cy=rule]")
			.eq(0)
			.children()
			.eq(2)
			.should("contain", "timeRemaining > 80%");

		cy.get("[data-cy=rule]")
			.eq(0)
			.children()
			.eq(3)
			.should("contain", "gridSize");

		cy.get("[data-cy=rule]")
			.eq(0)
			.children()
			.eq(4)
			.should("contain", "20%");

		cy.get("[data-cy=rule]")
			.eq(0)
			.children()
			.eq(5)
			.should("contain", "Yes");
	});

	it("user can discard a trial rule edit without it saving", () => {
		cy.get("[data-cy=edit-rule]")
			.first()
			.click();

		cy.get("input[name=averageStatisticPercentage").clear();
		cy.get("input[name=averageStatisticPercentage").type("40");

		cy.get("[data-cy=close-rule]").click();

		cy.get("[data-cy=rule]").should("have.length", 1);

		cy.get("[data-cy=rule]")
			.eq(0)
			.children()
			.eq(2)
			.should("contain", "timeRemaining > 80%");
	});

	it("user can duplicate trial rules", () => {
		cy.get("[data-cy=duplicate-rule]")
			.eq(0)
			.click();

		cy.get("[data-cy=rule]").should("have.length", 2);

		cy.get("[data-cy=rule]")
			.eq(1)
			.children()
			.eq(1)
			.should("contain", "2 trial(s)");

		cy.get("[data-cy=rule]")
			.eq(1)
			.children()
			.eq(2)
			.should("contain", "timeRemaining > 80%");

		cy.get("[data-cy=rule]")
			.eq(1)
			.children()
			.eq(3)
			.should("contain", "gridSize");

		cy.get("[data-cy=rule]")
			.eq(1)
			.children()
			.eq(4)
			.should("contain", "20%");

		cy.get("[data-cy=rule]")
			.eq(1)
			.children()
			.eq(5)
			.should("contain", "Yes");
	});

	it("user can delete a trial rule", () => {
		cy.get("[data-cy=delete-rule]")
			.eq(1)
			.click();

		cy.contains("Yes, delete")
			.first()
			.click();

		cy.get("[data-cy=rule]").should("have.length", 1);
	});

	it("user can save trial rules", () => {
		cy.get("[data-cy=save-rules]").click();

		cy.get("[data-cy=num-rules]").should("contain", "1 rule(s)");
	});

	it("user can close select rules without it saving", () => {
		cy.get("[data-cy=select-rules]").should("be.visible");

		cy.get("[data-cy=select-rules]").click();

		cy.get("[data-cy=rules-select]").should("be.visible");

		cy.get("[data-cy=duplicate-rule]")
			.first()
			.click();

		cy.get("[data-cy=rule]").should("have.length", 2);

		cy.get("[data-cy=close-rules").click();

		cy.get("[data-cy=num-rules]").should("contain", "1 rule(s)");

		cy.get("[data-cy=save-trial").click();
	});
});
