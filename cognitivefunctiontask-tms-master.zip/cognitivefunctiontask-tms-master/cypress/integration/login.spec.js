describe("Login", () => {
	before(() => {
		cy.request("POST", Cypress.env("api") + "/test/connect").then(() => {
			cy.request("POST", Cypress.env("api") + "/test/empty").then(() => {
				cy.task("db:seed");
			});
		});
	});

	after(() => {
		cy.request("POST", Cypress.env("api") + "/connect");
	});

	it("successfully loads page", () => {
		cy.visit("/login");
	});

	it("sets auth cookie when logging in via form submission", () => {
		const credentials = {
			email: "jsmith@test.com",
			password: "test",
		};

		cy.get("input[name=email]").type(credentials.email);

		cy.get("input[name=password]").type(credentials.password);

		cy.get("input[name=rememberMe]").check();

		cy.get("[data-cy=submit]")
			.click()
			.should(() => {
				expect(localStorage.getItem("user")).to.exist;
				expect(localStorage.getItem("jwt")).to.exist;
			});

		cy.url().should("eq", Cypress.config().baseUrl + "/");

		cy.get("[data-cy=current-user-name]").should("contain", "Jerald Smith");
	});

	it("user can logout", () => {
		cy.get("[data-cy=logout]").click();

		expect(localStorage.getItem("user")).to.not.exist;
		expect(localStorage.getItem("jwt")).to.not.exist;
	});

	it("user without admin access can't see or access users section", () => {
		const credentials = {
			email: "auser@test.com",
			password: "test",
		};

		cy.get("input[name=email]").type(credentials.email);

		cy.get("input[name=password]").type(credentials.password);

		cy.get("input[name=rememberMe]").check();

		cy.get("[data-cy=submit]")
			.click()
			.should(() => {
				expect(localStorage.getItem("user")).to.exist;
				expect(localStorage.getItem("jwt")).to.exist;
			});

		cy.url().should("eq", Cypress.config().baseUrl + "/");

		cy.get("[data-cy=current-user-name]").should("contain", "Another User");

		cy.get("[data-cy=view-users]").should("not.exist");

		cy.visit("/users");

		cy.url().should("eq", Cypress.config().baseUrl + "/");
	});
});
